import type { TransportMapRenderer } from "../contracts/renderer";
import { Canvas2dRenderer } from "./canvas2d/canvas2dRenderer";

export function createTransportMapRenderer(): TransportMapRenderer {
  // Canvas is intentionally the production default until a measured Android
  // WebGL2 win and the precision/context-loss gates exist.
  return new Canvas2dRenderer("canvas2d-main-thread");
}

