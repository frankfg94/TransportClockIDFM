import {
  GLOBAL_MAP_MODE_ORDER,
  type GlobalMapMode,
  type GlobalMapStation,
} from "../contracts/manifest";
import { GLOBAL_TRANSPORT_PLAN_CONFIG } from "../config/globalTransportPlanConfig";
import type { TransportMapRenderScene } from "../contracts/renderer";
import type { CameraState } from "../geo/camera";

/** The zoom at which ordinary overview stations receive a rendered dot. */
export const GLOBAL_TRANSPORT_PLAN_STATION_DETAIL_ZOOM = 14;

type StationNodeVisibilityScene = Pick<
  TransportMapRenderScene,
  | "lines"
  | "activeLineId"
  | "activeStationId"
  | "hoveredLineId"
  | "selectedStationIds"
  | "visibleModeMask"
  | "ghostLineIds"
>;

/**
 * Creates the pre-hover station visibility rule shared by Canvas rendering
 * and pointer hit-testing. `hoveredStationId` is deliberately not part of
 * the rule: a hidden station must not become visible merely because the
 * pointer landed on its hidden hit target.
 */
export function createStationNodeVisibilityPredicate(
  camera: Pick<CameraState, "zoom">,
  scene: StationNodeVisibilityScene,
): (station: GlobalMapStation) => boolean {
  const ghostLineIds = new Set(scene.ghostLineIds ?? []);
  const visibleLineIds = new Set(
    scene.lines
      .filter((line) => isModeVisible(line.mode, scene.visibleModeMask) || ghostLineIds.has(line.id))
      .map((line) => line.id),
  );
  const activeLine = scene.activeLineId
    ? scene.lines.find((line) => line.id === scene.activeLineId)
    : undefined;
  const activeLineStationIds = new Set(activeLine?.stationIds ?? []);
  if (activeLine) visibleLineIds.add(activeLine.id);
  const hoveredGhostLine = scene.hoveredLineId &&
    scene.hoveredLineId !== scene.activeLineId &&
    ghostLineIds.has(scene.hoveredLineId)
    ? scene.lines.find((line) => line.id === scene.hoveredLineId)
    : undefined;
  const hoveredGhostStationIds = new Set(hoveredGhostLine?.stationIds ?? []);
  const selectedStationIds = new Set(scene.selectedStationIds);

  return (station) => {
    if (!station.lineIds.some((lineId) => visibleLineIds.has(lineId))) return false;

    const selectedStation = station.id === scene.activeStationId || selectedStationIds.has(station.id);
    if (selectedStation || hoveredGhostStationIds.has(station.id)) return true;

    // A selected line is the user's explicit scope. Its station dots must
    // remain available at every zoom, including the merged/direction view.
    if (activeLineStationIds.has(station.id)) return true;

    if (isMajorOverviewHub(station, scene.lines)) return true;

    return camera.zoom >= GLOBAL_TRANSPORT_PLAN_STATION_DETAIL_ZOOM;
  };
}

function isMajorOverviewHub(
  station: GlobalMapStation,
  lines: StationNodeVisibilityScene["lines"],
): boolean {
  if (!station.isHub) return false;
  const stationLineIds = new Set(station.lineIds);
  if (stationLineIds.size >= GLOBAL_TRANSPORT_PLAN_CONFIG.renderer.overviewMajorHubMinLines) return true;

  // Some major poles are split into two line records, such as a rail/metro
  // or rail/tram interchange. Keep those cross-family pairs, but hide
  // same-family pairs like the U/L and U/N stations in the overview. The
  // classification intentionally uses the station's complete line list: a
  // secondary family can be filtered from the current view while the station
  // remains a real interchange hub.
  const stationModes = new Set(
    lines
      .filter((line) => stationLineIds.has(line.id))
      .map((line) => line.mode),
  );
  return stationModes.size >= 2;
}

function isModeVisible(mode: GlobalMapMode, mask: number): boolean {
  const modeIndex = GLOBAL_MAP_MODE_ORDER.indexOf(mode);
  return modeIndex >= 0 && (mask & (1 << modeIndex)) !== 0;
}
