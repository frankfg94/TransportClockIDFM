<script setup lang="ts">
import "@vue-flow/core/dist/style.css";
import "@vue-flow/controls/dist/style.css";
import dagre from "@dagrejs/dagre";
import {
  computed,
  nextTick,
  onBeforeUnmount,
  onMounted,
  ref,
  watch,
} from "vue";
import { Handle, Position, VueFlow } from "@vue-flow/core";
import type { Edge, Node } from "@vue-flow/core";
import LineIconBadge from "../../components/LineIconBadge.vue";
import MaterialCombobox from "../../components/MaterialCombobox.vue";
import MobileActionsMenu from "../../components/MobileActionsMenu.vue";
import StationTransferDetails from "../../components/StationTransferDetails.vue";
import {
  createTransportModeIcon,
  transitModeToFamily,
} from "../../services/linePresentation";
import { Controls } from "@vue-flow/controls";
import {
  Bus,
  Eye,
  Expand,
  Footprints,
  Info,
  Minimize2,
  TriangleAlert,
  X,
} from "lucide-vue-next";
import DistanceToggle from "../../components/DistanceToggle.vue";
import PatternFlowMiniMap from "./PatternFlowMiniMap.vue";
import { resolveTransitLonLat } from "../network-ghost/geoProjection";
import {
  formatTransitDistance,
  getCoordinatesDistanceKm,
} from "../../services/distance";
import { toServerApiUrl } from "../../services/serverApi";
import {
  createPatternStationKey as createStationKey,
  patternStationKeysAreCompatible as stationKeysAreCompatible,
} from "./stationKeys";
import {
  getFlowLightEdgeClass,
  getVisualFlowEdgeEndpoints,
} from "./flowDirection";
import { countPatternTopologyStations } from "./compactPatternFlow";
import {
  hydrateDeparturePatternTransfers,
  type PatternTransferHydrationProgress,
} from "./patternTransfers";
import { clearTransferBundleForBoard } from "./transferBundles";
import {
  filterCurrentLineTransfers,
  filterDuplicateBusTransfers,
  isBusLikeTransfer,
  isVisiblePatternPlanTransfer,
  type CurrentLineIdentity,
} from "./transferVisibility";
import type { TransferResolverMode } from "./transferResolverMode";
import type { HealthCheck, HealthResponse } from "../health/types";
import TrafficDisruptionCard from "../traffic/TrafficDisruptionCard.vue";
import {
  getTrafficDisruptionDisplayPeriod,
  getUpcomingTrafficWarningStart,
  parseTrafficDate,
} from "../traffic/trafficTiming";
import type { TrafficCalendarImpactScope, TrafficLineReport } from "../traffic";
import {
  type PatternTrafficImpact,
  type PatternTrafficImpactAnalysis,
  type PatternTrafficImpactSegment,
  type PatternTrafficEdge,
  type PatternTrafficStation,
} from "./trafficImpactAnalysis";
import {
  useDeparturePatternTraffic,
  type DeparturePatternTrafficAnalyzer,
} from "./useDeparturePatternTraffic";
import PatternTrafficCalendarSurface from "./PatternTrafficCalendarSurface.vue";
import PatternTrafficCalendarToggle from "./PatternTrafficCalendarToggle.vue";
import type { PatternTrafficCalendarDay } from "./trafficCalendar";
import type { PatternTrafficSummaryEntry } from "./trafficCalendarSummary";
import { usePatternTrafficCalendar } from "./usePatternTrafficCalendar";
import {
  TRAFFIC_DISTURBANCE_COLOR,
  TRAFFIC_INTERRUPTION_COLOR,
} from "./trafficImpactStyles";
import { createInterruptionWalkingTimes } from "./interruptionWalkingTimes";
import {
  createTrafficMarkerStationObstacles,
  getTrafficMarkerAnchor,
  getTrafficMarkerPulseStationKeys,
  getTrafficMarkerSize,
  groupPatternTrafficMarkerSegments,
  layoutTrafficMarkers,
  shouldPreferTrafficMarkerAbove,
  type PatternTrafficMarkerGroup,
  type TrafficMarkerRect,
} from "./trafficMarkerLayout";
import {
  createDeparturePatternModalInfoCardsDebugTools,
  type InfoCardDebugEdge,
  type InfoCardDebugMarker,
  type InfoCardDebugObstacle,
  type InfoCardDebugRect,
  type InfoCardDebugSnapshot,
} from "./infoCardsDebugTools/infoCardsDebugTools";
import { useI18n } from "../../i18n";
import { useAppSettings } from "../app-settings/appSettings";
import { transportClockPlugins } from "#transport-clock/plugins";
import { translatePluginMessage } from "../plugins/pluginRuntime";

import type {
  Departure,
  DepartureCall,
  DepartureCallingPattern,
  DepartureServiceType,
  LineRouteBranchLayout,
  LineRouteSequence,
  LineRouteStop,
  LineTopologyLayout,
  LineTopologyTerminalJunctionLayout,
  LineTopologyLoopLayout,
  LinePatternDirectionOption,
  TransferLineOption,
  TransitBoardConfig,
} from "../../types/transit";

type PatternStationFlowNode = Node<
  PatternStationNodeData,
  Record<string, never>,
  "station"
>;
type PatternCityZoneFlowNode = Node<
  PatternCityZoneNodeData,
  Record<string, never>,
  "city-zone"
>;
type PatternTrafficMarkerFlowNode = Node<
  PatternTrafficMarkerNodeData,
  Record<string, never>,
  "traffic-marker"
>;
type PatternTrafficMarkerConnectorFlowNode = Node<
  PatternTrafficMarkerConnectorNodeData,
  Record<string, never>,
  "traffic-marker-connector"
>;
type PatternTrafficWalkingFlowNode = Node<
  PatternTrafficWalkingNodeData,
  Record<string, never>,
  "traffic-walking"
>;
type PatternFlowNode =
  | PatternStationFlowNode
  | PatternCityZoneFlowNode
  | PatternTrafficMarkerFlowNode
  | PatternTrafficMarkerConnectorFlowNode
  | PatternTrafficWalkingFlowNode;
type PatternFlowEdge = Edge<
  PatternFlowEdgeData,
  Record<string, never>,
  PatternFlowEdgeType
>;
type PatternFlowEdgeType = "straight" | "default";

interface PatternStationNodeData {
  key: string;
  label: string;
  city?: string;
  cityNode: boolean;
  mixedServed: boolean;
  layoutX: number;
  layoutY: number;
  nodeX: number;
  nodeY: number;
  time?: string;
  current: boolean;
  served: boolean;
  branchEnd: boolean;
  branchChip?: string;
  busTransfers: TransferLineOption[];
  nonBusTransfers: TransferLineOption[];
  transfers: TransferLineOption[];
  trafficImpact?: PatternTrafficImpact;
}

interface PatternCityZoneNodeData {
  key: string;
  city: string;
  width: number;
  stationCount: number;
  layoutX: number;
  layoutY: number;
  nodeX: number;
  nodeY: number;
}

interface PatternTrafficMarkerNodeData {
  key: string;
  kind: PatternTrafficImpact["kind"];
  markerHeight: number;
  placement: "above" | "below";
  pulseStationKeys: string[];
  statusLabel: string;
  detailLabel?: string;
  replacementBus: boolean;
  trafficImpact: PatternTrafficImpact;
}

interface PatternTrafficMarkerConnectorNodeData {
  connectorAngle: number;
  connectorHeight: number;
  connectorLength: number;
  connectorOffset: number;
  key: string;
  kind: PatternTrafficImpact["kind"];
  markerHeight: number;
  markerWidth: number;
  placement: "above" | "below";
}

interface PatternTrafficWalkingNodeData {
  durationLabel: string;
  edgeKey: string;
}

interface PatternFlowEdgeData {
  trafficImpact?: PatternTrafficImpact;
}

type PatternVisualMode = "comfort" | "compact" | "realistic" | "cities";
type PatternCompactMode =
  | "auto"
  | Exclude<PatternVisualMode, "cities">;

interface PatternGraphNode {
  id: string;
  label: string;
  city?: string;
  lon?: number;
  lat?: number;
  coordinatePriority: number;
  current: boolean;
  served: boolean;
  time?: string;
  transfers: TransferLineOption[];
  degree: number;
}

interface PatternGraphEdge {
  id: string;
  source: string;
  target: string;
  active: boolean;
  distanceKm?: number;
}

interface PatternCityGroup {
  key: string;
  internalLabel: string;
  label: string;
  city?: string;
  sourceKeys: string[];
  current: boolean;
  served: boolean;
  mixedServed: boolean;
  time?: string;
  transfers: TransferLineOption[];
  lon?: number;
  lat?: number;
  coordinatePriority: number;
}

interface PatternCityCompression {
  graph: {
    nodes: PatternGraphNode[];
    edges: PatternGraphEdge[];
  };
  calls: DepartureCall[];
  lineTopology: LineRouteSequence[];
  lineTopologyLayout?: LineTopologyLayout;
  displayKeyBySourceKey: Map<string, string>;
  cityNodeKeys: Set<string>;
  mixedServedKeys: Set<string>;
}

interface PatternLoopLayoutHint {
  id: string;
  kind: LineTopologyLoopLayout["kind"];
  role?: "common" | "alternative";
  side?: "upper" | "lower" | "center";
  stationKeys: string[];
  anchorKeys: string[];
  lane: number;
  explicitLane?: boolean;
}

interface PatternFlowModel {
  nodes: PatternFlowNode[];
  stationNodes: PatternStationFlowNode[];
  edges: PatternFlowEdge[];
  trafficEdges: PatternTrafficEdge[];
  trafficSourceEdges: PatternTrafficEdge[];
  trafficPositions: Map<string, PatternLayoutPosition>;
  trafficStations: PatternTrafficStation[];
  trafficSourceStations: PatternTrafficStation[];
  trafficAnalysis: PatternTrafficImpactAnalysis;
  displayKeyBySourceKey: Map<string, string>;
}

interface PatternCityZoneGroup {
  city: string;
  stationKeys: string[];
}

interface PatternViewport {
  x: number;
  y: number;
  zoom: number;
}

interface PatternFlowViewportController {
  fitView?: (options?: { duration?: number; padding?: number }) => unknown;
  setViewport?: (
    viewport: PatternViewport,
    options?: { duration?: number },
  ) => unknown;
}

interface PatternViewportPoint {
  x: number;
  y: number;
}

interface PatternViewportSize {
  width: number;
  height: number;
}

interface PatternTopologyLayout {
  degrees: Map<string, number>;
  positions: Map<string, { x: number; y: number }>;
  syntheticEdges: PatternGraphEdge[];
  visibleEdges: Set<string>;
}

type PatternLayoutPosition = { x: number; y: number };
type PatternPlacementProposal = {
  key: string;
  position: PatternLayoutPosition;
};
type InterpolatedPathLane = {
  baseY: number;
  initialLane: number;
  laneGap: number;
};

const REGULAR_NODE_WIDTH = 184;
const REGULAR_NODE_HEIGHT = 104;
const COMPACT_NODE_WIDTH = 128;
const COMPACT_NODE_HEIGHT = 150;
const COMFORT_STOP_GAP = 236;
const COMPACT_STOP_GAP = 138;
const MIN_STATION_LAYOUT_SEPARATION = 86;
const MAX_LAYOUT_LANE_COLLISION_ATTEMPTS = 12;
const DEFAULT_COMPACT_BRANCH_GAP = 258;
const DEFAULT_COMPACT_FORK_GAP = 158;
const DEFAULT_REALISTIC_MIN_STOP_GAP_COEFFICIENT = 0.5;
const DEFAULT_REALISTIC_MAX_STOP_GAP_COEFFICIENT = 5;
const MIN_COMPACT_BRANCH_GAP = 180;
const MAX_COMPACT_BRANCH_GAP = 360;
const MIN_COMPACT_FORK_GAP = 110;
const MAX_COMPACT_FORK_GAP = 260;
const MIN_REALISTIC_STOP_GAP_COEFFICIENT = 0.25;
const MAX_REALISTIC_MIN_STOP_GAP_COEFFICIENT = 1.25;
const MIN_REALISTIC_MAX_STOP_GAP_COEFFICIENT = 1.25;
const MAX_REALISTIC_STOP_GAP_COEFFICIENT = 8;
const DISTANCE_LABEL_EXIT_MS = 240;
const TRAFFIC_FOCUS_CAMERA_DURATION_MS = 620;
const TRAFFIC_FOCUS_PULSE_DELAY_MS = 500;
const TRAFFIC_FOCUS_PULSE_DURATION_MS = 900;
const TRAFFIC_FOCUS_PULSE_REPEAT_DELAY_MS = 1_500;
const TRANSFER_HYDRATION_STALLED_RETRY_MS = 30_000;
const TRANSFER_HYDRATION_RATE_LIMIT_CHECK_MS = 1_200;
const TRANSFER_HYDRATION_HEALTH_CHECK_TIMEOUT_MS = 2_500;
const REGULAR_STATION_RAIL_CENTER_Y = 17;
const REGULAR_TERMINAL_RAIL_CENTER_Y = 19;
const COMPACT_STATION_RAIL_CENTER_Y = 15;
const TRAFFIC_MARKER_CONNECTOR_Z_INDEX = 90;
const TRAFFIC_MARKER_CARD_Z_INDEX = 100;
const TRAFFIC_MARKER_HOVERED_CONNECTOR_Z_INDEX = 110;
type PatternSpacingOptions = {
  compactBranchGap: number;
  compactForkGap: number;
  realisticMinGapCoefficient: number;
  realisticMaxGapCoefficient: number;
};
type PatternLayoutOptions = {
  mode: PatternVisualMode;
  compact: boolean;
  nodeWidth: number;
  nodeHeight: number;
  stopGap: number;
  edgeGapByKey?: Map<string, number>;
  branchGap: number;
  sameDirectionForkGap: number;
  rankSeparator: number;
  nodeSeparator: number;
};

const PATTERN_VISUAL_MODE_OPTIONS: Array<{
  id: PatternVisualMode;
  label: string;
}> = [
  { id: "comfort", label: "Comfort view" },
  { id: "compact", label: "Compact view" },
  { id: "realistic", label: "Realistic view" },
  { id: "cities", label: "City view" },
];

const props = withDefaults(
  defineProps<{
    open: boolean;
    board?: TransitBoardConfig;
    departure?: Departure;
    pattern?: DepartureCallingPattern;
    loading?: boolean;
    error?: string;
    embedded?: boolean;
    wheelZoom?: boolean;
    fullLine?: boolean;
    directionOptions?: LinePatternDirectionOption[];
    selectedDirectionId?: string;
    showMiniMap?: boolean;
    showCityZones?: boolean;
    compactMode?: PatternCompactMode;
    patternRoundedCurves?: boolean;
    showInterruptionWalkingTimes?: boolean;
    unifyReplacementBusMarkers?: boolean;
    patternCompactBranchGap?: number;
    patternCompactForkGap?: number;
    patternRealisticMinGapCoefficient?: number;
    patternRealisticMaxGapCoefficient?: number;
    richTransferTooltips?: boolean;
    reduceMotion?: boolean;
    lineId?: string;
    smartTrafficDetection?: boolean;
    trafficCalendarImpactScope?: TrafficCalendarImpactScope;
    trafficWarningLookaheadDays?: number;
    trafficReport?: TrafficLineReport;
    transferBundleRetentionDays?: number;
    transferBundleRequestConcurrency?: number;
    transferBundleRequestSpacingMs?: number;
    transferBundleLocalCacheEnabled?: boolean;
    transferBundleBackendCacheEnabled?: boolean;
    transportType?: string;
    transferResolverMode?: TransferResolverMode;
  }>(),
  {
    showMiniMap: true,
    showCityZones: true,
    compactMode: "compact",
    patternRoundedCurves: false,
    showInterruptionWalkingTimes: true,
    unifyReplacementBusMarkers: true,
    patternCompactBranchGap: DEFAULT_COMPACT_BRANCH_GAP,
    patternCompactForkGap: DEFAULT_COMPACT_FORK_GAP,
    patternRealisticMinGapCoefficient:
      DEFAULT_REALISTIC_MIN_STOP_GAP_COEFFICIENT,
    patternRealisticMaxGapCoefficient:
      DEFAULT_REALISTIC_MAX_STOP_GAP_COEFFICIENT,
    richTransferTooltips: true,
    reduceMotion: false,
    smartTrafficDetection: true,
    trafficCalendarImpactScope: "all-impacts",
    trafficWarningLookaheadDays: 10,
    transferBundleLocalCacheEnabled: true,
    transferBundleBackendCacheEnabled: true,
    transferBundleRetentionDays: 15,
    transferBundleRequestConcurrency: 1,
    transferBundleRequestSpacingMs: 0,
    transferResolverMode: "auto",
  },
);

const emit = defineEmits<{
  close: [];
  directionChange: [directionId: string];
}>();
const { d, locale, t } = useI18n();
const { settings: appSettings } = useAppSettings();

const isPatternFlowFullscreen = ref(false);
const patternVisualMode = ref<PatternVisualMode>("compact");
const showPatternDistances = ref(false);
const patternDistanceLabelsVisible = ref(false);
const patternDistanceLabelsLeaving = ref(false);
const patternFlowShell = ref<HTMLElement>();
const patternFlowViewport = ref<PatternViewport>({ x: 0, y: 0, zoom: 1 });
const patternFlowViewportController = ref<PatternFlowViewportController>();
const patternFlowViewportSize = ref<PatternViewportSize>({
  width: 0,
  height: 0,
});
const trafficPulseStationKeys = ref<Set<string>>(new Set());
const hiddenTrafficMarkerKeys = ref<Set<string>>(new Set());
const hoveredTrafficMarkerKey = ref<string>();
const selectedTrafficDisruptionIds = ref<string[]>([]);
const selectedTrafficTimestamp = ref<number>();
const hydratedPattern = ref<DepartureCallingPattern>();
const infoCardsDebugEnabled = ref(false);
const infoCardsDebugOutput = ref("");
const transferHydrationLoading = ref(false);
const transferHydrationProgress = ref<PatternTransferHydrationProgress>({
  completed: 0,
  failed: 0,
  pending: 0,
  total: 0,
});
const transferHydrationRetryVisible = ref(false);
const transferHydrationRateLimited = ref(false);
const forceFreshTransferHydration = ref(false);
const activeStationTooltipKey = ref<string>();
let transferHydrationRequest = 0;
let patternDistanceLabelHideTimer: number | undefined;
let transferHydrationRateLimitTimer: number | undefined;
let transferHydrationStalledTimer: number | undefined;
let visualModeDecisionKey = "";
let stationTooltipHideTimer: number | undefined;
let trafficFocusTimer: number | undefined;
let trafficFocusTimerResolve: (() => void) | undefined;
let trafficPulseClearTimer: number | undefined;
let trafficFocusRequest = 0;
const missingNetexTownWarningKeys = new Set<string>();
const departurePatternModalInfoCardsDebugTools =
  createDeparturePatternModalInfoCardsDebugTools(
    createInfoCardsDebugSnapshot,
  );

const serviceLabel = computed(() =>
  displayPattern.value
    ? formatServiceType(displayPattern.value.serviceType)
    : t("pattern.service"),
);
const patternVisualModeOptions = computed(() =>
  PATTERN_VISUAL_MODE_OPTIONS.map((option) => ({
    id: option.id,
    label:
      option.id === "comfort"
        ? t("settings.options.compactLinePlan.comfort")
        : option.id === "compact"
          ? t("settings.options.compactLinePlan.compact")
          : option.id === "realistic"
            ? t("settings.options.compactLinePlan.realistic")
            : t("pattern.cityView"),
  })),
);

const transferHydrationProgressPercent = computed(() => {
  const total = transferHydrationProgress.value.total;

  if (total <= 0) {
    return 0;
  }

  return Math.min(
    100,
    Math.max(0, (transferHydrationProgress.value.completed / total) * 100),
  );
});

const transferHydrationProgressLabel = computed(() => {
  const total = transferHydrationProgress.value.total;

  if (total <= 0) {
    return t("pattern.preparing");
  }

  return `${transferHydrationProgress.value.completed}/${total}`;
});
const transferHydrationStatusLabel = computed(() =>
  transferHydrationRateLimited.value
    ? t("pattern.apiRateLimit")
    : transferHydrationRetryVisible.value
      ? t("pattern.transfersBlocked")
      : t("pattern.loadingTransfers"),
);
const transferHydrationDetailLabel = computed(() =>
  transferHydrationRateLimited.value
    ? t("pattern.transfersTemporarilyUnavailable")
    : transferHydrationProgressLabel.value,
);
const servedCalls = computed(
  () => displayPattern.value?.calls.filter((call) => call.served) ?? [],
);
const destinationLabel = computed(
  () =>
    props.departure?.destination ??
    displayPattern.value?.destination ??
    t("pattern.destination"),
);
const hasDirectionPicker = computed(
  () => props.embedded && (props.directionOptions?.length ?? 0) > 1,
);
const isFullLineMode = computed(() =>
  Boolean(props.embedded && props.fullLine),
);
const departureClock = computed(() =>
  formatClock(departureTime(props.departure)),
);
const servedStopsLabel = computed(() => {
  if (isFullLineMode.value) {
    return t("pattern.fullLine");
  }

  const count = servedCalls.value.length;

  return count > 1
    ? t("pattern.servedStopsOther", { count })
    : t("pattern.servedStopsOne", { count });
});
const displayPattern = computed(() => hydratedPattern.value ?? props.pattern);
const topologyStationCount = computed(() =>
  countPatternTopologyStations(displayPattern.value?.lineTopology ?? []),
);

watch(
  () => ({
    departureId: displayPattern.value?.departureId,
    lineTopology: displayPattern.value?.lineTopology,
    showCityZones: props.showCityZones,
  }),
  () => {
    warnMissingNetexTown(
      displayPattern.value,
      props.showCityZones && patternVisualMode.value !== "cities",
    );
  },
  { immediate: true },
);

const isComfortPatternFlow = computed(
  () => patternVisualMode.value === "comfort",
);
const isCompactPatternFlow = computed(
  () => patternVisualMode.value === "compact",
);
const isRealisticPatternFlow = computed(
  () => patternVisualMode.value === "realistic",
);
const isCitiesPatternFlow = computed(
  () => patternVisualMode.value === "cities",
);
const usesCompactPatternFlowLayout = computed(
  () =>
    patternVisualMode.value === "compact" ||
    patternVisualMode.value === "realistic" ||
    patternVisualMode.value === "cities",
);
const currentLayoutOptions = computed(() =>
  createPatternLayoutOptions(patternVisualMode.value),
);
const patternSpacingKey = computed(() => {
  const spacing = getPatternSpacingOptions();

  return [
    spacing.compactBranchGap,
    spacing.compactForkGap,
    spacing.realisticMinGapCoefficient,
    spacing.realisticMaxGapCoefficient,
  ].join(":");
});
const shouldZoomOnWheel = computed(() => Boolean(props.wheelZoom));
const currentLineIdentity = computed<CurrentLineIdentity | undefined>(() => {
  const board = props.board;

  if (!board) {
    return undefined;
  }

  return {
    family: transitModeToFamily(board.line.mode),
    ids: [board.schedule?.lineRef, board.line.ref, props.departure?.lineRef],
    labels: [board.line.shortName, board.line.longName],
  };
});
const {
  activeTrafficImpact,
  analyzeCurrentTrafficImpacts,
  closeTrafficImpactPopup,
  resolvedTrafficReport,
  showTrafficImpactPopup,
  trafficTimingNow,
  trafficImpactKey,
} = useDeparturePatternTraffic({
  open: computed(() => props.open),
  board: computed(() => props.board),
  smartTrafficDetection: computed(() => props.smartTrafficDetection),
  trafficReport: computed(() => props.trafficReport),
  includeUpcomingWarnings: computed(() => false),
  selectedTrafficDisruptionIds: computed(
    () => selectedTrafficDisruptionIds.value,
  ),
  trafficEvaluationTimestamp: computed(() => selectedTrafficTimestamp.value),
  warningLookaheadDays: computed(() => props.trafficWarningLookaheadDays),
});
const transportModeIcon = computed(() =>
  createTransportModeIcon(props.board?.line.mode),
);
const flowModel = computed(() =>
  createPatternFlow(
    displayPattern.value?.calls ?? [],
    displayPattern.value?.lineTopology ?? [],
    displayPattern.value?.lineTopologyLayout,
    departureClock.value,
    patternVisualMode.value,
    isFullLineMode.value,
    currentLineIdentity.value,
    patternDistanceLabelsVisible.value,
    patternDistanceLabelsLeaving.value,
    props.showCityZones,
    props.patternRoundedCurves,
    props.showInterruptionWalkingTimes,
    props.unifyReplacementBusMarkers,
    analyzeCurrentTrafficImpacts,
  ),
);
const topologyStationKeyById = computed(() => {
  const keys = new Map<string, string>();

  for (const sequence of displayPattern.value?.lineTopology ?? []) {
    for (const stop of sequence.stops) {
      const stationKey = createStationKey(stop);
      const displayKey =
        flowModel.value.displayKeyBySourceKey.get(stationKey) ?? stationKey;

      [stop.id, stop.station.id, stop.station.scheduleStopAreaRef]
        .filter((value): value is string => Boolean(value))
        .forEach((value) => keys.set(value, displayKey));
    }
  }

  return keys;
});
const vehicleRailPositions = computed(() => {
  const compact = usesCompactPatternFlowLayout.value;

  return new Map(
    flowModel.value.stationNodes.map((node) => [
      node.id,
      {
        x:
          node.data?.layoutX ??
          node.position.x + currentLayoutOptions.value.nodeWidth / 2,
        y:
          node.position.y +
          (compact
            ? COMPACT_STATION_RAIL_CENTER_Y
            : node.data?.branchEnd
              ? REGULAR_TERMINAL_RAIL_CENTER_Y
              : REGULAR_STATION_RAIL_CENTER_Y),
      },
    ]),
  );
});
const patternPluginExtensions = transportClockPlugins.flatMap((plugin) => {
  const definition = plugin.servicePattern;
  if (!definition) {
    return [];
  }
  const enabled = computed(
    () =>
      appSettings.value.plugins[plugin.id]?.enabled ?? plugin.defaultEnabled,
  );
  const extension = definition.setup({
    active: computed(
      () =>
        props.open &&
        enabled.value &&
        Boolean(displayPattern.value?.lineTopology?.length),
    ),
    destinationLabel,
    fallbackVehicleLabel: computed(() => transportModeIcon.value.label),
    formatClock,
    isSegmentVisible(sourceId, targetId) {
      if (sourceId === targetId) {
        return true;
      }
      const sourceDisplayKey =
        topologyStationKeyById.value.get(sourceId) ??
        flowModel.value.displayKeyBySourceKey.get(sourceId) ??
        sourceId;
      const targetDisplayKey =
        topologyStationKeyById.value.get(targetId) ??
        flowModel.value.displayKeyBySourceKey.get(targetId) ??
        targetId;
      const edgeKey = createEdgeKey(sourceDisplayKey, targetDisplayKey);
      return flowModel.value.trafficEdges.some(
        (edge) => createEdgeKey(edge.source, edge.target) === edgeKey,
      );
    },
    line: computed(() => ({
      id: props.lineId ?? props.board?.line.shortName ?? props.board?.line.ref,
      mode: props.board?.line.mode,
      ref: props.board?.line.ref,
      shortName: props.board?.line.shortName,
      transportType: props.transportType,
    })),
    patternRoundedCurves: computed(() => props.patternRoundedCurves),
    reduceMotion: computed(() => props.reduceMotion),
    resolveServerApiUrl: toServerApiUrl,
    resolveStationKey(stationId) {
      const sourceKey = topologyStationKeyById.value.get(stationId);
      const displayKey = sourceKey
        ? flowModel.value.displayKeyBySourceKey.get(sourceKey) ?? sourceKey
        : undefined;

      return (
        displayKey ??
        (vehicleRailPositions.value.has(stationId) ? stationId : undefined)
      );
    },
    settings: computed(
      () =>
        appSettings.value.plugins[plugin.id]?.value ??
        plugin.settings?.defaultValue,
    ),
    stationPositions: vehicleRailPositions,
    t: (key, params) =>
      translatePluginMessage(plugin, locale.value, key, params),
  });
  return [{ enabled, extension, plugin }];
});
const pluginFlowNodes = computed<Node[]>(() =>
  patternPluginExtensions.flatMap(({ enabled, extension }) =>
    enabled.value ? extension.nodes.value : [],
  ),
);
const pluginNodeTypes = computed(() =>
  Object.assign(
    {},
    ...patternPluginExtensions.map(({ extension }) => extension.nodeTypes),
  ),
);
const pluginStatuses = computed(() =>
  patternPluginExtensions.flatMap(({ enabled, extension }) => {
    const status = enabled.value ? extension.status?.value : undefined;
    return status ? [status] : [];
  }),
);
const allFlowNodes = computed<Node[]>(() =>
  [...flowModel.value.nodes, ...pluginFlowNodes.value].map((node) => {
    if (node.type === "traffic-marker") {
      return { ...node, zIndex: TRAFFIC_MARKER_CARD_Z_INDEX };
    }

    if (node.type === "traffic-marker-connector") {
      return {
        ...node,
        zIndex:
          node.data.key === hoveredTrafficMarkerKey.value
            ? TRAFFIC_MARKER_HOVERED_CONNECTOR_Z_INDEX
            : TRAFFIC_MARKER_CONNECTOR_Z_INDEX,
      };
    }

    return node;
  }),
);
const {
  calendar: trafficCalendar,
  close: closeTrafficCalendar,
  closeExpanded: closeExpandedTrafficCalendar,
  eventCount: trafficCalendarEventCount,
  expand: expandTrafficCalendar,
  expanded: trafficCalendarExpanded,
  hasNext: hasNextTrafficCalendarMonth,
  hasPrevious: hasPreviousTrafficCalendarMonth,
  loadingDateKey: trafficCalendarLoadingDateKey,
  loadingDirection: trafficCalendarLoadingDirection,
  nextDelayLabel: trafficCalendarNextDelayLabel,
  nextMonth: selectNextTrafficCalendarMonth,
  open: trafficCalendarOpen,
  previousMonth: selectPreviousTrafficCalendarMonth,
  resetToday: resetPatternTrafficCalendarToday,
  selectDay: selectPatternTrafficCalendarDay,
  selectedDateKey: selectedTrafficCalendarDateKey,
  selectedDay: selectedTrafficCalendarDay,
  selectedDisruptions: selectedTrafficCalendarDisruptions,
  toggle: toggleTrafficCalendar,
} = usePatternTrafficCalendar({
  report: computed(() =>
    props.smartTrafficDetection ? resolvedTrafficReport.value : undefined,
  ),
  stations: computed(() => flowModel.value.trafficSourceStations),
  edges: computed(() => flowModel.value.trafficSourceEdges),
  impactScope: computed(() => props.trafficCalendarImpactScope),
  now: trafficTimingNow,
  reduceMotion: computed(() => props.reduceMotion),
  selectedDisruptionIds: selectedTrafficDisruptionIds,
  selectedTimestamp: selectedTrafficTimestamp,
});

const patternFlowKey = computed(
  () =>
    `${displayPattern.value?.departureId ?? "empty"}:${
      isPatternFlowFullscreen.value ? "fullscreen" : "modal"
    }:${patternVisualMode.value}:${
      isFullLineMode.value ? "full" : "route"
    }:${props.showCityZones ? "cities" : "no-cities"}:curves:${
      props.patternRoundedCurves ? "rounded" : "straight"
    }:spacing:${patternSpacingKey.value}${
      props.board?.line.mode ? `:${props.board.line.mode}` : ""
    }:traffic:${props.smartTrafficDetection ? trafficImpactKey.value : "off"}:bus-markers:${
      props.unifyReplacementBusMarkers ? "unified" : "separate"
    }`,
);
const initialViewport = computed(() => {
  const currentNode =
    flowModel.value.stationNodes.find((node) => node.data?.current) ??
    flowModel.value.stationNodes.find((node) => node.data?.served) ??
    flowModel.value.stationNodes[0];
  const nodeCount = flowModel.value.stationNodes.length;
  const layout = currentLayoutOptions.value;
  const zoom = createInitialZoom({
    fullscreen: isPatternFlowFullscreen.value,
    compact: usesCompactPatternFlowLayout.value,
    nodeCount,
  });
  const center = isPatternFlowFullscreen.value
    ? { x: 560, y: 360 }
    : { x: 280, y: 230 };

  if (!currentNode) {
    return {
      x: isPatternFlowFullscreen.value ? 72 : 24,
      y: isPatternFlowFullscreen.value ? 240 : 160,
      zoom,
    };
  }

  return {
    x: center.x - (currentNode.position.x + layout.nodeWidth / 2) * zoom,
    y: center.y - (currentNode.position.y + layout.nodeHeight / 2) * zoom,
    zoom,
  };
});

watch(
  initialViewport,
  (viewport) => {
    patternFlowViewport.value = {
      x: viewport.x,
      y: viewport.y,
      zoom: viewport.zoom,
    };
  },
  { immediate: true },
);

watch(showPatternDistances, (visible) => {
  clearPatternDistanceLabelHideTimer();

  if (visible) {
    patternDistanceLabelsVisible.value = true;
    patternDistanceLabelsLeaving.value = false;
    return;
  }

  if (!patternDistanceLabelsVisible.value) {
    return;
  }

  if (props.reduceMotion || typeof window === "undefined") {
    patternDistanceLabelsVisible.value = false;
    patternDistanceLabelsLeaving.value = false;
    return;
  }

  patternDistanceLabelsLeaving.value = true;
  patternDistanceLabelHideTimer = window.setTimeout(() => {
    patternDistanceLabelHideTimer = undefined;
    patternDistanceLabelsVisible.value = false;
    patternDistanceLabelsLeaving.value = false;
  }, DISTANCE_LABEL_EXIT_MS);
});

watch(
  patternFlowShell,
  (element, _previousElement, onCleanup) => {
    if (!element || typeof ResizeObserver === "undefined") {
      return;
    }

    const resizeObserver = new ResizeObserver(syncPatternFlowViewportSize);

    resizeObserver.observe(element);
    void nextTick(syncPatternFlowViewportSize);

    onCleanup(() => {
      resizeObserver.disconnect();
    });
  },
  { flush: "post" },
);

watch(
  () =>
    `${displayPattern.value?.departureId ?? "empty"}:${topologyStationCount.value}:${props.compactMode}`,
  (key) => {
    if (key === visualModeDecisionKey) {
      return;
    }

    visualModeDecisionKey = key;
    patternVisualMode.value = resolveInitialPatternVisualMode();
  },
  { immediate: true },
);

function resolveInitialPatternVisualMode(): PatternVisualMode {
  if (props.compactMode === "compact") {
    return "compact";
  }

  if (props.compactMode === "comfort") {
    return "comfort";
  }

  if (props.compactMode === "realistic") {
    return "realistic";
  }

  return "compact";
}

function createPatternLayoutOptions(
  mode: PatternVisualMode,
): PatternLayoutOptions {
  const spacing = getPatternSpacingOptions();

  return mode === "compact" || mode === "realistic" || mode === "cities"
    ? {
        mode,
        compact: true,
        nodeWidth: COMPACT_NODE_WIDTH,
        nodeHeight: COMPACT_NODE_HEIGHT,
        stopGap: mode === "realistic" ? COMFORT_STOP_GAP : COMPACT_STOP_GAP,
        branchGap: spacing.compactBranchGap,
        sameDirectionForkGap: spacing.compactForkGap,
        rankSeparator: 116,
        nodeSeparator: 46,
      }
    : {
        mode,
        compact: false,
        nodeWidth: REGULAR_NODE_WIDTH,
        nodeHeight: REGULAR_NODE_HEIGHT,
        stopGap: COMFORT_STOP_GAP,
        branchGap: 184,
        sameDirectionForkGap: 184 * 0.58,
        rankSeparator: 96,
        nodeSeparator: 54,
      };
}

function createResolvedPatternLayoutOptions(
  mode: PatternVisualMode,
  edges: PatternGraphEdge[],
): PatternLayoutOptions {
  const layout = createPatternLayoutOptions(mode);

  if (mode !== "realistic") {
    return layout;
  }

  return {
    ...layout,
    edgeGapByKey: createRealisticEdgeGapByKey(
      edges,
      getPatternSpacingOptions(),
    ),
  };
}

function createRealisticEdgeGapByKey(
  edges: PatternGraphEdge[],
  spacing: PatternSpacingOptions,
): Map<string, number> {
  const distances = edges
    .map((edge) => edge.distanceKm)
    .filter(isPositiveFiniteNumber)
    .sort((left, right) => left - right);

  if (distances.length < 2) {
    return new Map();
  }

  const medianDistance = getSortedMedian(distances);

  if (!isPositiveFiniteNumber(medianDistance)) {
    return new Map();
  }

  return new Map(
    edges.flatMap((edge): Array<[string, number]> => {
      if (!isPositiveFiniteNumber(edge.distanceKm)) {
        return [];
      }

      const gap = clampNumber(
        (edge.distanceKm / medianDistance) * COMFORT_STOP_GAP,
        COMFORT_STOP_GAP * spacing.realisticMinGapCoefficient,
        COMFORT_STOP_GAP * spacing.realisticMaxGapCoefficient,
      );

      return [[createEdgeKey(edge.source, edge.target), gap]];
    }),
  );
}

function getSortedMedian(values: number[]): number {
  if (values.length === 0) {
    return values[0] ?? 0;
  }

  const middleIndex = Math.floor(values.length / 2);

  if (values.length % 2 === 1) {
    return values[middleIndex] ?? 0;
  }

  return ((values[middleIndex - 1] ?? 0) + (values[middleIndex] ?? 0)) / 2;
}

function isPositiveFiniteNumber(value: unknown): value is number {
  return typeof value === "number" && Number.isFinite(value) && value > 0;
}

function clampNumber(value: number, min: number, max: number): number {
  return Math.min(max, Math.max(min, value));
}

function selectPatternVisualMode(mode: string): void {
  if (isPatternVisualMode(mode)) {
    patternVisualMode.value = mode;
  }
}

function isPatternVisualMode(value: string): value is PatternVisualMode {
  return (
    value === "comfort" ||
    value === "compact" ||
    value === "realistic" ||
    value === "cities"
  );
}

function createInitialZoom({
  fullscreen,
  compact,
  nodeCount,
}: {
  fullscreen: boolean;
  compact: boolean;
  nodeCount: number;
}): number {
  if (fullscreen) {
    if (nodeCount > 64) {
      return compact ? 0.68 : 0.58;
    }

    if (nodeCount > 42) {
      return compact ? 0.78 : 0.66;
    }

    return compact ? 0.96 : 0.92;
  }

  if (nodeCount > 64) {
    return compact ? 0.5 : 0.42;
  }

  if (nodeCount > 42) {
    return compact ? 0.6 : 0.5;
  }

  return compact ? 0.82 : 0.78;
}

function handlePatternFlowReady(instance: PatternFlowViewportController): void {
  patternFlowViewportController.value = instance;
  void nextTick(syncPatternFlowViewportSize);
}

function handlePatternFlowViewportChange(viewport: PatternViewport): void {
  patternFlowViewport.value = {
    x: viewport.x,
    y: viewport.y,
    zoom: viewport.zoom,
  };
}

function syncPatternFlowViewportSize(): void {
  const flowElement =
    patternFlowShell.value?.querySelector<HTMLElement>(".pattern-flow") ??
    patternFlowShell.value;

  if (!flowElement) {
    return;
  }

  patternFlowViewportSize.value = {
    width: flowElement.clientWidth,
    height: flowElement.clientHeight,
  };
}

function focusPatternFlowOn(
  point: PatternViewportPoint,
  preferredZoom?: number,
): void {
  const zoom = preferredZoom ?? patternFlowViewport.value.zoom;
  const viewport = {
    x: patternFlowViewportSize.value.width / 2 - point.x * zoom,
    y: patternFlowViewportSize.value.height / 2 - point.y * zoom,
    zoom,
  };

  patternFlowViewport.value = viewport;
  patternFlowViewportController.value?.setViewport?.(viewport, {
    duration: 220,
  });
}

async function selectTrafficCalendarDay(
  day: PatternTrafficCalendarDay,
): Promise<void> {
  const selection = await selectPatternTrafficCalendarDay(day);
  if (!selection) return;
  closeTrafficImpactPopup();
  focusTrafficCalendarSelection();
}

async function resetTrafficCalendarToday(): Promise<void> {
  await resetPatternTrafficCalendarToday();
  closeTrafficImpactPopup();
  patternFlowViewportController.value?.fitView?.({
    duration: 240,
    padding: 0.16,
  });
}

function focusTrafficCalendarSelection(): void {
  const selectedDay = selectedTrafficCalendarDay.value;
  const selectedIds = new Set(
    (selectedDay?.events ?? []).map((event) => event.disruption.id),
  );
  const selectedSegments = flowModel.value.trafficAnalysis.segments.filter(
    (segment) => selectedIds.has(segment.disruption.id),
  );
  const interruptedSegments = selectedSegments.filter(
    (segment) => segment.kind === "interruption",
  );
  const focusSegments =
    interruptedSegments.length > 0 ? interruptedSegments : selectedSegments;

  if (focusSegments.length !== 1) {
    patternFlowViewportController.value?.fitView?.({
      duration: 260,
      padding: 0.18,
    });
    return;
  }

  const focusPoint = getTrafficSegmentFocusPoint(focusSegments[0]);
  if (focusPoint) {
    focusPatternFlowOn(focusPoint, getTrafficCalendarFocusZoom());
  }
}

async function focusTrafficDisruption(
  entry: PatternTrafficSummaryEntry,
): Promise<void> {
  const disruptionIds = new Set(entry.disruptionIds);
  const segments = flowModel.value.trafficAnalysis.segments.filter((segment) =>
    disruptionIds.has(segment.disruption.id),
  );
  await focusTrafficStationKeys(getTrafficFocusStationKeys(segments), 2);
}

function focusTrafficMarker(stationKeys: string[]): void {
  void focusTrafficStationKeys(stationKeys, 3);
}

function hoverTrafficMarker(key: string): void {
  hoveredTrafficMarkerKey.value = key;
}

function unhoverTrafficMarker(key: string): void {
  if (hoveredTrafficMarkerKey.value === key) {
    hoveredTrafficMarkerKey.value = undefined;
  }
}

async function focusTrafficStationKeys(
  stationKeys: string[],
  pulseCount: number,
): Promise<void> {
  const viewport = createTrafficFocusViewport(stationKeys);
  const controller = patternFlowViewportController.value;

  if (!controller?.setViewport || !viewport || stationKeys.length === 0) return;

  trafficFocusRequest += 1;
  const request = trafficFocusRequest;
  resetTrafficFocusTimers();
  closeTrafficImpactPopup();

  const duration = props.reduceMotion ? 0 : TRAFFIC_FOCUS_CAMERA_DURATION_MS;
  patternFlowViewport.value = viewport;
  const transition = controller.setViewport(viewport, { duration });

  if (isPromiseLike(transition)) {
    await transition;
  } else {
    await waitForTrafficFocus(duration);
  }
  if (request !== trafficFocusRequest) return;

  for (let pulseIndex = 0; pulseIndex < pulseCount; pulseIndex += 1) {
    await waitForTrafficFocus(
      pulseIndex === 0
        ? TRAFFIC_FOCUS_PULSE_DELAY_MS
        : TRAFFIC_FOCUS_PULSE_REPEAT_DELAY_MS,
    );
    if (request !== trafficFocusRequest) return;
    pulseStations(stationKeys);
  }
}

function pulseStations(stations: string[]): void {
  const request = trafficFocusRequest;

  if (trafficPulseClearTimer !== undefined && typeof window !== "undefined") {
    window.clearTimeout(trafficPulseClearTimer);
  }

  trafficPulseStationKeys.value = new Set(stations);
  if (typeof window === "undefined") return;

  trafficPulseClearTimer = window.setTimeout(() => {
    if (request === trafficFocusRequest) {
      trafficPulseStationKeys.value = new Set();
    }
    trafficPulseClearTimer = undefined;
  }, TRAFFIC_FOCUS_PULSE_DURATION_MS);
}

function getTrafficFocusStationKeys(
  segments: PatternTrafficImpactSegment[],
  positions: Map<string, PatternLayoutPosition> =
    flowModel.value?.trafficPositions,
): string[] {
  return getTrafficMarkerPulseStationKeys(segments).filter((stationKey) =>
    positions?.has(stationKey),
  );
}

function createTrafficFocusViewport(
  stationKeys: string[],
): PatternViewport | undefined {
  syncPatternFlowViewportSize();
  const points = stationKeys
    .map((stationKey) => flowModel.value.trafficPositions.get(stationKey))
    .filter((point): point is PatternLayoutPosition => Boolean(point));
  const measuredViewport = patternFlowViewportSize.value;
  const width =
    measuredViewport.width ||
    (isPatternFlowFullscreen.value && typeof window !== "undefined"
      ? window.innerWidth
      : 960);
  const height =
    measuredViewport.height ||
    (isPatternFlowFullscreen.value && typeof window !== "undefined"
      ? window.innerHeight
      : 470);

  if (points.length === 0) return undefined;

  const minX = Math.min(...points.map((point) => point.x));
  const maxX = Math.max(...points.map((point) => point.x));
  const minY = Math.min(...points.map((point) => point.y));
  const maxY = Math.max(...points.map((point) => point.y));
  const layout = currentLayoutOptions.value;
  const boundsWidth = Math.max(
    layout.nodeWidth,
    maxX - minX + layout.nodeWidth,
  );
  const boundsHeight = Math.max(
    layout.nodeHeight,
    maxY - minY + layout.nodeHeight,
  );
  const paddingX = Math.min(180, width * 0.2);
  const paddingY = Math.min(130, height * 0.2);
  const fitZoom = Math.min(
    (width - paddingX * 2) / boundsWidth,
    (height - paddingY * 2) / boundsHeight,
  );
  const minimumZoom = isPatternFlowFullscreen.value ? 0.56 : 0.48;
  const zoom =
    points.length === 1
      ? getTrafficCalendarFocusZoom()
      : Math.min(1.08, Math.max(minimumZoom, fitZoom));
  const centerX = (minX + maxX) / 2;
  const centerY = (minY + maxY) / 2;

  return {
    x: width / 2 - centerX * zoom,
    y: height / 2 - centerY * zoom,
    zoom,
  };
}

function isPromiseLike(value: unknown): value is PromiseLike<unknown> {
  return (
    (typeof value === "object" || typeof value === "function") &&
    value !== null &&
    "then" in value
  );
}

function waitForTrafficFocus(duration: number): Promise<void> {
  if (duration <= 0 || typeof window === "undefined") return Promise.resolve();

  return new Promise((resolve) => {
    trafficFocusTimerResolve = resolve;
    trafficFocusTimer = window.setTimeout(() => {
      trafficFocusTimer = undefined;
      trafficFocusTimerResolve = undefined;
      resolve();
    }, duration);
  });
}

function resetTrafficFocusTimers(): void {
  if (trafficFocusTimer !== undefined && typeof window !== "undefined") {
    window.clearTimeout(trafficFocusTimer);
    trafficFocusTimer = undefined;
  }
  const resolve = trafficFocusTimerResolve;
  trafficFocusTimerResolve = undefined;
  resolve?.();

  if (trafficPulseClearTimer !== undefined && typeof window !== "undefined") {
    window.clearTimeout(trafficPulseClearTimer);
    trafficPulseClearTimer = undefined;
  }
  trafficPulseStationKeys.value = new Set();
}
function getTrafficSegmentFocusPoint(
  segment: PatternTrafficImpactSegment,
): PatternViewportPoint | undefined {
  const stationPoints = segment.stationKeys
    .map((stationKey) => flowModel.value.trafficPositions.get(stationKey))
    .filter((point): point is PatternLayoutPosition => Boolean(point));
  const points =
    stationPoints.length > 0
      ? stationPoints
      : getTrafficEdgeFocusPoints(segment);

  if (points.length === 0) {
    return undefined;
  }

  return {
    x: points.reduce((sum, point) => sum + point.x, 0) / points.length,
    y: points.reduce((sum, point) => sum + point.y, 0) / points.length,
  };
}

function getTrafficEdgeFocusPoints(
  segment: PatternTrafficImpactSegment,
): PatternLayoutPosition[] {
  return segment.edgeKeys.flatMap((edgeKey) => {
    const [source, target] = edgeKey.split("--");

    return [source, target]
      .map((stationKey) =>
        stationKey
          ? flowModel.value.trafficPositions.get(stationKey)
          : undefined,
      )
      .filter((point): point is PatternLayoutPosition => Boolean(point));
  });
}

function getTrafficCalendarFocusZoom(): number {
  const currentZoom = patternFlowViewport.value.zoom;
  const minimumZoom = isPatternFlowFullscreen.value ? 0.78 : 0.72;

  return Math.min(1.08, Math.max(currentZoom, minimumZoom));
}

function handlePatternEdgeClick(event: {
  edge?: { data?: PatternFlowEdgeData };
}): void {
  showTrafficImpactPopup(event.edge?.data?.trafficImpact);
}

function hideTrafficMarker(key: string): void {
  hiddenTrafficMarkerKeys.value = new Set([
    ...hiddenTrafficMarkerKeys.value,
    key,
  ]);
}

function formatClock(value?: string): string {
  if (!value) {
    return "";
  }

  return d(new Date(value), {
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "Europe/Paris",
  });
}

function formatServiceType(type: DepartureServiceType): string {
  if (type === "semi-direct") {
    return t("board.serviceType.semiDirect");
  }

  if (type === "direct") {
    return t("board.serviceType.direct");
  }

  if (type === "omnibus") {
    return t("board.serviceType.omnibus");
  }

  return t("pattern.service");
}

function departureTime(departure?: Departure): string | undefined {
  return (
    departure?.expectedDepartureTime ??
    departure?.expectedArrivalTime ??
    departure?.aimedDepartureTime
  );
}

watch(
  [
    () => props.open,
    () => props.board?.id,
    () => props.pattern?.departureId,
    () => props.transportType,
    () => props.transferResolverMode,
    () => props.transferBundleRetentionDays,
    () => props.transferBundleLocalCacheEnabled,
    () => props.transferBundleBackendCacheEnabled,
  ],
  () => {
    void hydratePatternTransfers();
  },
  { immediate: true },
);

async function hydratePatternTransfers(): Promise<void> {
  const requestId = ++transferHydrationRequest;
  const pattern = props.pattern;
  const board = props.board;
  const bypassBackendBundleCache = forceFreshTransferHydration.value;
  forceFreshTransferHydration.value = false;

  hydratedPattern.value = pattern;
  transferHydrationRetryVisible.value = false;
  transferHydrationRateLimited.value = false;
  transferHydrationProgress.value = {
    completed: 0,
    failed: 0,
    pending: 0,
    total: 0,
  };

  if (!props.open || !board || !pattern) {
    transferHydrationLoading.value = false;
    resetTransferHydrationStallState();
    clearTransferHydrationRateLimitTimer();
    return;
  }

  if (typeof window === "undefined") {
    transferHydrationLoading.value = false;
    resetTransferHydrationStallState();
    clearTransferHydrationRateLimitTimer();
    return;
  }

  transferHydrationLoading.value = true;
  syncTransferHydrationStallTimer(requestId);
  syncTransferHydrationRateLimitCheck(requestId);

  try {
    const enrichedPattern = await hydrateDeparturePatternTransfers(
      board,
      pattern,
      undefined,
      {
        onProgress(progress) {
          if (requestId === transferHydrationRequest) {
            transferHydrationProgress.value = progress;
            syncTransferHydrationStallTimer(requestId);
            syncTransferHydrationRateLimitCheck(requestId);
          }
        },
        localCacheEnabled: props.transferBundleLocalCacheEnabled,
        backendCacheEnabled:
          props.transferBundleBackendCacheEnabled && !bypassBackendBundleCache,
        retentionDays: props.transferBundleRetentionDays,
        transferBundleRequestConcurrency:
          props.transferBundleRequestConcurrency,
        transferBundleRequestSpacingMs: props.transferBundleRequestSpacingMs,
        transportType: props.transportType,
        transferResolverMode: props.transferResolverMode,
      },
    );

    if (requestId === transferHydrationRequest) {
      hydratedPattern.value = enrichedPattern;
    }
  } catch {
    if (requestId === transferHydrationRequest) {
      hydratedPattern.value = pattern;
    }
  } finally {
    if (requestId === transferHydrationRequest) {
      if (!transferHydrationRateLimited.value) {
        transferHydrationLoading.value = false;
        resetTransferHydrationStallState();
      } else {
        transferHydrationRetryVisible.value = true;
        clearTransferHydrationStallTimer();
      }
      clearTransferHydrationRateLimitTimer();
    }
  }
}

async function retryTransferHydrationFromScratch(): Promise<void> {
  if (!props.board) {
    return;
  }

  // Local cache is cleared synchronously; backend cleanup is best-effort so the
  // retry action does not wait on network availability before restarting.
  void Promise.resolve(
    clearTransferBundleForBoard(props.board, {
      backendCacheEnabled: false,
      localCacheEnabled: props.transferBundleLocalCacheEnabled,
    }),
  ).catch(() => undefined);
  transferHydrationRequest += 1;
  forceFreshTransferHydration.value = true;
  transferHydrationRateLimited.value = false;
  resetTransferHydrationStallState();
  clearTransferHydrationRateLimitTimer();
  void hydratePatternTransfers();
}

function syncTransferHydrationStallTimer(requestId: number): void {
  clearTransferHydrationStallTimer();

  if (
    !transferHydrationLoading.value ||
    transferHydrationProgress.value.completed > 0
  ) {
    transferHydrationRetryVisible.value = false;
    return;
  }

  transferHydrationStalledTimer = window.setTimeout(() => {
    transferHydrationStalledTimer = undefined;

    if (
      requestId === transferHydrationRequest &&
      transferHydrationLoading.value &&
      transferHydrationProgress.value.completed === 0
    ) {
      transferHydrationRetryVisible.value = true;
      void checkTransferHydrationRateLimit(requestId);
    }
  }, TRANSFER_HYDRATION_STALLED_RETRY_MS);
}

function syncTransferHydrationRateLimitCheck(requestId: number): void {
  clearTransferHydrationRateLimitTimer();

  if (
    !transferHydrationLoading.value ||
    transferHydrationRateLimited.value ||
    transferHydrationProgress.value.completed > 0
  ) {
    return;
  }

  transferHydrationRateLimitTimer = window.setTimeout(() => {
    transferHydrationRateLimitTimer = undefined;
    void checkTransferHydrationRateLimit(requestId);
  }, TRANSFER_HYDRATION_RATE_LIMIT_CHECK_MS);
}

async function checkTransferHydrationRateLimit(
  requestId: number,
): Promise<void> {
  if (
    requestId !== transferHydrationRequest ||
    !transferHydrationLoading.value ||
    transferHydrationProgress.value.completed > 0
  ) {
    return;
  }

  try {
    const response = await fetchTransferHydrationHealth();

    if (!response?.ok) {
      return;
    }

    const payload = (await response.json()) as HealthResponse;

    if (
      requestId === transferHydrationRequest &&
      transferHydrationLoading.value &&
      transferHydrationProgress.value.completed === 0 &&
      healthChecksIndicateMarketplaceRateLimit(payload.checks)
    ) {
      transferHydrationRateLimited.value = true;
      transferHydrationRetryVisible.value = true;
      clearTransferHydrationStallTimer();
    }
  } catch {
    // Health is best-effort here: the loader must keep its normal behavior if
    // the health endpoint itself is unavailable.
  }
}

async function fetchTransferHydrationHealth(): Promise<Response | undefined> {
  const controller =
    typeof AbortController === "undefined" ? undefined : new AbortController();
  const timeout =
    controller && typeof window !== "undefined"
      ? window.setTimeout(
          () => controller.abort(),
          TRANSFER_HYDRATION_HEALTH_CHECK_TIMEOUT_MS,
        )
      : undefined;

  try {
    return await fetch(toServerApiUrl("/api/health"), {
      signal: controller?.signal,
    });
  } catch {
    return undefined;
  } finally {
    if (timeout !== undefined) {
      window.clearTimeout(timeout);
    }
  }
}

function healthChecksIndicateMarketplaceRateLimit(
  checks: HealthCheck[],
): boolean {
  return checks
    .filter((check) => ["prim", "navitia", "prim-traffic"].includes(check.id))
    .some(healthCheckIndicatesRateLimit);
}

function healthCheckIndicatesRateLimit(check: HealthCheck): boolean {
  const remaining = check.quota?.remaining;
  const numericRemaining =
    remaining === undefined || remaining === "" ? undefined : Number(remaining);

  if (
    numericRemaining !== undefined &&
    Number.isFinite(numericRemaining) &&
    numericRemaining <= 0
  ) {
    return true;
  }

  const text = `${check.message} ${check.detail ?? ""}`.toLowerCase();

  return (
    text.includes("429") ||
    text.includes("rate limit") ||
    text.includes("ratelimit") ||
    text.includes("quota")
  );
}

function resetTransferHydrationStallState(): void {
  transferHydrationRetryVisible.value = false;
  clearTransferHydrationStallTimer();
}

function clearTransferHydrationStallTimer(): void {
  if (transferHydrationStalledTimer === undefined) {
    return;
  }

  window.clearTimeout(transferHydrationStalledTimer);
  transferHydrationStalledTimer = undefined;
}

function clearTransferHydrationRateLimitTimer(): void {
  if (transferHydrationRateLimitTimer === undefined) {
    return;
  }

  window.clearTimeout(transferHydrationRateLimitTimer);
  transferHydrationRateLimitTimer = undefined;
}

function clearPatternDistanceLabelHideTimer(): void {
  if (patternDistanceLabelHideTimer === undefined) {
    return;
  }

  window.clearTimeout(patternDistanceLabelHideTimer);
  patternDistanceLabelHideTimer = undefined;
}

function createPatternFlow(
  calls: DepartureCall[],
  lineTopology: LineRouteSequence[],
  lineTopologyLayout: LineTopologyLayout | undefined,
  departureTimeLabel: string,
  visualMode: PatternVisualMode,
  fullLine: boolean,
  currentLine?: CurrentLineIdentity,
  showDistances = false,
  distanceLabelsLeaving = false,
  showCityZones = true,
  roundedCurves = false,
  showInterruptionWalkingTimes = true,
  unifyReplacementBusMarkers = true,
  analyzeTraffic: DeparturePatternTrafficAnalyzer = createEmptyTrafficImpactAnalysis,
): PatternFlowModel {
  const sourceGraph = buildPatternGraph(calls, lineTopology, fullLine);
  const sourceLayout = createResolvedPatternLayoutOptions(
    visualMode === "cities" ? "compact" : visualMode,
    sourceGraph.edges,
  );
  const sourceTopology =
    createTopologyLayout(
      sourceGraph.nodes,
      sourceGraph.edges,
      calls,
      lineTopology,
      lineTopologyLayout,
      fullLine,
      sourceLayout,
    ) ?? createFallbackTopologyLayout(sourceGraph, sourceLayout);
  const sourceDrawableEdges = [
    ...sourceGraph.edges,
    ...sourceTopology.syntheticEdges,
  ];
  const sourceVisibleDrawableEdges = sourceDrawableEdges.filter((edge) =>
    sourceTopology.visibleEdges.has(createEdgeKey(edge.source, edge.target)),
  );
  const trafficSourceStations = sourceGraph.nodes.map((node) => ({
    key: node.id,
    label: node.label,
    transfers: filterCurrentLineTransfers(node.transfers, currentLine),
    branchEnd: node.degree <= 1,
  }));
  const trafficSourceEdges = sourceVisibleDrawableEdges.map((edge) => ({
    id: edge.id,
    source: edge.source,
    target: edge.target,
  }));
  const sourceTrafficAnalysis = analyzeTraffic(
    trafficSourceStations,
    trafficSourceEdges,
  );
  const cityCompression =
    visualMode === "cities"
      ? createCityPatternCompression({
          sourceGraph,
          calls,
          lineTopology,
          lineTopologyLayout,
          fullLine,
        })
      : undefined;
  const graph = cityCompression?.graph ?? sourceGraph;
  const renderCalls = cityCompression?.calls ?? calls;
  const renderLineTopology = cityCompression?.lineTopology ?? lineTopology;
  const renderLineTopologyLayout =
    cityCompression?.lineTopologyLayout ?? lineTopologyLayout;
  const layout = createResolvedPatternLayoutOptions(visualMode, graph.edges);
  const topology = cityCompression
    ? createTopologyLayout(
        graph.nodes,
        graph.edges,
        renderCalls,
        renderLineTopology,
        renderLineTopologyLayout,
        fullLine,
        layout,
      ) ?? createFallbackTopologyLayout(graph, layout)
    : sourceTopology;
  const activeTerminalIds = getActiveTerminalIds(graph);
  const drawableEdges = [...graph.edges, ...topology.syntheticEdges];
  const visibleDrawableEdges = drawableEdges.filter((edge) =>
    topology.visibleEdges.has(createEdgeKey(edge.source, edge.target)),
  );
  const trafficStations = graph.nodes.map((node) => ({
    key: node.id,
    label: node.label,
    transfers: filterCurrentLineTransfers(node.transfers, currentLine),
    branchEnd: node.degree <= 1,
  }));
  const trafficEdges = visibleDrawableEdges.map((edge) => ({
    id: edge.id,
    source: edge.source,
    target: edge.target,
  }));
  const trafficAnalysis = cityCompression
    ? projectPatternTrafficAnalysis(
        sourceTrafficAnalysis,
        cityCompression.displayKeyBySourceKey,
        trafficEdges,
      )
    : sourceTrafficAnalysis;
  const stationNodes = graph.nodes.map((node) => {
    const position = topology.positions.get(node.id) ?? { x: 0, y: 0 };
    const nodePosition = {
      x: position.x - layout.nodeWidth / 2,
      y: position.y - layout.nodeHeight / 2,
    };
    const isBranchEnd = node.degree <= 1;
    const cityNode = Boolean(cityCompression?.cityNodeKeys.has(node.id));
    const visibleTransfers = filterDuplicateBusTransfers(
      filterCurrentLineTransfers(node.transfers, currentLine),
    );

    return {
      id: node.id,
      type: "station",
      position: nodePosition,
      targetPosition: Position.Left,
      sourcePosition: Position.Right,
      draggable: false,
      selectable: false,
      connectable: false,
      class: node.current ? "pattern-flow-node--current" : undefined,
      zIndex: node.current ? 80 : node.transfers.length > 0 ? 60 : undefined,
      data: {
        key: node.id,
        label: node.label,
        city: node.city,
        cityNode,
        mixedServed: Boolean(cityCompression?.mixedServedKeys.has(node.id)),
        layoutX: position.x,
        layoutY: position.y,
        nodeX: nodePosition.x,
        nodeY: nodePosition.y,
        time: node.time,
        current: node.current,
        served: node.served,
        branchEnd: isBranchEnd,
        branchChip: fullLine
          ? undefined
          : getBranchChip(node, activeTerminalIds, departureTimeLabel),
        busTransfers:
          visualMode === "cities" ? [] : visibleTransfers.filter(isBusTransfer),
        nonBusTransfers:
          visualMode === "cities"
            ? []
            : visibleTransfers.filter(isVisiblePatternPlanTransfer),
        transfers: visibleTransfers,
        trafficImpact: trafficAnalysis.stationImpacts[node.id],
      },
    } satisfies PatternStationFlowNode;
  });
  const cityZoneNodes = showCityZones && visualMode !== "cities"
    ? createCityZoneFlowNodes({
        graphNodes: graph.nodes,
        graphEdges: graph.edges,
        positions: topology.positions,
        layout,
        compact: layout.compact,
      })
    : [];
  const trafficWalkingNodes = showInterruptionWalkingTimes
    ? createTrafficWalkingFlowNodes({
        segments: trafficAnalysis.segments,
        edges: visibleDrawableEdges,
        positions: topology.positions,
        layout,
      })
    : [];
  const trafficMarkerGroups = groupPatternTrafficMarkerSegments({
    segments: trafficAnalysis.segments,
    edges: visibleDrawableEdges,
    unifyReplacementBusMarkers,
    availableStationKeys: topology.positions.keys(),
  }).filter((group) => !hiddenTrafficMarkerKeys.value.has(group.id));
  const trafficMarkerNodes = createTrafficMarkerFlowNodes({
    groups: trafficMarkerGroups,
    edges: visibleDrawableEdges,
    layout,
    compact: layout.compact,
    stationNodes,
    cityZoneNodes,
    walkingNodes: trafficWalkingNodes,
  });
  const nodes: PatternFlowNode[] = [
    ...cityZoneNodes,
    ...stationNodes,
    ...trafficWalkingNodes,
    ...trafficMarkerNodes,
  ];
  const activeRouteEdgeOrder = fullLine
    ? new Map<string, number>()
    : createActiveRouteEdgeOrder(renderCalls, renderLineTopology);
  const activeRouteEdgeDirections = fullLine
    ? new Map<string, { source: string; target: string }>()
    : createActiveRouteEdgeDirections(renderCalls, renderLineTopology);
  const activeLightEdges = fullLine
    ? []
    : visibleDrawableEdges
        .filter(
          (edge) =>
            edge.active &&
            !trafficAnalysis.edgeImpacts[
              createEdgeKey(edge.source, edge.target)
            ],
        )
        .map((edge, fallbackOrder) => ({
          edge,
          direction: activeRouteEdgeDirections.get(
            createEdgeKey(edge.source, edge.target),
          ),
          order:
            activeRouteEdgeOrder.get(createEdgeKey(edge.source, edge.target)) ??
            fallbackOrder,
        }))
        .sort((left, right) => left.order - right.order);
  const edges = [
    ...visibleDrawableEdges.map((edge) =>
      createFlowEdge(
        edge,
        topology.positions,
        showDistances,
        distanceLabelsLeaving,
        trafficAnalysis.edgeImpacts[createEdgeKey(edge.source, edge.target)],
        roundedCurves,
      ),
    ),
    ...activeLightEdges.map(({ edge, direction, order }) =>
      createFlowLightEdge(
        edge,
        topology.positions,
        direction,
        order,
        activeLightEdges.length,
        roundedCurves,
      ),
    ),
  ];
  return {
    nodes,
    stationNodes,
    edges,
    trafficEdges,
    trafficSourceEdges,
    trafficPositions: topology.positions,
    trafficStations,
    trafficSourceStations,
    trafficAnalysis,
    displayKeyBySourceKey:
      cityCompression?.displayKeyBySourceKey ??
      new Map(sourceGraph.nodes.map((node) => [node.id, node.id])),
  };
}

function createCityPatternCompression({
  sourceGraph,
  calls,
  lineTopology,
  lineTopologyLayout,
  fullLine,
}: {
  sourceGraph: {
    nodes: PatternGraphNode[];
    edges: PatternGraphEdge[];
  };
  calls: DepartureCall[];
  lineTopology: LineRouteSequence[];
  lineTopologyLayout: LineTopologyLayout | undefined;
  fullLine: boolean;
}): PatternCityCompression {
  const groups = createPatternCityGroups(sourceGraph.nodes, fullLine);
  const groupByKey = new Map(groups.map((group) => [group.key, group]));
  const displayKeyBySourceKey = new Map<string, string>();

  groups.forEach((group) => {
    group.sourceKeys.forEach((sourceKey) => {
      displayKeyBySourceKey.set(sourceKey, group.key);
    });
  });

  const topologyIdBySourceKey = new Map<string, string>();
  lineTopology.forEach((sequence) => {
    sequence.stops.forEach((stop) => {
      const sourceKey = createStationKey(stop);
      const displayKey = resolveCityDisplayKey(
        sourceKey,
        sourceGraph.nodes,
        displayKeyBySourceKey,
      );

      if (!displayKey) {
        return;
      }

      topologyIdBySourceKey.set(sourceKey, displayKey);
      topologyIdBySourceKey.set(stop.id, displayKey);
      topologyIdBySourceKey.set(stop.station.id, displayKey);
      if (stop.station.scheduleStopAreaRef) {
        topologyIdBySourceKey.set(stop.station.scheduleStopAreaRef, displayKey);
      }
    });
  });

  const compressedCalls = calls.flatMap((call, index) => {
    const sourceKey = createStationKey(call);
    const displayKey = resolveCityDisplayKey(
      sourceKey,
      sourceGraph.nodes,
      displayKeyBySourceKey,
    );
    const group = displayKey ? groupByKey.get(displayKey) : undefined;

    if (!group) {
      return [];
    }

    return [
      {
        ...call,
        id: `${group.key}:call:${index}`,
        label: group.internalLabel,
        city: group.city,
        time: group.time,
        current: fullLine ? false : group.current,
        served: fullLine || group.served,
        stopAreaRef: group.key,
        transferLines: group.transfers,
      },
    ];
  });

  const compressedTopology = lineTopology.flatMap((sequence) => {
    const compressedKeys = dedupeAdjacentPatternKeys(
      sequence.stops.flatMap((stop) => {
        const sourceKey = createStationKey(stop);
        const displayKey = resolveCityDisplayKey(
          sourceKey,
          sourceGraph.nodes,
          displayKeyBySourceKey,
        );
        return displayKey ? [displayKey] : [];
      }),
    );
    const stops = compressedKeys.flatMap((key) => {
      const group = groupByKey.get(key);
      return group ? [createCitySyntheticStop(group)] : [];
    });

    if (stops.length === 0) {
      return [];
    }

    const branchLayout = sequence.branchLayout
      ? remapCityBranchLayout(
          sequence.branchLayout,
          topologyIdBySourceKey,
          stops,
        )
      : undefined;

    return [
      {
        ...sequence,
        stops,
        branchLayout,
      },
    ];
  });

  const compressedTopologyLayout = lineTopologyLayout
    ? remapCityTopologyLayout(lineTopologyLayout, topologyIdBySourceKey)
    : undefined;
  const graph = buildPatternGraph(compressedCalls, compressedTopology, fullLine);

  graph.nodes.forEach((node) => {
    const group = groupByKey.get(node.id);

    if (!group) {
      return;
    }

    node.label = group.label;
    node.city = group.city;
    node.lon = group.lon;
    node.lat = group.lat;
    node.coordinatePriority = group.coordinatePriority;
    node.current = group.current;
    node.served = group.served;
    node.time = group.time;
    node.transfers = group.transfers;
  });

  return {
    graph,
    calls: compressedCalls,
    lineTopology: compressedTopology,
    lineTopologyLayout: compressedTopologyLayout,
    displayKeyBySourceKey,
    cityNodeKeys: new Set(
      groups.filter((group) => Boolean(group.city)).map((group) => group.key),
    ),
    mixedServedKeys: new Set(
      groups
        .filter((group) => group.mixedServed)
        .map((group) => group.key),
    ),
  };
}

function createPatternCityGroups(
  sourceNodes: PatternGraphNode[],
  fullLine: boolean,
): PatternCityGroup[] {
  const groupsByIdentity = new Map<string, PatternCityGroup>();

  sourceNodes.forEach((node) => {
    const city = normalizeCityLabel(node.city);
    const normalizedCity = normalizeCityZoneKey(city);
    const identity = normalizedCity
      ? `city:${normalizedCity}`
      : `station:${node.id}`;
    const existing = groupsByIdentity.get(identity);

    if (existing) {
      existing.sourceKeys.push(node.id);
      existing.current ||= node.current;
      existing.served ||= fullLine || node.served;
      existing.transfers = mergeTransfers(existing.transfers, node.transfers);
      existing.coordinatePriority = Math.max(
        existing.coordinatePriority,
        node.coordinatePriority,
      );
      return;
    }

    const internalLabel = normalizedCity
      ? `__citynode:${normalizedCity}__`
      : `__stationnode:${node.id}__`;
    const coordinates = node.lon !== undefined && node.lat !== undefined
      ? { lon: node.lon, lat: node.lat }
      : undefined;

    groupsByIdentity.set(identity, {
      key: createStationKey({ label: internalLabel }),
      internalLabel,
      label: city || node.label,
      city: city || undefined,
      sourceKeys: [node.id],
      current: fullLine ? false : node.current,
      served: fullLine || node.served,
      mixedServed: false,
      time: fullLine ? undefined : node.time,
      transfers: node.transfers,
      lon: coordinates?.lon,
      lat: coordinates?.lat,
      coordinatePriority: node.coordinatePriority,
    });
  });

  const groups = Array.from(groupsByIdentity.values());
  groups.forEach((group) => {
    if (!group.city) {
      return;
    }

    const members = group.sourceKeys.flatMap((sourceKey) =>
      sourceNodes.filter((node) => node.id === sourceKey),
    );
    const servedMembers = members.filter((node) => node.served);
    const currentWithTime = members.find((node) => node.current && node.time);
    const servedWithTime = servedMembers.find((node) => node.time);

    group.time = fullLine
      ? undefined
      : (currentWithTime?.time ?? servedWithTime?.time);
    group.mixedServed =
      group.sourceKeys.length > 1 &&
      !fullLine &&
      members.some((node) => node.served) &&
      members.some((node) => !node.served);

    const coordinateMembers = members.filter(
      (node): node is PatternGraphNode & { lon: number; lat: number } =>
        node.lon !== undefined && node.lat !== undefined,
    );
    if (coordinateMembers.length > 0) {
      group.lon =
        coordinateMembers.reduce((sum, node) => sum + node.lon, 0) /
        coordinateMembers.length;
      group.lat =
        coordinateMembers.reduce((sum, node) => sum + node.lat, 0) /
        coordinateMembers.length;
    }
  });

  return groups;
}

function resolveCityDisplayKey(
  sourceKey: string,
  sourceNodes: PatternGraphNode[],
  displayKeyBySourceKey: Map<string, string>,
): string | undefined {
  const exact = displayKeyBySourceKey.get(sourceKey);
  if (exact) {
    return exact;
  }

  const compatible = sourceNodes.find((node) =>
    stationKeysAreCompatible(sourceKey, node.id),
  );

  return compatible ? displayKeyBySourceKey.get(compatible.id) : undefined;
}

function createCitySyntheticStop(group: PatternCityGroup): LineRouteStop {
  return {
    id: group.key,
    label: group.internalLabel,
    city: group.city,
    lon: group.lon,
    lat: group.lat,
    station: {
      id: group.key,
      label: group.internalLabel,
      city: group.city,
      lon: group.lon,
      lat: group.lat,
      monitoringRef: group.key,
      scheduleStopAreaRef: group.key,
    },
    transferLines: group.transfers,
  };
}

function remapCityBranchLayout(
  branchLayout: LineRouteBranchLayout,
  topologyIdBySourceKey: Map<string, string>,
  stops: LineRouteStop[],
): LineRouteBranchLayout | undefined {
  const firstStopId = stops[0]?.id ?? branchLayout.junctionStationId;
  const lastStopId = stops.at(-1)?.id ?? branchLayout.terminalStationId;
  const junctionStationId =
    topologyIdBySourceKey.get(branchLayout.junctionStationId) ?? firstStopId;
  const terminalStationId =
    topologyIdBySourceKey.get(branchLayout.terminalStationId) ?? lastStopId;

  if (
    stops.length < 2 ||
    !junctionStationId ||
    !terminalStationId ||
    junctionStationId === terminalStationId ||
    !stops.some((stop) => stop.id === junctionStationId) ||
    !stops.some((stop) => stop.id === terminalStationId)
  ) {
    return undefined;
  }

  const trunkStationId = branchLayout.trunkStationId
    ? topologyIdBySourceKey.get(branchLayout.trunkStationId)
    : undefined;

  return {
    ...branchLayout,
    junctionStationId,
    terminalStationId,
    trunkStationId:
      trunkStationId &&
      trunkStationId !== junctionStationId &&
      trunkStationId !== terminalStationId
        ? trunkStationId
        : undefined,
  };
}

function remapCityTopologyLayout(
  layout: LineTopologyLayout,
  topologyIdBySourceKey: Map<string, string>,
): LineTopologyLayout {
  const mapIds = (ids: string[] | undefined): string[] =>
    normalizeCityTopologyHintIds(
      (ids ?? []).flatMap((id) => {
        const mapped = topologyIdBySourceKey.get(id);
        return mapped ? [mapped] : [];
      }),
    );

  const remapLaneHints = (
    laneHints: NonNullable<LineTopologyLoopLayout["laneHints"]>,
  ): NonNullable<LineTopologyLoopLayout["laneHints"]> =>
    laneHints.flatMap((laneHint) => {
      const anchorStationIds = mapIds(laneHint.anchorStationIds);
      const stationIds = mapIds(laneHint.stationIds);

      return stationIds.length >= 3 &&
        new Set(anchorStationIds).size >= 2
        ? [{ ...laneHint, anchorStationIds, stationIds }]
        : [];
    });

  const loops = layout.loops.flatMap((loop) => {
    const anchorStationIds = mapIds(loop.anchorStationIds);
    const stationIds = mapIds(loop.stationIds);
    const orderedAnchorStationIds = loop.orderedAnchorStationIds
      ? mapIds(loop.orderedAnchorStationIds)
      : undefined;
    const orderedStationIds = loop.orderedStationIds
      ? mapIds(loop.orderedStationIds)
      : undefined;
    const laneHints = loop.laneHints
      ? remapLaneHints(loop.laneHints)
      : undefined;
    const effectiveStationIds =
      orderedStationIds && orderedStationIds.length > 0
        ? orderedStationIds
        : stationIds;
    const effectiveAnchorStationIds =
      orderedAnchorStationIds && orderedAnchorStationIds.length > 0
        ? orderedAnchorStationIds
        : anchorStationIds;

    if (
      effectiveStationIds.length < 3 ||
      new Set(effectiveAnchorStationIds).size < 2
    ) {
      return [];
    }

    return [
      {
        ...loop,
        anchorStationIds,
        stationIds,
        orderedAnchorStationIds,
        orderedStationIds,
        laneHints: laneHints && laneHints.length > 0 ? laneHints : undefined,
      },
    ];
  });

  const terminalJunctions = layout.terminalJunctions?.flatMap((junction) => {
      const junctionStationId = topologyIdBySourceKey.get(
        junction.junctionStationId,
      );

      if (!junctionStationId) {
        return [];
      }

      const arms = junction.arms.flatMap((arm) => {
        const stationIds = mapIds(arm.stationIds);
        const anchorStationId =
          topologyIdBySourceKey.get(arm.anchorStationId) ?? stationIds.at(-1);

        return anchorStationId &&
          stationIds.length >= 2 &&
          stationIds[0] === junctionStationId &&
          new Set(stationIds).size >= 2 &&
          anchorStationId !== junctionStationId
          ? [{ ...arm, anchorStationId, stationIds }]
          : [];
      });

      return arms.length >= 3
        ? [{ ...junction, junctionStationId, arms }]
        : [];
    }) ?? [];

  return {
    loops,
    terminalJunctions:
      terminalJunctions.length > 0 ? terminalJunctions : undefined,
  };
}

function dedupeAdjacentPatternKeys(keys: string[]): string[] {
  return keys.filter((key, index) => index === 0 || key !== keys[index - 1]);
}

function normalizeCityTopologyHintIds(ids: string[]): string[] {
  const normalized = dedupeAdjacentPatternKeys(ids);

  if (
    normalized.length > 1 &&
    normalized[0] === normalized[normalized.length - 1]
  ) {
    normalized.pop();
  }

  return normalized;
}

function projectPatternTrafficAnalysis(
  sourceAnalysis: PatternTrafficImpactAnalysis,
  displayKeyBySourceKey: Map<string, string>,
  displayEdges: PatternTrafficEdge[],
): PatternTrafficImpactAnalysis {
  const displayEdgeKeys = new Set(
    displayEdges.map((edge) => createEdgeKey(edge.source, edge.target)),
  );
  const projectedSegments = sourceAnalysis.segments.flatMap((segment) => {
    let stationKeys = Array.from(
      new Set(
        segment.stationKeys.flatMap((sourceKey) => {
          const displayKey = displayKeyBySourceKey.get(sourceKey);
          return displayKey ? [displayKey] : [];
        }),
      ),
    );
    const edgeKeys = Array.from(
      new Set(
        segment.edgeKeys.flatMap((sourceKey) => {
          const displayKey = projectPatternTrafficEdgeKey(
            sourceKey,
            displayKeyBySourceKey,
            displayEdgeKeys,
          );
          return displayKey ? [displayKey] : [];
        }),
      ),
    );

    if (
      segment.kind === "interruption" &&
      stationKeys.length === 0 &&
      edgeKeys.length === 0
    ) {
      stationKeys = Array.from(
        new Set(
          segment.edgeKeys.flatMap((sourceKey) => {
            const [source, target] = sourceKey.split("--");
            const displaySource = source
              ? displayKeyBySourceKey.get(source)
              : undefined;
            const displayTarget = target
              ? displayKeyBySourceKey.get(target)
              : undefined;

            return displaySource && displaySource === displayTarget
              ? [displaySource]
              : [];
          }),
        ),
      );
    }

    return stationKeys.length > 0 || edgeKeys.length > 0
      ? [{ ...segment, stationKeys, edgeKeys }]
      : [];
  });

  const interruptionStationKeys = new Set(
    projectedSegments.flatMap((segment) =>
      segment.kind === "interruption" ? segment.stationKeys : [],
    ),
  );
  const interruptionEdgeKeys = new Set(
    projectedSegments.flatMap((segment) =>
      segment.kind === "interruption" ? segment.edgeKeys : [],
    ),
  );
  const segments = projectedSegments.flatMap((segment) => {
    if (segment.kind === "interruption") {
      return [segment];
    }

    const stationKeys = segment.stationKeys.filter(
      (stationKey) => !interruptionStationKeys.has(stationKey),
    );
    const edgeKeys = segment.edgeKeys.filter(
      (edgeKey) => !interruptionEdgeKeys.has(edgeKey),
    );

    return stationKeys.length > 0 || edgeKeys.length > 0
      ? [{ ...segment, stationKeys, edgeKeys }]
      : [];
  });

  const stationImpacts: Record<string, PatternTrafficImpact> = {};
  const edgeImpacts: Record<string, PatternTrafficImpact> = {};

  Object.entries(sourceAnalysis.stationImpacts).forEach(
    ([sourceKey, impact]) => {
      const displayKey = displayKeyBySourceKey.get(sourceKey);
      if (displayKey) {
        stationImpacts[displayKey] = chooseProjectedTrafficImpact(
          stationImpacts[displayKey],
          impact,
        );
      }
    },
  );

  Object.entries(sourceAnalysis.edgeImpacts).forEach(([sourceKey, impact]) => {
    const displayKey = projectPatternTrafficEdgeKey(
      sourceKey,
      displayKeyBySourceKey,
      displayEdgeKeys,
    );
    if (displayKey) {
      edgeImpacts[displayKey] = chooseProjectedTrafficImpact(
        edgeImpacts[displayKey],
        impact,
      );
    }
  });

  segments.forEach((segment) => {
    segment.stationKeys.forEach((stationKey) => {
      stationImpacts[stationKey] = chooseProjectedTrafficImpact(
        stationImpacts[stationKey],
        segment,
      );
    });
    segment.edgeKeys.forEach((edgeKey) => {
      edgeImpacts[edgeKey] = chooseProjectedTrafficImpact(
        edgeImpacts[edgeKey],
        segment,
      );
    });
  });

  return { segments, stationImpacts, edgeImpacts };
}

function projectPatternTrafficEdgeKey(
  sourceEdgeKey: string,
  displayKeyBySourceKey: Map<string, string>,
  displayEdgeKeys: Set<string>,
): string | undefined {
  const [source, target] = sourceEdgeKey.split("--");
  const displaySource = source ? displayKeyBySourceKey.get(source) : undefined;
  const displayTarget = target ? displayKeyBySourceKey.get(target) : undefined;

  if (!displaySource || !displayTarget || displaySource === displayTarget) {
    return undefined;
  }

  const displayEdgeKey = createEdgeKey(displaySource, displayTarget);
  return displayEdgeKeys.has(displayEdgeKey) ? displayEdgeKey : undefined;
}

function chooseProjectedTrafficImpact(
  existing: PatternTrafficImpact | undefined,
  next: PatternTrafficImpact,
): PatternTrafficImpact {
  if (!existing || (next.kind === "interruption" && existing.kind !== "interruption")) {
    return next;
  }

  return existing;
}

function createEmptyTrafficImpactAnalysis(): PatternTrafficImpactAnalysis {
  return {
    segments: [],
    stationImpacts: {},
    edgeImpacts: {},
  };
}

function createTrafficMarkerRailPositions(
  stationNodes: PatternStationFlowNode[],
  layout: PatternLayoutOptions,
  compact: boolean,
): Map<string, PatternLayoutPosition> {
  return new Map(
    stationNodes.map((node) => [
      node.id,
      {
        x: node.position.x + layout.nodeWidth / 2,
        y:
          node.position.y +
          (compact
            ? COMPACT_STATION_RAIL_CENTER_Y
            : node.data?.branchEnd
              ? REGULAR_TERMINAL_RAIL_CENTER_Y
              : REGULAR_STATION_RAIL_CENTER_Y),
      },
    ]),
  );
}

function createTrafficMarkerFlowNodes({
  groups,
  edges,
  layout,
  compact,
  stationNodes,
  cityZoneNodes,
  walkingNodes,
}: {
  groups: PatternTrafficMarkerGroup[];
  edges: PatternGraphEdge[];
  layout: PatternLayoutOptions;
  compact: boolean;
  stationNodes: PatternStationFlowNode[];
  cityZoneNodes: PatternCityZoneFlowNode[];
  walkingNodes: PatternTrafficWalkingFlowNode[];
}): PatternFlowNode[] {
  const railPositions = createTrafficMarkerRailPositions(
    stationNodes,
    layout,
    compact,
  );
  const obstacles: TrafficMarkerRect[] = [
    ...stationNodes.flatMap((node) =>
      createTrafficMarkerStationObstacles({
        position: node.position,
        width: layout.nodeWidth,
        height: layout.nodeHeight,
        compact,
      }),
    ),
    ...cityZoneNodes.map((node) => ({
      x: node.position.x,
      y: node.position.y,
      width: node.data?.width ?? 0,
      height: 32,
    })),
    ...walkingNodes.map((node) => ({
      x: node.position.x,
      y: node.position.y,
      width: compact ? 84 : 96,
      height: compact ? 24 : 26,
    })),
  ];
  const requests = groups.flatMap((group) => {
    const anchor = getTrafficMarkerAnchor(group, edges, railPositions);

    if (!anchor) {
      return [];
    }

    const size = getTrafficMarkerSize(
      group.representative.kind,
      compact,
      group.representative.replacementBus,
    );

    return [
      {
        key: group.id,
        anchor,
        width: size.width,
        height: size.height,
        preferAbove: shouldPreferTrafficMarkerAbove(
          anchor,
          railPositions.values(),
        ),
      },
    ];
  });
  const placements = layoutTrafficMarkers(requests, obstacles);

  return groups.flatMap((group): PatternFlowNode[] => {
      const anchor = getTrafficMarkerAnchor(group, edges, railPositions);
      const placement = placements.get(group.id);

      if (!anchor || !placement) {
        return [];
      }

      const segment = group.representative;
      const markerSize = getTrafficMarkerSize(
        segment.kind,
        compact,
        segment.replacementBus,
      );

      const connectorNode: PatternTrafficMarkerConnectorFlowNode = {
        id: `traffic-marker-connector:${group.id}`,
        type: "traffic-marker-connector",
        position: placement.position,
        draggable: false,
        selectable: false,
        connectable: false,
        focusable: false,
        class: `pattern-flow-traffic-marker-connector-node pattern-flow-traffic-marker-connector-node--${segment.kind}`,
        zIndex: TRAFFIC_MARKER_CONNECTOR_Z_INDEX,
        data: {
          connectorAngle: placement.connectorAngle,
          connectorHeight: placement.connectorHeight,
          connectorLength: placement.connectorLength,
          connectorOffset: placement.connectorOffset,
          key: group.id,
          kind: segment.kind,
          markerHeight: markerSize.height,
          markerWidth: markerSize.width,
          placement: placement.placement,
        },
      };
      const markerNode: PatternTrafficMarkerFlowNode = {
        id: `traffic-marker:${group.id}`,
        type: "traffic-marker",
        position: placement.position,
        draggable: false,
        selectable: false,
        connectable: false,
        focusable: false,
        class: `pattern-flow-traffic-marker-node pattern-flow-traffic-marker-node--${segment.kind}`,
        zIndex: TRAFFIC_MARKER_CARD_Z_INDEX,
        data: {
          key: group.id,
          kind: segment.kind,
          markerHeight: markerSize.height,
          placement: placement.placement,
          pulseStationKeys: getTrafficFocusStationKeys(
            group.segments,
            railPositions,
          ),
          statusLabel: getTrafficMarkerStatusLabel(segment),
          detailLabel: getTrafficMarkerDetailLabel(segment),
          replacementBus: segment.replacementBus,
          trafficImpact: segment,
        },
      };
      return [connectorNode, markerNode];
    });
}

function createInfoCardsDebugSnapshot(): InfoCardDebugSnapshot {
  if (!props.open) {
    return { markers: [], obstacles: [] };
  }

  const model = flowModel.value;
  const layout = currentLayoutOptions.value;
  const railPositions = createTrafficMarkerRailPositions(
    model.stationNodes,
    layout,
    layout.compact,
  );
  const groups = groupPatternTrafficMarkerSegments({
    segments: model.trafficAnalysis.segments,
    edges: model.trafficEdges,
    unifyReplacementBusMarkers: props.unifyReplacementBusMarkers,
    availableStationKeys: model.trafficPositions.keys(),
  }).filter((group) => !hiddenTrafficMarkerKeys.value.has(group.id));
  const groupById = new Map(groups.map((group) => [group.id, group]));
  const edgeByKey = new Map(
    model.trafficEdges.map((edge) => [createEdgeKey(edge.source, edge.target), edge]),
  );
  const markerNodes = allFlowNodes.value.filter(
    (node): node is PatternTrafficMarkerFlowNode =>
      node.type === "traffic-marker",
  );
  const connectorNodes = new Map(
    allFlowNodes.value
      .filter(
        (node): node is PatternTrafficMarkerConnectorFlowNode =>
          node.type === "traffic-marker-connector",
      )
      .flatMap((node) => (node.data ? [[node.data.key, node] as const] : [])),
  );
  const markers = markerNodes.flatMap((node): InfoCardDebugMarker[] => {
    const markerData = node.data;
    if (!markerData) return [];
    const group = groupById.get(markerData.key);
    if (!group) return [];

    const anchor = getTrafficMarkerAnchor(
      group,
      model.trafficEdges,
      railPositions,
    );
    const connectorNode = connectorNodes.get(group.id);
    if (!anchor || !connectorNode) return [];

    const size = getTrafficMarkerSize(
      group.representative.kind,
      layout.compact,
      group.representative.replacementBus,
    );
    const card = {
      x: node.position.x,
      y: node.position.y,
      width: size.width,
      height: markerData.markerHeight,
    };
    const segmentEdges: InfoCardDebugEdge[] = group.edgeKeys.flatMap(
      (edgeKey) => {
        const edge = edgeByKey.get(edgeKey);
        const sourcePoint = edge && railPositions.get(edge.source);
        const targetPoint = edge && railPositions.get(edge.target);
        if (!edge || !sourcePoint || !targetPoint) return [];
        return [
          {
            edgeKey,
            source: edge.source,
            target: edge.target,
            sourcePoint,
            targetPoint,
          },
        ];
      },
    );

    return [
      {
        markerId: node.id,
        groupId: group.id,
        kind: markerData.kind,
        replacementBus: markerData.replacementBus,
        segmentIds: group.segments.map((segment) => segment.id),
        stationKeys: group.stationKeys,
        edgeKeys: group.edgeKeys,
        text: {
          statusLabel: markerData.statusLabel,
          detailLabel: markerData.detailLabel,
          restartTimeLabel: group.representative.restartTimeLabel,
          endDateLabel: group.representative.endDateLabel,
        },
        disruption: group.representative.disruption,
        anchor,
        card,
        placement: markerData.placement,
        connector: {
          height: connectorNode.data?.connectorHeight ?? 0,
          length: connectorNode.data?.connectorLength ?? 0,
          offset: connectorNode.data?.connectorOffset ?? 0,
          angle: connectorNode.data?.connectorAngle ?? 0,
        },
        segmentEdges,
        domCard: readDebugRect(
          findDebugElement(
            ".pattern-flow-traffic-marker",
            "data-traffic-marker-key",
            group.id,
          ),
        ),
        domConnector: readDebugRect(
          findDebugElement(
            ".pattern-flow-traffic-marker-connector",
            "data-traffic-marker-connector-key",
            group.id,
          ),
        ),
      },
    ];
  });

  return {
    markers,
    obstacles: createInfoCardsDebugObstacles({
      stationNodes: model.stationNodes,
      cityZoneNodes: model.nodes.filter(
        (node): node is PatternCityZoneFlowNode => node.type === "city-zone",
      ),
      walkingNodes: model.nodes.filter(
        (node): node is PatternTrafficWalkingFlowNode =>
          node.type === "traffic-walking",
      ),
      markerNodes,
      layout,
    }),
  };
}

function createInfoCardsDebugObstacles({
  stationNodes,
  cityZoneNodes,
  walkingNodes,
  markerNodes,
  layout,
}: {
  stationNodes: PatternStationFlowNode[];
  cityZoneNodes: PatternCityZoneFlowNode[];
  walkingNodes: PatternTrafficWalkingFlowNode[];
  markerNodes: PatternTrafficMarkerFlowNode[];
  layout: PatternLayoutOptions;
}): InfoCardDebugObstacle[] {
  const obstacles: InfoCardDebugObstacle[] = [];
  const add = (obstacle: InfoCardDebugObstacle): void => {
    obstacles.push(obstacle);
  };

  stationNodes.forEach((node) => {
    const graphRects = createTrafficMarkerStationObstacles({
      position: node.position,
      width: layout.nodeWidth,
      height: layout.nodeHeight,
      compact: layout.compact,
    });
    const stationElement = findDebugElement(
      ".pattern-flow-station",
      "data-station-key",
      node.id,
    );
    add({
      id: `${node.id}:station`,
      type: "station",
      rect: graphRects[0]!,
      domRect: readDebugRect(stationElement),
    });
    if (graphRects[1]) {
      add({
        id: `${node.id}:title`,
        type: "station-title",
        rect: graphRects[1],
        domRect: readDebugRect(
          stationElement?.querySelector<HTMLElement>(".station-name"),
        ),
      });
    }
    const transferRect = readDebugRect(
      stationElement?.querySelector<HTMLElement>(
        ".pattern-flow-station__transfers",
      ),
    );
    if (transferRect) {
      add({
        id: `${node.id}:transfers`,
        type: "transfer",
        rect: transferRect,
        domRect: transferRect,
      });
    }
  });

  cityZoneNodes.forEach((node) => {
    const data = node.data;
    if (!data) return;
    add({
      id: node.id,
      type: "city-title",
      rect: {
        x: node.position.x,
        y: node.position.y,
        width: data.width,
        height: 32,
      },
      domRect: readDebugRect(
        findDebugElement(
          ".pattern-flow-city-zone",
          "data-city-zone-key",
          data.key,
        ),
      ),
    });
  });

  walkingNodes.forEach((node) => {
    const data = node.data;
    if (!data) return;
    const rect = {
      x: node.position.x,
      y: node.position.y,
      width: layout.compact ? 84 : 96,
      height: layout.compact ? 24 : 26,
    };
    const domRect = readDebugRect(
      findDebugElement(
        ".pattern-flow-traffic-walking",
        "data-traffic-walking-edge-key",
        data.edgeKey,
      ),
    );
    add({ id: node.id, type: "walking", rect, domRect });
  });

  markerNodes.forEach((node) => {
    const data = node.data;
    if (!data) return;
    const size = getTrafficMarkerSize(
      data.kind,
      layout.compact,
      data.replacementBus,
    );
    add({
      id: node.id,
      markerId: node.id,
      type: "traffic-marker",
      rect: {
        x: node.position.x,
        y: node.position.y,
        width: size.width,
        height: data.markerHeight,
      },
      domRect: readDebugRect(
        findDebugElement(
          ".pattern-flow-traffic-marker",
          "data-traffic-marker-key",
          data.key,
        ),
      ),
    });
  });

  return obstacles;
}

function findDebugElement(
  selector: string,
  attribute: string,
  value: string,
): HTMLElement | undefined {
  if (typeof document === "undefined") return undefined;
  return [...document.querySelectorAll<HTMLElement>(selector)].find(
    (element) => element.getAttribute(attribute) === value,
  );
}

function readDebugRect(
  element?: Element | null,
): InfoCardDebugRect | undefined {
  if (!element) return undefined;
  const rect = element.getBoundingClientRect();
  if (![rect.x, rect.y, rect.width, rect.height].every(Number.isFinite)) {
    return undefined;
  }
  if (rect.width <= 0 || rect.height <= 0) return undefined;
  return {
    x: rect.x,
    y: rect.y,
    width: rect.width,
    height: rect.height,
  };
}

function createTrafficWalkingFlowNodes({
  segments,
  edges,
  positions,
  layout,
}: {
  segments: PatternTrafficImpactSegment[];
  edges: PatternGraphEdge[];
  positions: Map<string, { x: number; y: number }>;
  layout: PatternLayoutOptions;
}): PatternTrafficWalkingFlowNode[] {
  const edgeByKey = new Map(
    edges.map((edge) => [createEdgeKey(edge.source, edge.target), edge]),
  );
  const width = layout.compact ? 84 : 96;

  return createInterruptionWalkingTimes(segments, edges).flatMap(
    (walkingTime) => {
      const edge = edgeByKey.get(walkingTime.edgeKey);
      const source = edge ? positions.get(edge.source) : undefined;
      const target = edge ? positions.get(edge.target) : undefined;

      if (!source || !target) {
        return [];
      }

      return [
        {
          id: `traffic-walking:${walkingTime.edgeKey}`,
          type: "traffic-walking",
          position: {
            x: (source.x + target.x) / 2 - width / 2,
            y: (source.y + target.y) / 2 + 10,
          },
          draggable: false,
          selectable: false,
          connectable: false,
          focusable: false,
          class: "pattern-flow-traffic-walking-node",
          zIndex: 94,
          data: {
            durationLabel: formatInterruptionWalkingDuration(
              walkingTime.minutes,
            ),
            edgeKey: walkingTime.edgeKey,
          },
        } satisfies PatternTrafficWalkingFlowNode,
      ];
    },
  );
}

function formatInterruptionWalkingDuration(minutes: number): string {
  const hours = Math.floor(minutes / 60);
  const remainingMinutes = minutes % 60;

  if (hours === 0) {
    return t("pattern.walkingDurationMinutes", { minutes });
  }

  if (remainingMinutes === 0) {
    return t("pattern.walkingDurationHours", { hours });
  }

  return t("pattern.walkingDurationHoursMinutes", {
    hours,
    minutes: remainingMinutes,
  });
}

function getTrafficMarkerStatusLabel(segment: PatternTrafficImpact): string {
  if (isUpcomingTrafficWarning(segment)) {
    if (segment.replacementBus) {
      return t("pattern.trafficReplacementBusPlanned");
    }

    return segment.kind === "interruption"
      ? t("pattern.trafficInterruptionPlanned")
      : t("pattern.trafficDisturbancePlanned");
  }

  if (segment.replacementBus) {
    return t("pattern.trafficReplacementBus");
  }

  return segment.kind === "interruption"
    ? t("pattern.trafficInterrupted")
    : t("pattern.trafficDisrupted");
}

function getTrafficMarkerDetailLabel(
  segment: PatternTrafficImpact,
): string | undefined {
  const selectedNow = selectedTrafficTimestamp.value;
  const timingNow =
    typeof selectedNow === "number" && Number.isFinite(selectedNow)
      ? selectedNow
      : Date.now();
  const warningStart = getUpcomingTrafficWarningStart(
    segment.disruption,
    timingNow,
    props.trafficWarningLookaheadDays,
  );

  if (warningStart && selectedNow === undefined) {
    return t("pattern.startsOn", {
      date: formatTrafficStartDate(warningStart),
    });
  }

  const relativeRestartLabel =
    selectedNow === undefined
      ? getTodayRestartRelativeLabel(segment)
      : undefined;

  if (relativeRestartLabel) {
    return relativeRestartLabel;
  }

  if (selectedNow !== undefined) {
    const selectedPeriodEnd = parseTrafficDate(
      getTrafficDisruptionDisplayPeriod(segment.disruption, selectedNow)?.end,
    );

    if (selectedPeriodEnd && !Number.isNaN(selectedPeriodEnd.getTime())) {
      return t("pattern.resumesOn", {
        date: formatTrafficStartDate(selectedPeriodEnd),
      });
    }
  }

  if (segment.restartTimeLabel) {
    return t("pattern.resumesAt", { time: segment.restartTimeLabel });
  }

  return segment.endDateLabel
    ? t("pattern.resumesOn", { date: segment.endDateLabel })
    : undefined;
}

function isUpcomingTrafficWarning(segment: PatternTrafficImpact): boolean {
  if (selectedTrafficTimestamp.value !== undefined) {
    return false;
  }

  return Boolean(
    getUpcomingTrafficWarningStart(
      segment.disruption,
      Date.now(),
      props.trafficWarningLookaheadDays,
    ),
  );
}

function getTodayRestartRelativeLabel(
  segment: PatternTrafficImpact,
): string | undefined {
  const now = new Date();
  const restartDate =
    getTodayRestartDateFromTimeLabel(segment.restartTimeLabel, now) ??
    (segment.endDateLabelSource === "text"
      ? undefined
      : parseTrafficDate(
          getTrafficDisruptionDisplayPeriod(segment.disruption)?.end,
        ));

  if (!restartDate || !isSameLocalDay(restartDate, now)) {
    return undefined;
  }

  const remainingMinutes = Math.ceil(
    (restartDate.getTime() - now.getTime()) / 60_000,
  );

  if (remainingMinutes <= 0) {
    return undefined;
  }

  const restartTimeLabel = formatTrafficRestartTime(restartDate);

  if (remainingMinutes < 60) {
    return remainingMinutes === 1
      ? t("pattern.resumesInMinute", {
          count: remainingMinutes,
          time: restartTimeLabel,
        })
      : t("pattern.resumesInMinutes", {
          count: remainingMinutes,
          time: restartTimeLabel,
        });
  }

  const remainingHours = Math.ceil(remainingMinutes / 60);

  return remainingHours === 1
    ? t("pattern.resumesInHour", {
        count: remainingHours,
        time: restartTimeLabel,
      })
    : t("pattern.resumesInHours", {
        count: remainingHours,
        time: restartTimeLabel,
      });
}

function getTodayRestartDateFromTimeLabel(
  timeLabel: string | undefined,
  now: Date,
): Date | undefined {
  if (!timeLabel) {
    return undefined;
  }

  const match = timeLabel.match(/^(\d{2}):(\d{2})$/u);

  if (!match) {
    return undefined;
  }

  const [, hourText, minuteText] = match;
  const restartDate = new Date(now);

  restartDate.setHours(Number(hourText), Number(minuteText), 0, 0);

  return restartDate;
}

function isSameLocalDay(left: Date, right: Date): boolean {
  return (
    left.getFullYear() === right.getFullYear() &&
    left.getMonth() === right.getMonth() &&
    left.getDate() === right.getDate()
  );
}

function formatTrafficStartDate(date: Date): string {
  return d(date, {
    dateStyle: "medium",
    timeStyle: "short",
  });
}

function formatTrafficRestartTime(date: Date): string {
  const formatted = d(date, {
    hour: "2-digit",
    minute: "2-digit",
  });

  return locale.value === "fr" ? formatted.replace(":", "h") : formatted;
}

function createCityZoneFlowNodes({
  graphNodes,
  graphEdges,
  positions,
  layout,
  compact,
}: {
  graphNodes: PatternGraphNode[];
  graphEdges: PatternGraphEdge[];
  positions: Map<string, { x: number; y: number }>;
  layout: PatternLayoutOptions;
  compact: boolean;
}): PatternCityZoneFlowNode[] {
  const groups = createCityZoneGroups(graphNodes, graphEdges);
  const minWidth = compact ? 92 : 118;
  const zonePadding = compact ? 70 : 96;
  const topOffset = compact ? 112 : 34;

  return groups
    .map((group, index): PatternCityZoneFlowNode | undefined => {
      const stationPositions = group.stationKeys
        .map((key) => positions.get(key))
        .filter((position): position is { x: number; y: number } =>
          Boolean(position),
        );

      if (stationPositions.length === 0) {
        return undefined;
      }

      const minX = Math.min(...stationPositions.map((position) => position.x));
      const maxX = Math.max(...stationPositions.map((position) => position.x));
      const minY = Math.min(...stationPositions.map((position) => position.y));
      const width = Math.max(minWidth, maxX - minX + zonePadding);
      const x = (minX + maxX) / 2 - width / 2;
      const y = minY - layout.nodeHeight / 2 - topOffset;

      return {
        id: `city-zone:${index}:${normalizeCityZoneKey(group.city)}:${group.stationKeys.join("|")}`,
        type: "city-zone",
        position: { x, y },
        draggable: false,
        selectable: false,
        connectable: false,
        focusable: false,
        class: "pattern-flow-city-zone-node",
        zIndex: 4,
        data: {
          key: group.stationKeys.join("|"),
          city: group.city,
          width,
          stationCount: new Set(group.stationKeys).size,
          layoutX: (minX + maxX) / 2,
          layoutY: minY,
          nodeX: x,
          nodeY: y,
        },
      };
    })
    .filter((node): node is PatternCityZoneFlowNode => Boolean(node));
}

function createCityZoneGroups(
  graphNodes: PatternGraphNode[],
  graphEdges: PatternGraphEdge[],
): PatternCityZoneGroup[] {
  const nodeById = new Map(graphNodes.map((node) => [node.id, node]));
  const nodeOrder = new Map(graphNodes.map((node, index) => [node.id, index]));
  const adjacency = new Map<string, Set<string>>();
  const groups: PatternCityZoneGroup[] = [];

  graphNodes.forEach((node) => {
    adjacency.set(node.id, new Set());
  });

  graphEdges.forEach((edge) => {
    const source = nodeById.get(edge.source);
    const target = nodeById.get(edge.target);
    const sourceCityKey = normalizeCityZoneKey(source?.city);
    const targetCityKey = normalizeCityZoneKey(target?.city);

    if (
      !source ||
      !target ||
      !sourceCityKey ||
      sourceCityKey !== targetCityKey
    ) {
      return;
    }

    adjacency.get(source.id)?.add(target.id);
    adjacency.get(target.id)?.add(source.id);
  });

  const visited = new Set<string>();

  graphNodes.forEach((node) => {
    const city = normalizeCityLabel(node.city);

    if (!city || visited.has(node.id)) {
      return;
    }

    const cityKey = normalizeCityZoneKey(city);
    const stationKeys: string[] = [];
    const queue = [node.id];
    visited.add(node.id);

    while (queue.length > 0) {
      const stationKey = queue.shift()!;
      const station = nodeById.get(stationKey);

      if (!station || normalizeCityZoneKey(station.city) !== cityKey) {
        continue;
      }

      stationKeys.push(stationKey);

      (adjacency.get(stationKey) ?? new Set()).forEach((nextStationKey) => {
        if (!visited.has(nextStationKey)) {
          visited.add(nextStationKey);
          queue.push(nextStationKey);
        }
      });
    }

    stationKeys.sort(
      (left, right) =>
        (nodeOrder.get(left) ?? Number.MAX_SAFE_INTEGER) -
        (nodeOrder.get(right) ?? Number.MAX_SAFE_INTEGER),
    );

    groups.push({
      city,
      stationKeys,
    });
  });

  return groups.sort(
    (left, right) =>
      Math.min(
        ...left.stationKeys.map(
          (stationKey) => nodeOrder.get(stationKey) ?? Number.MAX_SAFE_INTEGER,
        ),
      ) -
      Math.min(
        ...right.stationKeys.map(
          (stationKey) => nodeOrder.get(stationKey) ?? Number.MAX_SAFE_INTEGER,
        ),
      ),
  );
}

function normalizeCityLabel(value?: string): string | undefined {
  const normalized = value?.replace(/\s+/gu, " ").trim();

  return normalized || undefined;
}

function warnMissingNetexTown(
  pattern: DepartureCallingPattern | undefined,
  showCityZones: boolean,
): void {
  if (!showCityZones || !pattern?.lineTopology?.length) {
    return;
  }

  const missing = new Map<string, LineRouteStop>();

  pattern.lineTopology.forEach((sequence) => {
    sequence.stops.forEach((stop) => {
      const city = normalizeCityLabel(stop.city ?? stop.station.city);

      if (!city) {
        missing.set(stop.id, stop);
      }
    });
  });

  if (missing.size === 0) {
    return;
  }

  const warningKey = [
    pattern.departureId,
    ...Array.from(missing.keys()).sort(),
  ].join("|");

  if (missingNetexTownWarningKeys.has(warningKey)) {
    return;
  }

  missingNetexTownWarningKeys.add(warningKey);

  const sample = Array.from(missing.values())
    .slice(0, 5)
    .map((stop) => `${stop.label} (${stop.id})`);

  console.warn(
    "[DeparturePatternModal] NeTEx Town is missing for some stations; city zones will ignore them.",
    { count: missing.size, sample },
  );
}

function normalizeCityZoneKey(value?: string): string {
  return (value ?? "")
    .normalize("NFD")
    .replace(/\p{Diacritic}/gu, "")
    .replace(/\s+/gu, " ")
    .trim()
    .toLowerCase();
}

function createFlowEdge(
  edge: PatternGraphEdge,
  positions: Map<string, { x: number; y: number }>,
  showDistance = false,
  distanceLabelsLeaving = false,
  trafficImpact?: PatternTrafficImpact,
  roundedCurves = false,
): PatternFlowEdge {
  const { source, target } = getVisualFlowEdgeEndpoints(edge, positions);
  const distanceLabel =
    showDistance && edge.distanceKm !== undefined
      ? formatTransitDistance(edge.distanceKm)
      : undefined;

  return {
    id: `${edge.id}:${source}:${target}`,
    source,
    target,
    sourceHandle: "station-source",
    targetHandle: "station-target",
    type: roundedCurves ? "default" : "straight",
    pathOptions: roundedCurves ? { curvature: 0.32 } : undefined,
    selectable: false,
    focusable: Boolean(trafficImpact),
    interactionWidth: trafficImpact ? 26 : undefined,
    class: [
      edge.active ? "pattern-flow-edge--active" : "pattern-flow-edge--skipped",
      distanceLabel ? "pattern-flow-edge--distance" : "",
      distanceLabel && distanceLabelsLeaving
        ? "pattern-flow-edge--distance-leave"
        : "",
      trafficImpact ? "pattern-flow-edge--traffic" : "",
      trafficImpact?.kind === "interruption"
        ? "pattern-flow-edge--traffic-interruption"
        : "",
      trafficImpact?.kind === "disturbance"
        ? "pattern-flow-edge--traffic-disturbance"
        : "",
      roundedCurves ? "pattern-flow-edge--rounded-curves" : "",
    ],
    label: distanceLabel,
    labelShowBg: Boolean(distanceLabel),
    labelBgPadding: [7, 5],
    labelBgBorderRadius: 7,
    data: {
      trafficImpact,
    },
    style: {
      stroke: getPatternFlowEdgeStroke(edge, trafficImpact),
      strokeOpacity: trafficImpact?.kind === "interruption" ? 0.42 : undefined,
      strokeWidth: edge.active || trafficImpact ? 10 : 7,
    },
  };
}

function getPatternFlowEdgeStroke(
  edge: PatternGraphEdge,
  trafficImpact?: PatternTrafficImpact,
): string {
  if (trafficImpact?.kind === "interruption") {
    return TRAFFIC_INTERRUPTION_COLOR;
  }

  if (trafficImpact?.kind === "disturbance") {
    return TRAFFIC_DISTURBANCE_COLOR;
  }

  return edge.active ? "var(--line-color)" : "#cbd5e1";
}

function createFlowLightEdge(
  edge: PatternGraphEdge,
  positions: Map<string, { x: number; y: number }>,
  direction: { source: string; target: string } | undefined,
  order: number,
  count: number,
  roundedCurves = false,
): PatternFlowEdge {
  const flowEdge = createFlowEdge(
    edge,
    positions,
    false,
    false,
    undefined,
    roundedCurves,
  );
  const lightCycleSeconds = Math.max(8.5, count * 0.72);
  const lightDelay = (order * lightCycleSeconds) / Math.max(count, 1);

  return {
    ...flowEdge,
    id: `${flowEdge.id}:light`,
    class: getFlowLightEdgeClass({
      direction,
      visualEdge: flowEdge,
    }),
    style: {
      stroke: "color-mix(in srgb, var(--line-color), white 58%)",
      strokeOpacity: 0.42,
      strokeWidth: 14,
      "--flow-light-cycle": `${lightCycleSeconds.toFixed(2)}s`,
      "--flow-light-delay": `${lightDelay.toFixed(2)}s`,
    } as PatternFlowEdge["style"],
  };
}

function createTopologyLayout(
  nodes: PatternGraphNode[],
  edges: PatternGraphEdge[],
  calls: DepartureCall[],
  lineTopology: LineRouteSequence[],
  lineTopologyLayout: LineTopologyLayout | undefined,
  fullLine: boolean,
  layout: PatternLayoutOptions,
): PatternTopologyLayout | null {
  if (nodes.length === 0 || edges.length === 0) {
    return null;
  }

  const adjacency = createAdjacency(edges);
  const activeKeys = fullLine
    ? new Set<string>()
    : new Set(calls.filter((call) => call.served).map(createStationKey));
  const currentKey = fullLine
    ? undefined
    : calls.find((call) => call.current)
      ? createStationKey(calls.find((call) => call.current)!)
      : undefined;
  const destinationKey = fullLine ? undefined : getServedDestinationKey(calls);
  const preferStructuralSpine = graphHasCycle(nodes, edges);
  const topologyStationKeyById = createTopologyStationKeyById(lineTopology);
  const terminalKeys = new Set(
    nodes
      .filter((node) => (adjacency.get(node.id)?.size ?? 0) <= 1)
      .map((node) => node.id),
  );
  const terminalJunctionHints = createTerminalJunctionLayoutHints(
    lineTopologyLayout,
    topologyStationKeyById,
    adjacency,
  );
  const preferredMainPaths = createPreferredMainPaths(
    lineTopologyLayout,
    topologyStationKeyById,
    adjacency,
    terminalKeys,
  );
  const mainPath = chooseMainPath(
    nodes,
    adjacency,
    activeKeys,
    currentKey,
    destinationKey,
    preferStructuralSpine,
    preferredMainPaths,
    terminalJunctionHints,
  );

  if (mainPath.length < 2) {
    return null;
  }

  if (!fullLine && preferredMainPaths.length === 0) {
    orientPathTowardDeparture(mainPath, calls);
  }

  const positions = new Map<string, { x: number; y: number }>();
  const visibleEdges = new Set<string>();
  const syntheticEdges: PatternGraphEdge[] = [];
  const placed = new Set<string>();
  const branchLayoutHints = createBranchLayoutHints(lineTopology);
  const loopLayoutHints = createLoopLayoutHints(
    lineTopologyLayout,
    topologyStationKeyById,
    nodes,
  );

  let mainPathX = 0;

  mainPath.forEach((key, index) => {
    positions.set(key, { x: mainPathX, y: 0 });
    placed.add(key);

    const nextKey = mainPath[index + 1];

    if (nextKey) {
      mainPathX += getLayoutStopGap(layout, key, nextKey);
    }
  });
  addPathEdges(mainPath, visibleEdges);

  // Resolve anchored corridors while the common spine is the only placed
  // geometry. This keeps their lane selection local and prevents later fork
  // placement from forcing a secondary corridor onto a distant lane.
  while (
    placeLoopCorridor(
      loopLayoutHints,
      positions,
      placed,
      visibleEdges,
      layout,
    )
  ) {
    // Keep placing all resolvable two-anchor corridors before other branches.
  }

  placeTerminalJunctionFans({
    nodes,
    adjacency,
    mainPath,
    terminalKeys,
    terminalJunctionHints,
    positions,
    placed,
    visibleEdges,
    layout,
  });
  if ((lineTopologyLayout?.loops.length ?? 0) === 0) {
    placeSimpleTerminalForks({
      nodes,
      adjacency,
      mainPath,
      positions,
      placed,
      visibleEdges,
      layout,
    });
  }
  placeSameDirectionForks(
    branchLayoutHints,
    positions,
    placed,
    visibleEdges,
    layout,
  );
  placeTerminalJunctionFans({
    nodes,
    adjacency,
    mainPath,
    terminalKeys,
    terminalJunctionHints,
    positions,
    placed,
    visibleEdges,
    layout,
    reflowExisting: true,
  });

  const laneSteps = createLaneSteps();
  let guard = 0;

  while (placed.size < nodes.length && guard < nodes.length * 2) {
    guard += 1;

    if (
      placeLoopCorridor(
        loopLayoutHints,
        positions,
        placed,
        visibleEdges,
        layout,
      )
    ) {
      placeSameDirectionForks(
        branchLayoutHints,
        positions,
        placed,
        visibleEdges,
        layout,
      );
      continue;
    }

    const connectorPath = findBestConnectorPath(nodes, adjacency, placed);

    if (connectorPath) {
      placeConnectorPath(
        connectorPath,
        positions,
        placed,
        visibleEdges,
        laneSteps,
        layout,
      );
      placeSameDirectionForks(
        branchLayoutHints,
        positions,
        placed,
        visibleEdges,
        layout,
      );
      continue;
    }

    const branchPath = findBestBranchPath(nodes, adjacency, placed);

    if (!branchPath) {
      break;
    }

    placeBranchPath(
      branchPath,
      positions,
      placed,
      visibleEdges,
      laneSteps,
      destinationKey,
      branchLayoutHints,
      layout,
    );
    placeSameDirectionForks(
      branchLayoutHints,
      positions,
      placed,
      visibleEdges,
      layout,
    );
  }

  placeRemainingComponents(
    nodes,
    adjacency,
    positions,
    placed,
    visibleEdges,
    laneSteps,
    destinationKey,
    layout,
  );
  addGraphEdges(edges, visibleEdges);
  return {
    positions,
    syntheticEdges,
    visibleEdges,
    degrees: createDegreesFromEdges(edges),
  };
}

function createFallbackTopologyLayout(
  graph: {
    nodes: PatternGraphNode[];
    edges: PatternGraphEdge[];
  },
  layout: PatternLayoutOptions,
): PatternTopologyLayout {
  const visibleEdges = new Set(
    graph.edges.map((edge) => createEdgeKey(edge.source, edge.target)),
  );

  return {
    positions: createDagreLayout(graph, layout),
    syntheticEdges: [],
    visibleEdges,
    degrees: createDegreesFromEdgeKeys(visibleEdges),
  };
}

function createAdjacency(edges: PatternGraphEdge[]): Map<string, Set<string>> {
  const adjacency = new Map<string, Set<string>>();

  edges.forEach((edge) => {
    addNeighbor(adjacency, edge.source, edge.target);
    addNeighbor(adjacency, edge.target, edge.source);
  });

  return adjacency;
}

function getLayoutStopGap(
  layout: PatternLayoutOptions,
  source?: string,
  target?: string,
): number {
  if (!source || !target) {
    return layout.stopGap;
  }

  return (
    layout.edgeGapByKey?.get(createEdgeKey(source, target)) ?? layout.stopGap
  );
}

function getPathSpan(path: string[], layout: PatternLayoutOptions): number {
  return path.slice(0, -1).reduce((span, source, index) => {
    const target = path[index + 1];

    return span + getLayoutStopGap(layout, source, target);
  }, 0);
}

function getPathOffsetToIndex(
  path: string[],
  targetIndex: number,
  layout: PatternLayoutOptions,
): number {
  return getPathSpan(path.slice(0, targetIndex + 1), layout);
}

function addNeighbor(
  adjacency: Map<string, Set<string>>,
  source: string,
  target: string,
): void {
  if (!adjacency.has(source)) {
    adjacency.set(source, new Set<string>());
  }

  adjacency.get(source)!.add(target);
}

function chooseMainPath(
  nodes: PatternGraphNode[],
  adjacency: Map<string, Set<string>>,
  activeKeys: Set<string>,
  currentKey?: string,
  destinationKey?: string,
  preferStructuralSpine = false,
  preferredMainPaths: string[][] = [],
  terminalJunctionHints: PatternTerminalJunctionLayoutHint[] = [],
): string[] {
  const terminals = nodes
    .filter((node) => (adjacency.get(node.id)?.size ?? 0) <= 1)
    .map((node) => node.id);
  const candidates =
    terminals.length >= 2 ? terminals : nodes.map((node) => node.id);
  let bestPath: string[] = [];
  let bestScore = Number.NEGATIVE_INFINITY;

  const evaluatePath = (path: string[], preferred: boolean) => {
    const score =
      scoreMainPath(
        path,
        activeKeys,
        currentKey,
        destinationKey,
        preferStructuralSpine,
      ) + (preferred ? 1_000_000 + path.length * 120 : 0);

    if (score > bestScore) {
      bestScore = score;
      bestPath = path;
    }
  };

  preferredMainPaths.forEach((path) => {
    if (path.length >= 3) {
      evaluatePath(path, true);
    }
  });

  // A semantic terminus can still have several outgoing arms in the
  // schematic graph. Treat its longest arm as a preferred spine, so the
  // terminus remains an endpoint of the drawing instead of being selected as
  // the middle of a longest terminal-to-terminal path. This applies only to
  // the full-line graph, where there is no departure direction to preserve.
  if (activeKeys.size === 0 && !currentKey && terminalJunctionHints.length > 0) {
    const terminalKeys = new Set(terminals);

    terminalJunctionHints.forEach((hint) => {
      hint.arms.forEach((arm) => {
        const firstKey = arm.stationKeys[1];
        if (!firstKey) {
          return;
        }

        const armPath = findTerminalArmPath({
          junctionKey: hint.junctionKey,
          firstKey,
          adjacency,
          terminalKeys,
        });

        if (!armPath || armPath.length < 3) {
          return;
        }

        evaluatePath(
          hint.direction === "forward" ? armPath : [...armPath].reverse(),
          true,
        );
      });
    });
  }

  candidates.forEach((source, sourceIndex) => {
    candidates.slice(sourceIndex + 1).forEach((target) => {
      const path = findShortestPath(source, (key) => key === target, adjacency);

      if (!path) {
        return;
      }

      evaluatePath(path, false);
    });
  });

  return bestPath;
}

function scoreMainPath(
  path: string[],
  activeKeys: Set<string>,
  currentKey?: string,
  destinationKey?: string,
  preferStructuralSpine = false,
): number {
  const activeCount = path.filter((key) => activeKeys.has(key)).length;
  const currentBonus = currentKey && path.includes(currentKey) ? 400 : 0;
  const destinationIndex = destinationKey ? path.indexOf(destinationKey) : -1;
  const destinationTerminalBonus =
    destinationIndex === 0 || destinationIndex === path.length - 1 ? 1200 : 0;
  const destinationPresenceBonus = destinationIndex >= 0 ? 500 : 0;

  if (preferStructuralSpine) {
    return (
      path.length * 90 +
      activeCount * 20 +
      currentBonus * 0.1 +
      destinationPresenceBonus * 0.15 +
      destinationTerminalBonus * 0.15
    );
  }

  return (
    path.length * 8 +
    activeCount * 120 +
    currentBonus +
    destinationPresenceBonus +
    destinationTerminalBonus
  );
}

function graphHasCycle(
  nodes: PatternGraphNode[],
  edges: PatternGraphEdge[],
): boolean {
  return (
    edges.length - nodes.length + countConnectedComponents(nodes, edges) > 0
  );
}

function countConnectedComponents(
  nodes: PatternGraphNode[],
  edges: PatternGraphEdge[],
): number {
  const adjacency = createAdjacency(edges);
  const visited = new Set<string>();
  let components = 0;

  nodes.forEach((node) => {
    if (visited.has(node.id)) {
      return;
    }

    components += 1;
    const queue = [node.id];

    while (queue.length > 0) {
      const current = queue.shift()!;

      if (visited.has(current)) {
        continue;
      }

      visited.add(current);

      Array.from(adjacency.get(current) ?? []).forEach((neighbor) => {
        if (!visited.has(neighbor)) {
          queue.push(neighbor);
        }
      });
    }
  });

  return components;
}

function orientPathTowardDeparture(
  path: string[],
  calls: DepartureCall[],
): void {
  const servedCalls = calls.filter((call) => call.served);
  const firstServed = servedCalls[0]
    ? createStationKey(servedCalls[0])
    : undefined;
  const lastServedCall = servedCalls[servedCalls.length - 1];
  const lastServed = lastServedCall
    ? createStationKey(lastServedCall)
    : undefined;

  if (!firstServed || !lastServed) {
    return;
  }

  const firstIndex = path.indexOf(firstServed);
  const lastIndex = path.indexOf(lastServed);

  if (firstIndex >= 0 && lastIndex >= 0 && lastIndex < firstIndex) {
    path.reverse();
  }
}

type PatternBranchLayoutHint = LineRouteBranchLayout & {
  junctionKey: string;
  terminalKey: string;
  trunkKey?: string;
  stationKeys: string[];
};

type PatternTerminalJunctionArmHint =
  LineTopologyTerminalJunctionLayout["arms"][number] & {
    anchorKey: string;
    stationKeys: string[];
  };

type PatternTerminalJunctionLayoutHint = Omit<
  LineTopologyTerminalJunctionLayout,
  "junctionStationId" | "arms"
> & {
  junctionKey: string;
  arms: PatternTerminalJunctionArmHint[];
};

function createBranchLayoutHints(
  lineTopology: LineRouteSequence[],
): Map<string, PatternBranchLayoutHint> {
  const hints = new Map<string, PatternBranchLayoutHint>();
  const stationKeyById = new Map<string, string>();

  lineTopology.forEach((sequence) => {
    sequence.stops.forEach((stop) => {
      stationKeyById.set(stop.id, createStationKey(stop));
    });
  });

  lineTopology.forEach((sequence) => {
    if (!sequence.branchLayout || sequence.stops.length < 2) {
      return;
    }

    const junction = sequence.stops[0];
    const terminal = sequence.stops[sequence.stops.length - 1];
    const junctionKey = createStationKey(junction);
    const terminalKey = createStationKey(terminal);
    const stationKeys = sequence.stops.map(createStationKey);

    hints.set(createBranchLayoutHintKey(junctionKey, terminalKey), {
      ...sequence.branchLayout,
      junctionKey,
      terminalKey,
      trunkKey: sequence.branchLayout.trunkStationId
        ? stationKeyById.get(sequence.branchLayout.trunkStationId)
        : undefined,
      stationKeys,
    });
  });

  return hints;
}

function createTerminalJunctionLayoutHints(
  lineTopologyLayout: LineTopologyLayout | undefined,
  stationKeyById: Map<string, string>,
  adjacency: Map<string, Set<string>>,
): PatternTerminalJunctionLayoutHint[] {
  return (lineTopologyLayout?.terminalJunctions ?? []).flatMap((junction) => {
    const junctionKey = stationKeyById.get(junction.junctionStationId);
    if (!junctionKey) {
      return [];
    }

    const arms = junction.arms.flatMap((arm) => {
      const stationKeys = arm.stationIds.flatMap(
        (stationId) => stationKeyById.get(stationId) ?? [],
      );
      const anchorKey = stationKeyById.get(arm.anchorStationId) ?? stationKeys.at(-1);

      if (
        !anchorKey ||
        stationKeys.length < 2 ||
        stationKeys[0] !== junctionKey ||
        !stationKeys.every((key, index) => {
          const nextKey = stationKeys[index + 1];
          return !nextKey || adjacency.get(key)?.has(nextKey);
        })
      ) {
        return [];
      }

      return [{ ...arm, anchorKey, stationKeys }];
    });

    return arms.length >= 3
      ? [{ ...junction, junctionKey, arms }]
      : [];
  });
}

function createTopologyStationKeyById(
  lineTopology: LineRouteSequence[],
): Map<string, string> {
  const stationKeyById = new Map<string, string>();

  lineTopology.forEach((sequence) => {
    sequence.stops.forEach((stop) => {
      stationKeyById.set(stop.id, createStationKey(stop));
    });
  });

  return stationKeyById;
}

function createPreferredMainPaths(
  lineTopologyLayout: LineTopologyLayout | undefined,
  stationKeyById: Map<string, string>,
  adjacency: Map<string, Set<string>>,
  terminalKeys: Set<string>,
): string[][] {
  if (!lineTopologyLayout?.loops.length) {
    return [];
  }

  return lineTopologyLayout.loops.flatMap((loop) =>
    (loop.laneHints ?? [])
      .filter((hint) => hint.role === "common")
      .map((hint) =>
        extendPreferredMainPath(
          normalizeLoopStationKeys(
            hint.stationIds.flatMap(
              (stationId) => stationKeyById.get(stationId) ?? [],
            ),
          ),
          adjacency,
        ),
      )
      .filter(
        (path) =>
          path.length >= 3 &&
          countPathTerminals(path, terminalKeys) >= 2 &&
          path.every((key, index) => {
            const nextKey = path[index + 1];

            return !nextKey || adjacency.get(key)?.has(nextKey);
          }),
      ),
  );
}

function getPatternSpacingOptions(): PatternSpacingOptions {
  const realisticMinGapCoefficient = clampFiniteNumber(
    props.patternRealisticMinGapCoefficient,
    DEFAULT_REALISTIC_MIN_STOP_GAP_COEFFICIENT,
    MIN_REALISTIC_STOP_GAP_COEFFICIENT,
    MAX_REALISTIC_MIN_STOP_GAP_COEFFICIENT,
  );

  return {
    compactBranchGap: clampFiniteNumber(
      props.patternCompactBranchGap,
      DEFAULT_COMPACT_BRANCH_GAP,
      MIN_COMPACT_BRANCH_GAP,
      MAX_COMPACT_BRANCH_GAP,
    ),
    compactForkGap: clampFiniteNumber(
      props.patternCompactForkGap,
      DEFAULT_COMPACT_FORK_GAP,
      MIN_COMPACT_FORK_GAP,
      MAX_COMPACT_FORK_GAP,
    ),
    realisticMinGapCoefficient,
    realisticMaxGapCoefficient: clampFiniteNumber(
      props.patternRealisticMaxGapCoefficient,
      DEFAULT_REALISTIC_MAX_STOP_GAP_COEFFICIENT,
      Math.max(
        MIN_REALISTIC_MAX_STOP_GAP_COEFFICIENT,
        realisticMinGapCoefficient,
      ),
      MAX_REALISTIC_STOP_GAP_COEFFICIENT,
    ),
  };
}

function clampFiniteNumber(
  value: unknown,
  fallback: number,
  min: number,
  max: number,
): number {
  return typeof value === "number" && Number.isFinite(value)
    ? clampNumber(value, min, max)
    : fallback;
}

function countPathTerminals(path: string[], terminalKeys: Set<string>): number {
  return path.filter((key) => terminalKeys.has(key)).length;
}

function extendPreferredMainPath(
  path: string[],
  adjacency: Map<string, Set<string>>,
): string[] {
  if (path.length < 2) {
    return path;
  }

  const pathSet = new Set(path);
  const startArm = findSimpleTerminalArm({
    anchor: path[0],
    blockedNeighbor: path[1],
    pathSet,
    adjacency,
  });
  const endArm = findSimpleTerminalArm({
    anchor: path[path.length - 1],
    blockedNeighbor: path[path.length - 2],
    pathSet,
    adjacency,
  });

  return [...startArm.slice(1).reverse(), ...path, ...endArm.slice(1)];
}

function findSimpleTerminalArm(params: {
  anchor: string;
  blockedNeighbor: string;
  pathSet: Set<string>;
  adjacency: Map<string, Set<string>>;
}): string[] {
  let bestArm = [params.anchor];

  Array.from(params.adjacency.get(params.anchor) ?? []).forEach((neighbor) => {
    if (neighbor === params.blockedNeighbor || params.pathSet.has(neighbor)) {
      return;
    }

    const arm = walkSimpleTerminalArm({
      anchor: params.anchor,
      first: neighbor,
      pathSet: params.pathSet,
      adjacency: params.adjacency,
    });

    if (arm && arm.length > bestArm.length) {
      bestArm = arm;
    }
  });

  return bestArm;
}

function walkSimpleTerminalArm(params: {
  anchor: string;
  first: string;
  pathSet: Set<string>;
  adjacency: Map<string, Set<string>>;
}): string[] | undefined {
  const path = [params.anchor];
  let previous = params.anchor;
  let current = params.first;

  while (true) {
    if (params.pathSet.has(current)) {
      return undefined;
    }

    path.push(current);

    const neighbors = Array.from(params.adjacency.get(current) ?? []);

    if (neighbors.length <= 1) {
      return path;
    }

    if (neighbors.length !== 2) {
      return undefined;
    }

    const next = neighbors.find((neighbor) => neighbor !== previous);

    if (!next) {
      return undefined;
    }

    previous = current;
    current = next;
  }
}

function createLoopLayoutHints(
  lineTopologyLayout: LineTopologyLayout | undefined,
  stationKeyById: Map<string, string>,
  nodes: PatternGraphNode[],
): PatternLoopLayoutHint[] {
  if (!lineTopologyLayout?.loops.length) {
    return [];
  }

  const nodeByKey = new Map(nodes.map((node) => [node.id, node]));
  const candidates: Array<
    PatternLoopLayoutHint & {
      averageLatitude: number | undefined;
      index: number;
    }
  > = lineTopologyLayout.loops
    .flatMap((loop, index) => {
      if (loop.laneHints?.length) {
        return loop.laneHints.flatMap((laneHint, laneHintIndex) => {
          const stationKeys = normalizeLoopStationKeys(
            laneHint.stationIds.flatMap(
              (stationId) => stationKeyById.get(stationId) ?? [],
            ),
          );
          const anchorKeySet = new Set(
            laneHint.anchorStationIds.flatMap(
              (stationId) => stationKeyById.get(stationId) ?? [],
            ),
          );
          const anchorKeys = stationKeys.filter((key) => anchorKeySet.has(key));

          if (stationKeys.length < 2 || new Set(anchorKeys).size < 2) {
            return [];
          }

          return [
            {
              id: `${loop.id}:${laneHint.id}`,
              kind: loop.kind,
              role: laneHint.role,
              side: laneHint.side,
              stationKeys,
              anchorKeys,
              lane: laneHint.lane,
              explicitLane: true,
              averageLatitude: getAverageLoopLatitude(stationKeys, nodeByKey),
              index: index * 100 + laneHintIndex,
            },
          ];
        });
      }

      const stationKeys = normalizeLoopStationKeys(
        (loop.orderedStationIds?.length
          ? loop.orderedStationIds
          : loop.stationIds
        ).flatMap((stationId) => stationKeyById.get(stationId) ?? []),
      );
      const anchorKeySet = new Set(
        (loop.orderedAnchorStationIds?.length
          ? loop.orderedAnchorStationIds
          : loop.anchorStationIds
        ).flatMap((stationId) => stationKeyById.get(stationId) ?? []),
      );
      const anchorKeys = stationKeys.filter((key) => anchorKeySet.has(key));

      if (stationKeys.length < 3 || new Set(anchorKeys).size < 2) {
        return [];
      }

      return [
        {
          id: loop.id,
          kind: loop.kind,
          stationKeys,
          anchorKeys,
          lane: 0,
          averageLatitude: getAverageLoopLatitude(stationKeys, nodeByKey),
          index,
        },
      ];
    })
    .sort((left, right) => {
      if (
        left.averageLatitude !== undefined &&
        right.averageLatitude !== undefined
      ) {
        return right.averageLatitude - left.averageLatitude;
      }

      if (left.averageLatitude !== undefined) {
        return -1;
      }

      if (right.averageLatitude !== undefined) {
        return 1;
      }

      return left.index - right.index;
    });

  return candidates.map(({ averageLatitude, index, ...hint }, laneIndex) => ({
    ...hint,
    lane: hint.explicitLane ? hint.lane : createLoopLane(laneIndex),
  }));
}

function normalizeLoopStationKeys(stationKeys: string[]): string[] {
  const normalized = stationKeys.filter(
    (key, index) => index === 0 || key !== stationKeys[index - 1],
  );

  if (
    normalized.length > 1 &&
    normalized[0] === normalized[normalized.length - 1]
  ) {
    normalized.pop();
  }

  return normalized;
}

function getAverageLoopLatitude(
  stationKeys: string[],
  nodeByKey: Map<string, PatternGraphNode>,
): number | undefined {
  const latitudes = stationKeys
    .map((key) => nodeByKey.get(key)?.lat)
    .filter((latitude): latitude is number => Number.isFinite(latitude));

  if (latitudes.length === 0) {
    return undefined;
  }

  return (
    latitudes.reduce((total, latitude) => total + latitude, 0) /
    latitudes.length
  );
}

function createLoopLane(index: number): number {
  const magnitude = Math.floor(index / 2) + 1;

  return index % 2 === 0 ? -magnitude : magnitude;
}

function createBranchLayoutHintKey(
  junctionKey: string,
  terminalKey: string,
): string {
  return `${junctionKey}::${terminalKey}`;
}

function placeTerminalJunctionFans(params: {
  nodes: PatternGraphNode[];
  adjacency: Map<string, Set<string>>;
  mainPath: string[];
  terminalKeys: Set<string>;
  terminalJunctionHints: PatternTerminalJunctionLayoutHint[];
  reflowExisting?: boolean;
  positions: Map<string, PatternLayoutPosition>;
  placed: Set<string>;
  visibleEdges: Set<string>;
  layout: PatternLayoutOptions;
}): void {
  params.terminalJunctionHints.forEach((hint) => {
    const junctionPosition = params.positions.get(hint.junctionKey);
    if (!junctionPosition || hint.arms.length < 3) {
      return;
    }

    const junctionIndex = params.mainPath.indexOf(hint.junctionKey);
    const mainPathNeighbor =
      junctionIndex >= 0
        ? params.mainPath[
            hint.direction === "forward"
              ? junctionIndex + 1
              : junctionIndex - 1
          ]
        : undefined;
    const mainArm = hint.arms.find((arm) =>
      arm.stationKeys.slice(1).includes(mainPathNeighbor ?? ""),
    );
    const orderedArms = [...hint.arms].sort(
      (left, right) =>
        terminalJunctionSideRank(left.side) -
          terminalJunctionSideRank(right.side) ||
        (left.side === "lower" && right.side === "lower"
          ? (right.angleDegrees ?? 0) - (left.angleDegrees ?? 0)
          : (left.angleDegrees ?? 0) - (right.angleDegrees ?? 0)) ||
        left.id.localeCompare(right.id),
    );
    const mainArmIndex = Math.max(0, orderedArms.indexOf(mainArm ?? orderedArms[0]));
    const direction = hint.direction === "forward" ? 1 : -1;
    const armPaths = new Map(
      orderedArms.map((arm) => {
        const firstKey = arm.stationKeys[1];
        const armPath = firstKey
          ? findTerminalArmPath({
              junctionKey: hint.junctionKey,
              firstKey,
              adjacency: params.adjacency,
              terminalKeys: params.terminalKeys,
            }) ?? arm.stationKeys
          : arm.stationKeys;

        return [arm.id, armPath] as const;
      }),
    );

    if (params.reflowExisting) {
      orderedArms.forEach((arm) => {
        if (arm.id === (mainArm ?? orderedArms[0]).id) {
          return;
        }

        armPaths
          .get(arm.id)
          ?.slice(1)
          .forEach((key) => params.positions.delete(key));
      });
    }

    orderedArms.forEach((arm, armIndex) => {
      const firstKey = arm.stationKeys[1];
      if (!firstKey) {
        return;
      }

      const armPath = armPaths.get(arm.id) ?? arm.stationKeys;

      addPathEdges(armPath, params.visibleEdges);

      const laneOffset = armIndex - mainArmIndex;
      if (laneOffset === 0) {
        armPath.slice(1).forEach((key) => params.placed.add(key));
        return;
      }

      const side = laneOffset < 0 ? -1 : 1;
      const y = findClearSameDirectionForkY({
        path: armPath,
        junctionPosition,
        direction,
        side,
        initialMagnitude: Math.max(1, Math.abs(laneOffset)),
        positions: params.positions,
        layout: params.layout,
      });

      createDirectionalPathPlacementProposals({
        path: armPath,
        anchorPosition: junctionPosition,
        direction,
        y,
        positions: params.positions,
        layout: params.layout,
      }).forEach(({ key, position }) => {
        params.positions.set(key, position);
      });
      armPath.slice(1).forEach((key) => params.placed.add(key));
    });

  });
}

function terminalJunctionSideRank(
  side: PatternTerminalJunctionArmHint["side"],
): number {
  if (side === "upper") {
    return 0;
  }

  if (side === "lower") {
    return 2;
  }

  return 1;
}

function placeSameDirectionForks(
  branchLayoutHints: Map<string, PatternBranchLayoutHint>,
  positions: Map<string, { x: number; y: number }>,
  placed: Set<string>,
  visibleEdges: Set<string>,
  layout: PatternLayoutOptions,
): void {
  const hintsByJunction = new Map<string, PatternBranchLayoutHint[]>();

  branchLayoutHints.forEach((hint) => {
    if (hint.kind !== "same-direction-fork") {
      return;
    }

    const current = hintsByJunction.get(hint.junctionKey) ?? [];
    current.push(hint);
    hintsByJunction.set(hint.junctionKey, current);
  });

  hintsByJunction.forEach((hints, junctionKey) => {
    const junctionPosition = positions.get(junctionKey);
    const trunkKey = hints.find((hint) => hint.trunkKey)?.trunkKey;
    const trunkPosition = trunkKey ? positions.get(trunkKey) : undefined;

    if (!junctionPosition || !trunkPosition || hints.length < 2) {
      return;
    }

    const direction = junctionPosition.x <= trunkPosition.x ? -1 : 1;
    const forkLaneCountBySide = new Map<number, number>();

    hints.forEach((hint, hintIndex) => {
      const side = resolveForkSide(hint, hintIndex);
      const laneCount = forkLaneCountBySide.get(side) ?? 0;
      const initialMagnitude = laneCount + 1;
      const y = findClearSameDirectionForkY({
        path: hint.stationKeys,
        junctionPosition,
        direction,
        side,
        initialMagnitude,
        positions,
        layout,
      });
      const laneMagnitude =
        Math.max(
          1,
          Math.round(
            Math.abs(y - junctionPosition.y) / layout.sameDirectionForkGap,
          ),
        ) || initialMagnitude;

      forkLaneCountBySide.set(side, Math.max(laneCount + 1, laneMagnitude));

      createDirectionalPathPlacementProposals({
        path: hint.stationKeys,
        anchorPosition: junctionPosition,
        direction,
        y,
        positions,
        layout,
      }).forEach(({ key, position }) => {
        positions.set(key, position);
      });
      hint.stationKeys.slice(1).forEach((key) => placed.add(key));
      addPathEdges(hint.stationKeys, visibleEdges);
    });
  });
}

function resolveForkSide(hint: PatternBranchLayoutHint, index: number): 1 | -1 {
  if (hint.side === "upper") {
    return -1;
  }

  if (hint.side === "lower") {
    return 1;
  }

  return index % 2 === 0 ? -1 : 1;
}

function placeSimpleTerminalForks(params: {
  nodes: PatternGraphNode[];
  adjacency: Map<string, Set<string>>;
  mainPath: string[];
  positions: Map<string, PatternLayoutPosition>;
  placed: Set<string>;
  visibleEdges: Set<string>;
  layout: PatternLayoutOptions;
}): void {
  const nodeByKey = new Map(params.nodes.map((node) => [node.id, node]));
  const terminalKeys = new Set(
    params.nodes
      .filter((node) => (params.adjacency.get(node.id)?.size ?? 0) <= 1)
      .map((node) => node.id),
  );

  for (let pass = 0; pass < 2; pass += 1) {
    params.mainPath.forEach((junctionKey, mainPathIndex) => {
      const previousMainKey = params.mainPath[mainPathIndex - 1];
      const nextMainKey = params.mainPath[mainPathIndex + 1];

      if (!previousMainKey || !nextMainKey) {
        return;
      }

      const neighbors = Array.from(params.adjacency.get(junctionKey) ?? []);
      const offMainNeighbors = neighbors.filter(
        (neighbor) => neighbor !== previousMainKey && neighbor !== nextMainKey,
      );

      if (neighbors.length !== 3 || offMainNeighbors.length !== 1) {
        return;
      }

      const offMainPath = findTerminalArmPath({
        junctionKey,
        firstKey: offMainNeighbors[0],
        adjacency: params.adjacency,
        terminalKeys,
      });

      if (!offMainPath || offMainPath.length < 3) {
        return;
      }

      const previousMainPath = params.mainPath
        .slice(0, mainPathIndex + 1)
        .reverse();
      const nextMainPath = params.mainPath.slice(mainPathIndex);
      const siblingMainPath = chooseSameSideMainArm({
        junctionKey,
        offMainPath,
        previousMainPath,
        nextMainPath,
        nodeByKey,
      });

      if (!siblingMainPath) {
        return;
      }

      const junctionPosition = params.positions.get(junctionKey);

      if (!junctionPosition) {
        return;
      }

      const branchDirection =
        (params.positions.get(siblingMainPath[siblingMainPath.length - 1])?.x ??
          junctionPosition.x) >= junctionPosition.x
          ? 1
          : -1;
      const [upperPath, lowerPath] = orderForkArmsByLatitude(
        siblingMainPath,
        offMainPath,
        nodeByKey,
      );

      if (Math.abs(junctionPosition.y) >= MIN_STATION_LAYOUT_SEPARATION) {
        placeNestedSimpleTerminalFork({
          junctionPosition,
          siblingMainPath,
          offMainPath,
          direction: branchDirection,
          positions: params.positions,
          placed: params.placed,
          visibleEdges: params.visibleEdges,
          layout: params.layout,
        });
        return;
      }

      const forkLaneMagnitude = 1;

      applyDirectionalPathPositions({
        path: upperPath,
        anchorPosition: junctionPosition,
        direction: branchDirection,
        y:
          junctionPosition.y -
          params.layout.sameDirectionForkGap * forkLaneMagnitude,
        positions: params.positions,
        layout: params.layout,
        overwriteExisting: true,
      });
      applyDirectionalPathPositions({
        path: lowerPath,
        anchorPosition: junctionPosition,
        direction: branchDirection,
        y:
          junctionPosition.y +
          params.layout.sameDirectionForkGap * forkLaneMagnitude,
        positions: params.positions,
        layout: params.layout,
        overwriteExisting: true,
      });
      upperPath.slice(1).forEach((key) => params.placed.add(key));
      lowerPath.slice(1).forEach((key) => params.placed.add(key));
      addPathEdges(upperPath, params.visibleEdges);
      addPathEdges(lowerPath, params.visibleEdges);
    });
  }
}

function placeNestedSimpleTerminalFork(params: {
  junctionPosition: PatternLayoutPosition;
  siblingMainPath: string[];
  offMainPath: string[];
  direction: 1 | -1;
  positions: Map<string, PatternLayoutPosition>;
  placed: Set<string>;
  visibleEdges: Set<string>;
  layout: PatternLayoutOptions;
}): void {
  const branchY = findClearNestedForkY({
    junctionPosition: params.junctionPosition,
    path: params.offMainPath,
    direction: params.direction,
    positions: params.positions,
    layout: params.layout,
  });

  applyDirectionalPathPositions({
    path: params.siblingMainPath,
    anchorPosition: params.junctionPosition,
    direction: params.direction,
    y: params.junctionPosition.y,
    positions: params.positions,
    layout: params.layout,
    overwriteExisting: true,
  });
  applyDirectionalPathPositions({
    path: params.offMainPath,
    anchorPosition: params.junctionPosition,
    direction: params.direction,
    y: branchY,
    positions: params.positions,
    layout: params.layout,
    overwriteExisting: true,
  });
  params.siblingMainPath.slice(1).forEach((key) => params.placed.add(key));
  params.offMainPath.slice(1).forEach((key) => params.placed.add(key));
  addPathEdges(params.siblingMainPath, params.visibleEdges);
  addPathEdges(params.offMainPath, params.visibleEdges);
}

function findClearNestedForkY(params: {
  junctionPosition: PatternLayoutPosition;
  path: string[];
  direction: 1 | -1;
  positions: Map<string, PatternLayoutPosition>;
  layout: PatternLayoutOptions;
}): number {
  const towardCenter = params.junctionPosition.y < 0 ? 1 : -1;
  const nestedGap = Math.max(
    MIN_STATION_LAYOUT_SEPARATION * 1.4,
    params.layout.sameDirectionForkGap * 0.78,
  );
  const ignoredKeys = new Set(params.path);

  for (
    let magnitude = 1;
    magnitude <= MAX_LAYOUT_LANE_COLLISION_ATTEMPTS;
    magnitude += 1
  ) {
    const y = params.junctionPosition.y + towardCenter * nestedGap * magnitude;
    const proposals = createDirectionalPathOverwriteProposals({
      path: params.path,
      anchorPosition: params.junctionPosition,
      direction: params.direction,
      y,
      layout: params.layout,
    });

    if (
      !hasLayoutPlacementCollision(proposals, params.positions, ignoredKeys)
    ) {
      return y;
    }
  }

  return (
    params.junctionPosition.y +
    towardCenter * nestedGap * (MAX_LAYOUT_LANE_COLLISION_ATTEMPTS + 1)
  );
}

function findTerminalArmPath(params: {
  junctionKey: string;
  firstKey: string;
  adjacency: Map<string, Set<string>>;
  terminalKeys: Set<string>;
}): string[] | undefined {
  const allowed = collectArmComponent(
    params.firstKey,
    params.junctionKey,
    params.adjacency,
  );
  let bestPath: string[] | undefined;

  allowed.forEach((key) => {
    if (!params.terminalKeys.has(key)) {
      return;
    }

    const path = findShortestPathRestricted(
      params.firstKey,
      (candidate) => candidate === key,
      params.adjacency,
      allowed,
    );

    if (path && (!bestPath || path.length > bestPath.length)) {
      bestPath = path;
    }
  });

  return bestPath ? [params.junctionKey, ...bestPath] : undefined;
}

function collectArmComponent(
  startKey: string,
  blockedKey: string,
  adjacency: Map<string, Set<string>>,
): Set<string> {
  const component = new Set<string>();
  const queue = [startKey];

  while (queue.length > 0) {
    const key = queue.shift()!;

    if (key === blockedKey || component.has(key)) {
      continue;
    }

    component.add(key);
    Array.from(adjacency.get(key) ?? []).forEach((neighbor) => {
      if (neighbor !== blockedKey && !component.has(neighbor)) {
        queue.push(neighbor);
      }
    });
  }

  return component;
}

function chooseSameSideMainArm(params: {
  junctionKey: string;
  offMainPath: string[];
  previousMainPath: string[];
  nextMainPath: string[];
  nodeByKey: Map<string, PatternGraphNode>;
}): string[] | undefined {
  const offVector = createGeoVector(
    params.nodeByKey,
    params.junctionKey,
    params.offMainPath[params.offMainPath.length - 1],
  );
  const previousVector = createGeoVector(
    params.nodeByKey,
    params.junctionKey,
    params.previousMainPath[params.previousMainPath.length - 1],
  );
  const nextVector = createGeoVector(
    params.nodeByKey,
    params.junctionKey,
    params.nextMainPath[params.nextMainPath.length - 1],
  );

  if (!offVector || !previousVector || !nextVector) {
    return undefined;
  }

  const previousDot = dotGeoVector(offVector, previousVector);
  const nextDot = dotGeoVector(offVector, nextVector);

  if (previousDot <= 0 && nextDot <= 0) {
    return undefined;
  }

  if (previousDot > nextDot) {
    return params.previousMainPath;
  }

  if (nextDot > previousDot) {
    return params.nextMainPath;
  }

  return undefined;
}

function orderForkArmsByLatitude(
  firstPath: string[],
  secondPath: string[],
  nodeByKey: Map<string, PatternGraphNode>,
): [string[], string[]] {
  const firstLatitude = getAveragePathLatitude(firstPath, nodeByKey);
  const secondLatitude = getAveragePathLatitude(secondPath, nodeByKey);

  if (firstLatitude === undefined || secondLatitude === undefined) {
    return [firstPath, secondPath];
  }

  return firstLatitude >= secondLatitude
    ? [firstPath, secondPath]
    : [secondPath, firstPath];
}

function getAveragePathLatitude(
  path: string[],
  nodeByKey: Map<string, PatternGraphNode>,
): number | undefined {
  const latitudes = path
    .slice(1)
    .map((key) => nodeByKey.get(key)?.lat)
    .filter((latitude): latitude is number => Number.isFinite(latitude));

  if (latitudes.length === 0) {
    return undefined;
  }

  return (
    latitudes.reduce((total, latitude) => total + latitude, 0) /
    latitudes.length
  );
}

function createGeoVector(
  nodeByKey: Map<string, PatternGraphNode>,
  sourceKey: string,
  targetKey: string,
): { x: number; y: number } | undefined {
  const source = nodeByKey.get(sourceKey);
  const target = nodeByKey.get(targetKey);

  if (
    !source ||
    !target ||
    !Number.isFinite(source.lon) ||
    !Number.isFinite(source.lat) ||
    !Number.isFinite(target.lon) ||
    !Number.isFinite(target.lat)
  ) {
    return undefined;
  }

  return {
    x: target.lon! - source.lon!,
    y: target.lat! - source.lat!,
  };
}

function dotGeoVector(
  left: { x: number; y: number },
  right: { x: number; y: number },
): number {
  return left.x * right.x + left.y * right.y;
}

function findClearSameDirectionForkY(params: {
  path: string[];
  junctionPosition: PatternLayoutPosition;
  direction: 1 | -1;
  side: 1 | -1;
  initialMagnitude: number;
  positions: Map<string, PatternLayoutPosition>;
  layout: PatternLayoutOptions;
}): number {
  let laneMagnitude = Math.max(1, params.initialMagnitude);

  for (
    let attempt = 0;
    attempt < MAX_LAYOUT_LANE_COLLISION_ATTEMPTS;
    attempt += 1
  ) {
    const y =
      params.junctionPosition.y +
      params.side * params.layout.sameDirectionForkGap * laneMagnitude;
    const proposals = createDirectionalPathPlacementProposals({
      path: params.path,
      anchorPosition: params.junctionPosition,
      direction: params.direction,
      y,
      positions: params.positions,
      layout: params.layout,
    });

    if (!hasLayoutPlacementCollision(proposals, params.positions)) {
      return y;
    }

    laneMagnitude += 1;
  }

  return (
    params.junctionPosition.y +
    params.side * params.layout.sameDirectionForkGap * laneMagnitude
  );
}

function placeLoopCorridor(
  loopLayoutHints: PatternLoopLayoutHint[],
  positions: Map<string, { x: number; y: number }>,
  placed: Set<string>,
  visibleEdges: Set<string>,
  layout: PatternLayoutOptions,
): boolean {
  const candidates = loopLayoutHints.flatMap((hint) =>
    createLoopPlacementCandidates(hint, positions, placed),
  );
  const selected = candidates.sort(
    (left, right) =>
      right.unplacedCount - left.unplacedCount ||
      right.path.length - left.path.length ||
      Math.abs(left.hint.lane) - Math.abs(right.hint.lane),
  )[0];

  if (!selected) {
    return false;
  }

  placeLoopPath(
    selected.path,
    selected.hint,
    positions,
    placed,
    visibleEdges,
    layout,
  );
  return true;
}

function createLoopPlacementCandidates(
  hint: PatternLoopLayoutHint,
  positions: Map<string, { x: number; y: number }>,
  placed: Set<string>,
): Array<{
  hint: PatternLoopLayoutHint;
  path: string[];
  unplacedCount: number;
}> {
  const anchorSet = new Set(hint.anchorKeys);
  const placedAnchorIndexes = hint.stationKeys
    .map((key, index) =>
      anchorSet.has(key) && positions.has(key) ? index : -1,
    )
    .filter((index) => index >= 0);

  if (placedAnchorIndexes.length < 2) {
    return [];
  }

  return placedAnchorIndexes.flatMap((startIndex, index) => {
    const endIndex =
      placedAnchorIndexes[(index + 1) % placedAnchorIndexes.length];
    const path = createLoopPathBetweenAnchors(
      hint.stationKeys,
      startIndex,
      endIndex,
    );
    const internalKeys = path.slice(1, -1);
    const unplacedCount = internalKeys.filter((key) => !placed.has(key)).length;

    if (
      path.length < 3 ||
      unplacedCount === 0 ||
      !positions.has(path[0]) ||
      !positions.has(path[path.length - 1])
    ) {
      return [];
    }

    return [{ hint, path, unplacedCount }];
  });
}

function createLoopPathBetweenAnchors(
  stationKeys: string[],
  startIndex: number,
  endIndex: number,
): string[] {
  if (startIndex < endIndex) {
    return stationKeys.slice(startIndex, endIndex + 1);
  }

  return [
    ...stationKeys.slice(startIndex),
    ...stationKeys.slice(0, endIndex + 1),
  ];
}

function placeLoopPath(
  path: string[],
  hint: PatternLoopLayoutHint,
  positions: Map<string, { x: number; y: number }>,
  placed: Set<string>,
  visibleEdges: Set<string>,
  layout: PatternLayoutOptions,
): void {
  const startKey = path[0];
  const endKey = path[path.length - 1];
  const startPosition = positions.get(startKey);
  const endPosition = positions.get(endKey);

  if (!startPosition || !endPosition) {
    return;
  }

  // The corridor is constrained by its already-placed anchors. Its natural
  // span is used only to preserve local proportions inside that interval.
  const naturalSpan = getPathSpan(path, layout);

  const lane = resolveLoopInterpolatedPathLane({
    hint,
    startPosition,
    endPosition,
    layout,
  });
  const y = findClearInterpolatedPathY({
    path,
    startPosition,
    endPosition,
    naturalSpan,
    initialLane: lane.initialLane,
    baseY: lane.baseY,
    laneGap: lane.laneGap,
    positions,
    layout,
  });
  const proposals = createInterpolatedPathPlacementProposals({
    path,
    startPosition,
    endPosition,
    naturalSpan,
    y,
    positions,
    layout,
  });

  proposals.forEach(({ key, position }) => {
    positions.set(key, position);
  });
  path.slice(1, -1).forEach((key) => placed.add(key));
  addPathEdges(path, visibleEdges);
}

function resolveLoopInterpolatedPathLane({
  hint,
  startPosition,
  endPosition,
  layout,
}: {
  hint: PatternLoopLayoutHint;
  startPosition: PatternLayoutPosition;
  endPosition: PatternLayoutPosition;
  layout: PatternLayoutOptions;
}): InterpolatedPathLane {
  const hintSide = hint.lane < 0 ? -1 : 1;
  const startSide = getPositionSide(startPosition.y);
  const endSide = getPositionSide(endPosition.y);

  if (startSide !== 0 && startSide === endSide && hintSide !== startSide) {
    const corridorHeight = Math.min(
      Math.abs(startPosition.y),
      Math.abs(endPosition.y),
    );

    if (corridorHeight >= MIN_STATION_LAYOUT_SEPARATION * 2) {
      return {
        baseY: 0,
        initialLane: startSide,
        laneGap: corridorHeight / 2,
      };
    }

    return {
      baseY:
        startSide *
        Math.max(Math.abs(startPosition.y), Math.abs(endPosition.y), 0),
      initialLane: startSide,
      laneGap: layout.sameDirectionForkGap,
    };
  }

  return {
    baseY:
      hint.lane < 0
        ? Math.min(startPosition.y, endPosition.y, 0)
        : Math.max(startPosition.y, endPosition.y, 0),
    initialLane: hint.lane,
    laneGap: layout.branchGap,
  };
}

function getPositionSide(y: number): -1 | 0 | 1 {
  if (Math.abs(y) < MIN_STATION_LAYOUT_SEPARATION) {
    return 0;
  }

  return y < 0 ? -1 : 1;
}

function findBestConnectorPath(
  nodes: PatternGraphNode[],
  adjacency: Map<string, Set<string>>,
  placed: Set<string>,
): string[] | null {
  const placedIds = nodes.map((node) => node.id).filter((id) => placed.has(id));
  let bestPath: string[] | null = null;
  let bestScore = Number.NEGATIVE_INFINITY;

  placedIds.forEach((source) => {
    const path = findConnectorPathFrom(source, adjacency, placed);

    if (!path || path.length < 3) {
      return;
    }

    const internalCount = path
      .slice(1, -1)
      .filter((id) => !placed.has(id)).length;
    const score = internalCount * 100 + path.length;

    if (score > bestScore) {
      bestScore = score;
      bestPath = path;
    }
  });

  return bestPath;
}

function findConnectorPathFrom(
  source: string,
  adjacency: Map<string, Set<string>>,
  placed: Set<string>,
): string[] | null {
  const queue: string[][] = [[source]];
  const visited = new Set<string>([source]);

  while (queue.length > 0) {
    const path = queue.shift()!;
    const current = path[path.length - 1];

    for (const neighbor of adjacency.get(current) ?? []) {
      if (neighbor === source || visited.has(neighbor)) {
        continue;
      }

      const nextPath = [...path, neighbor];

      if (placed.has(neighbor)) {
        if (nextPath.length >= 3) {
          return nextPath;
        }

        continue;
      }

      visited.add(neighbor);
      queue.push(nextPath);
    }
  }

  return null;
}

function findBestBranchPath(
  nodes: PatternGraphNode[],
  adjacency: Map<string, Set<string>>,
  placed: Set<string>,
): string[] | null {
  const unplacedTerminals = nodes
    .filter((node) => !placed.has(node.id))
    .filter((node) => (adjacency.get(node.id)?.size ?? 0) <= 1)
    .map((node) => node.id);
  const starts =
    unplacedTerminals.length > 0
      ? unplacedTerminals
      : nodes.filter((node) => !placed.has(node.id)).map((node) => node.id);
  let bestPath: string[] | null = null;

  starts.forEach((start) => {
    const path = findShortestPath(start, (key) => placed.has(key), adjacency);

    if (!path || path.length < 2) {
      return;
    }

    if (!bestPath || path.length > bestPath.length) {
      bestPath = path;
    }
  });

  return bestPath ? [...bestPath].reverse() : null;
}

function findNearestDisconnectedBranchPath(
  nodes: PatternGraphNode[],
  adjacency: Map<string, Set<string>>,
  placed: Set<string>,
  syntheticEdges: PatternGraphEdge[],
): string[] | null {
  const nodeMap = new Map(nodes.map((node) => [node.id, node]));
  const placedNodes = nodes.filter((node) => placed.has(node.id));
  const unplacedNodes = nodes.filter((node) => !placed.has(node.id));
  let best:
    | {
        distanceKm: number;
        placedNode: PatternGraphNode;
        unplacedNode: PatternGraphNode;
      }
    | undefined;

  placedNodes.forEach((placedNode) => {
    unplacedNodes.forEach((unplacedNode) => {
      const distanceKm = getNodeDistanceKm(placedNode, unplacedNode);

      if (distanceKm === undefined || distanceKm > 7) {
        return;
      }

      if (!best || distanceKm < best.distanceKm) {
        best = { distanceKm, placedNode, unplacedNode };
      }
    });
  });

  if (!best) {
    return null;
  }

  const component = collectUnplacedComponent(
    best.unplacedNode.id,
    adjacency,
    placed,
  );
  const componentPath = findLongestComponentPathFrom(
    best.unplacedNode.id,
    component,
    adjacency,
  );
  const connectorKey = createEdgeKey(best.placedNode.id, best.unplacedNode.id);

  if (!syntheticEdges.some((edge) => edge.id === connectorKey)) {
    syntheticEdges.push({
      id: connectorKey,
      source: best.placedNode.id,
      target: best.unplacedNode.id,
      active: false,
      distanceKm: best.distanceKm,
    });
  }

  componentPath.forEach((key) => {
    const node = nodeMap.get(key);

    if (node) {
      node.degree = Math.max(node.degree, adjacency.get(key)?.size ?? 0);
    }
  });

  return [best.placedNode.id, ...componentPath];
}

function collectUnplacedComponent(
  start: string,
  adjacency: Map<string, Set<string>>,
  placed: Set<string>,
): Set<string> {
  const component = new Set<string>();
  const queue = [start];

  while (queue.length > 0) {
    const current = queue.shift()!;

    if (component.has(current) || placed.has(current)) {
      continue;
    }

    component.add(current);
    Array.from(adjacency.get(current) ?? []).forEach((neighbor) => {
      if (!component.has(neighbor) && !placed.has(neighbor)) {
        queue.push(neighbor);
      }
    });
  }

  return component;
}

function findLongestComponentPathFrom(
  start: string,
  component: Set<string>,
  adjacency: Map<string, Set<string>>,
): string[] {
  const terminals = Array.from(component).filter(
    (key) =>
      Array.from(adjacency.get(key) ?? []).filter((neighbor) =>
        component.has(neighbor),
      ).length <= 1,
  );
  let bestPath = [start];

  terminals.forEach((terminal) => {
    const path = findShortestPathRestricted(
      start,
      (key) => key === terminal,
      adjacency,
      component,
    );

    if (path && path.length > bestPath.length) {
      bestPath = path;
    }
  });

  return bestPath;
}

function findShortestPathRestricted(
  start: string,
  isTarget: (key: string) => boolean,
  adjacency: Map<string, Set<string>>,
  allowed: Set<string>,
): string[] | null {
  const queue: string[][] = [[start]];
  const visited = new Set<string>([start]);

  while (queue.length > 0) {
    const path = queue.shift()!;
    const current = path[path.length - 1];

    if (isTarget(current)) {
      return path;
    }

    Array.from(adjacency.get(current) ?? [])
      .filter((neighbor) => allowed.has(neighbor) && !visited.has(neighbor))
      .forEach((neighbor) => {
        visited.add(neighbor);
        queue.push([...path, neighbor]);
      });
  }

  return null;
}

function findShortestPath(
  start: string,
  isTarget: (key: string) => boolean,
  adjacency: Map<string, Set<string>>,
): string[] | null {
  const queue: string[][] = [[start]];
  const visited = new Set<string>([start]);

  while (queue.length > 0) {
    const path = queue.shift()!;
    const current = path[path.length - 1];

    if (path.length > 1 && isTarget(current)) {
      return path;
    }

    Array.from(adjacency.get(current) ?? [])
      .filter((neighbor) => !visited.has(neighbor))
      .forEach((neighbor) => {
        visited.add(neighbor);
        queue.push([...path, neighbor]);
      });
  }

  return null;
}

function placeConnectorPath(
  path: string[],
  positions: Map<string, { x: number; y: number }>,
  placed: Set<string>,
  visibleEdges: Set<string>,
  laneSteps: Generator<number, never, unknown>,
  layout: PatternLayoutOptions,
): void {
  const startKey = path[0];
  const endKey = path[path.length - 1];
  const startPosition = positions.get(startKey);
  const endPosition = positions.get(endKey);

  if (!startPosition || !endPosition) {
    return;
  }

  // A connector with two placed endpoints must fit between those endpoints;
  // it must never move the common spine to satisfy its natural length.
  const naturalSpan = getPathSpan(path, layout);

  const baseY = Math.max(startPosition.y, endPosition.y, 0);
  const lane = Math.abs(laneSteps.next().value);
  const y = findClearInterpolatedPathY({
    path,
    startPosition,
    endPosition,
    naturalSpan,
    initialLane: lane,
    baseY,
    laneGap: layout.branchGap,
    positions,
    layout,
  });
  const proposals = createInterpolatedPathPlacementProposals({
    path,
    startPosition,
    endPosition,
    naturalSpan,
    y,
    positions,
    layout,
  });

  proposals.forEach(({ key, position }) => {
    positions.set(key, position);
  });
  path.slice(1, -1).forEach((key) => placed.add(key));

  addPathEdges(path, visibleEdges);
}

function placeBranchPath(
  path: string[],
  positions: Map<string, { x: number; y: number }>,
  placed: Set<string>,
  visibleEdges: Set<string>,
  laneSteps: Generator<number, never, unknown>,
  destinationKey?: string,
  branchLayoutHints?: Map<string, PatternBranchLayoutHint>,
  layout?: PatternLayoutOptions,
): void {
  const anchor = path[0];
  const terminal = path[path.length - 1];
  const anchorPosition = positions.get(anchor);

  if (!anchorPosition) {
    return;
  }

  const layoutHint = branchLayoutHints?.get(
    createBranchLayoutHintKey(anchor, terminal),
  );
  const spacing = layout ?? createPatternLayoutOptions("comfort");
  const destinationPosition = destinationKey
    ? positions.get(destinationKey)
    : undefined;
  const branchDirection = resolveBranchDirection({
    anchor,
    anchorPosition,
    path,
    destinationKey,
    destinationPosition,
    positions,
    layoutHint,
  });
  const lane = findClearBranchLane({
    path,
    anchorPosition,
    branchDirection,
    initialLane: createBranchLane(laneSteps, layoutHint),
    positions,
    layout: spacing,
  });
  const y = lane * spacing.branchGap;
  const proposals = createDirectionalPathPlacementProposals({
    path,
    anchorPosition,
    direction: branchDirection,
    y,
    positions,
    layout: spacing,
  });

  proposals.forEach(({ key, position }) => {
    positions.set(key, position);
  });
  path.slice(1).forEach((key) => placed.add(key));
  addPathEdges(path, visibleEdges);
}

function findClearBranchLane(params: {
  path: string[];
  anchorPosition: PatternLayoutPosition;
  branchDirection: 1 | -1;
  initialLane: number;
  positions: Map<string, PatternLayoutPosition>;
  layout: PatternLayoutOptions;
}): number {
  const anchorSide =
    Math.abs(params.anchorPosition.y) >= MIN_STATION_LAYOUT_SEPARATION
      ? params.anchorPosition.y < 0
        ? -1
        : 1
      : undefined;
  const side = anchorSide ?? (params.initialLane < 0 ? -1 : 1);
  let magnitude = Math.max(
    1,
    Math.abs(params.initialLane),
    anchorSide
      ? Math.ceil(Math.abs(params.anchorPosition.y) / params.layout.branchGap)
      : 1,
  );

  for (
    let attempt = 0;
    attempt < MAX_LAYOUT_LANE_COLLISION_ATTEMPTS;
    attempt += 1
  ) {
    const lane = side * magnitude;
    const proposals = createDirectionalPathPlacementProposals({
      path: params.path,
      anchorPosition: params.anchorPosition,
      direction: params.branchDirection,
      y: lane * params.layout.branchGap,
      positions: params.positions,
      layout: params.layout,
    });

    if (!hasLayoutPlacementCollision(proposals, params.positions)) {
      return lane;
    }

    magnitude += 1;
  }

  return side * magnitude;
}

function findClearInterpolatedPathY(params: {
  path: string[];
  startPosition: PatternLayoutPosition;
  endPosition: PatternLayoutPosition;
  naturalSpan: number;
  initialLane: number;
  baseY: number;
  laneGap: number;
  positions: Map<string, PatternLayoutPosition>;
  layout: PatternLayoutOptions;
}): number {
  const side = params.initialLane < 0 ? -1 : 1;
  let magnitude = Math.max(1, Math.abs(params.initialLane));

  for (
    let attempt = 0;
    attempt < MAX_LAYOUT_LANE_COLLISION_ATTEMPTS;
    attempt += 1
  ) {
    const y = params.baseY + side * magnitude * params.laneGap;
    const proposals = createInterpolatedPathPlacementProposals({
      path: params.path,
      startPosition: params.startPosition,
      endPosition: params.endPosition,
      naturalSpan: params.naturalSpan,
      y,
      positions: params.positions,
      layout: params.layout,
    });

    // A compressed anchored corridor may have adjacent stops closer than the
    // global separation threshold. Only collisions with already-placed
    // geometry should force it onto another lane.
    if (!hasExistingLayoutPlacementCollision(proposals, params.positions)) {
      return y;
    }

    magnitude += 1;
  }

  return params.baseY + side * magnitude * params.laneGap;
}

function createDirectionalPathPlacementProposals(params: {
  path: string[];
  anchorPosition: PatternLayoutPosition;
  direction: 1 | -1;
  y: number;
  positions: Map<string, PatternLayoutPosition>;
  layout: PatternLayoutOptions;
}): PatternPlacementProposal[] {
  let branchOffset = 0;

  return params.path.slice(1).flatMap((key, index) => {
    branchOffset += getLayoutStopGap(params.layout, params.path[index], key);

    if (params.positions.has(key)) {
      return [];
    }

    return [
      {
        key,
        position: {
          x: params.anchorPosition.x + params.direction * branchOffset,
          y: params.y,
        },
      },
    ];
  });
}

function createDirectionalPathOverwriteProposals(params: {
  path: string[];
  anchorPosition: PatternLayoutPosition;
  direction: 1 | -1;
  y: number;
  layout: PatternLayoutOptions;
}): PatternPlacementProposal[] {
  let branchOffset = 0;

  return params.path.slice(1).map((key, index) => {
    branchOffset += getLayoutStopGap(params.layout, params.path[index], key);

    return {
      key,
      position: {
        x: params.anchorPosition.x + params.direction * branchOffset,
        y: params.y,
      },
    };
  });
}

function applyDirectionalPathPositions(params: {
  path: string[];
  anchorPosition: PatternLayoutPosition;
  direction: 1 | -1;
  y: number;
  positions: Map<string, PatternLayoutPosition>;
  layout: PatternLayoutOptions;
  overwriteExisting: boolean;
}): void {
  let branchOffset = 0;

  params.path.slice(1).forEach((key, index) => {
    branchOffset += getLayoutStopGap(params.layout, params.path[index], key);

    if (!params.overwriteExisting && params.positions.has(key)) {
      return;
    }

    params.positions.set(key, {
      x: params.anchorPosition.x + params.direction * branchOffset,
      y: params.y,
    });
  });
}

function createInterpolatedPathPlacementProposals(params: {
  path: string[];
  startPosition: PatternLayoutPosition;
  endPosition: PatternLayoutPosition;
  naturalSpan: number;
  y: number;
  positions: Map<string, PatternLayoutPosition>;
  layout: PatternLayoutOptions;
}): PatternPlacementProposal[] {
  const denominator = Math.max(params.path.length - 1, 1);

  return params.path.slice(1, -1).flatMap((key, index) => {
    if (params.positions.has(key)) {
      return [];
    }

    const realisticOffset = getPathOffsetToIndex(
      params.path,
      index + 1,
      params.layout,
    );
    const ratio =
      params.naturalSpan > 0
        ? realisticOffset / params.naturalSpan
        : (index + 1) / denominator;

    return [
      {
        key,
        position: {
          x:
            params.startPosition.x +
            (params.endPosition.x - params.startPosition.x) * ratio,
          y: params.y,
        },
      },
    ];
  });
}

function hasLayoutPlacementCollision(
  proposals: PatternPlacementProposal[],
  positions: Map<string, PatternLayoutPosition>,
  ignoredExistingKeys = new Set<string>(),
): boolean {
  if (proposals.length === 0) {
    return false;
  }

  if (hasExistingLayoutPlacementCollision(proposals, positions, ignoredExistingKeys)) {
    return true;
  }

  return proposals.some((proposal, index) =>
    proposals
      .slice(index + 1)
      .some(
        (otherProposal) =>
          proposal.key !== otherProposal.key &&
          getLayoutDistance(proposal.position, otherProposal.position) <
            MIN_STATION_LAYOUT_SEPARATION,
      ),
  );
}

function hasExistingLayoutPlacementCollision(
  proposals: PatternPlacementProposal[],
  positions: Map<string, PatternLayoutPosition>,
  ignoredExistingKeys = new Set<string>(),
): boolean {
  return proposals.some(({ key, position }) =>
    Array.from(positions.entries()).some(
      ([existingKey, existingPosition]) =>
        !ignoredExistingKeys.has(existingKey) &&
        existingKey !== key &&
        getLayoutDistance(position, existingPosition) <
          MIN_STATION_LAYOUT_SEPARATION,
    ),
  );
}

function getLayoutDistance(
  left: PatternLayoutPosition,
  right: PatternLayoutPosition,
): number {
  return Math.hypot(left.x - right.x, left.y - right.y);
}

function createBranchLane(
  laneSteps: Generator<number, never, unknown>,
  layoutHint?: PatternBranchLayoutHint,
): number {
  const nextLane = laneSteps.next().value;

  if (!layoutHint || layoutHint.kind !== "same-direction-fork") {
    return nextLane;
  }

  const lane = Math.abs(nextLane);

  if (layoutHint.side === "upper") {
    return -lane;
  }

  if (layoutHint.side === "lower") {
    return lane;
  }

  return lane;
}

function resolveBranchDirection(params: {
  anchor: string;
  anchorPosition: { x: number; y: number };
  path: string[];
  destinationKey?: string;
  destinationPosition?: { x: number; y: number };
  positions: Map<string, { x: number; y: number }>;
  layoutHint?: PatternBranchLayoutHint;
}): 1 | -1 {
  if (params.layoutHint?.kind === "same-direction-fork") {
    const trunkPosition = params.layoutHint.trunkKey
      ? params.positions.get(params.layoutHint.trunkKey)
      : undefined;

    if (trunkPosition) {
      return params.anchorPosition.x <= trunkPosition.x ? -1 : 1;
    }
  }

  if (
    params.destinationPosition &&
    typeof params.destinationKey === "string" &&
    params.anchor !== params.destinationKey &&
    params.path.includes(params.destinationKey)
  ) {
    return params.anchorPosition.x < params.destinationPosition.x ? 1 : -1;
  }

  if (
    params.destinationPosition &&
    typeof params.destinationKey === "string" &&
    params.anchor !== params.destinationKey
  ) {
    return params.anchorPosition.x < params.destinationPosition.x ? -1 : 1;
  }

  return 1;
}

function placeRemainingComponents(
  nodes: PatternGraphNode[],
  adjacency: Map<string, Set<string>>,
  positions: Map<string, { x: number; y: number }>,
  placed: Set<string>,
  visibleEdges: Set<string>,
  laneSteps: Generator<number, never, unknown>,
  destinationKey?: string,
  layout: PatternLayoutOptions = createPatternLayoutOptions("comfort"),
): void {
  const nodeIds = nodes.map((node) => node.id);
  const keepAfterDestinationClear =
    destinationKey !== undefined && positions.has(destinationKey);
  let nextBaseX = keepAfterDestinationClear
    ? getMinPositionX(positions) - layout.stopGap
    : getMaxPositionX(positions) + layout.stopGap;

  while (true) {
    const start = nodeIds.find((id) => !placed.has(id));

    if (!start) {
      break;
    }

    const component = collectUnplacedComponentIds(start, adjacency, placed);
    const mainPath = findLongestPathInComponent(component, adjacency);
    const orderedIds = mainPath.length > 0 ? mainPath : Array.from(component);
    const lane = laneSteps.next().value;
    const y = lane * layout.branchGap;

    let componentOffset = 0;

    orderedIds.forEach((id, index) => {
      if (index > 0) {
        componentOffset += getLayoutStopGap(layout, orderedIds[index - 1], id);
      }

      positions.set(id, {
        x: keepAfterDestinationClear
          ? nextBaseX - componentOffset
          : nextBaseX + componentOffset,
        y,
      });
      placed.add(id);
    });

    placeComponentSideNodes({
      component,
      orderedIds,
      adjacency,
      positions,
      placed,
      baseY: y,
      layout,
    });

    addComponentEdges(component, adjacency, visibleEdges);

    nextBaseX +=
      (keepAfterDestinationClear ? -1 : 1) *
      (getPathSpan(orderedIds, layout) + layout.stopGap * 2);
  }
}

function collectUnplacedComponentIds(
  start: string,
  adjacency: Map<string, Set<string>>,
  placed: Set<string>,
): Set<string> {
  const component = new Set<string>();
  const queue = [start];

  while (queue.length > 0) {
    const current = queue.shift()!;

    if (component.has(current) || placed.has(current)) {
      continue;
    }

    component.add(current);

    for (const neighbor of adjacency.get(current) ?? []) {
      if (!component.has(neighbor) && !placed.has(neighbor)) {
        queue.push(neighbor);
      }
    }
  }

  return component;
}

function findLongestPathInComponent(
  component: Set<string>,
  adjacency: Map<string, Set<string>>,
): string[] {
  const ids = Array.from(component);

  if (ids.length <= 1) {
    return ids;
  }

  const terminals = ids.filter((id) => {
    const componentDegree = Array.from(adjacency.get(id) ?? []).filter(
      (neighbor) => component.has(neighbor),
    ).length;

    return componentDegree <= 1;
  });
  const candidates = terminals.length >= 2 ? terminals : ids;
  let bestPath: string[] = [];

  candidates.forEach((source, sourceIndex) => {
    candidates.slice(sourceIndex + 1).forEach((target) => {
      const path = findShortestPathRestricted(
        source,
        (key) => key === target,
        adjacency,
        component,
      );

      if (path && path.length > bestPath.length) {
        bestPath = path;
      }
    });
  });

  return bestPath.length > 0 ? bestPath : ids;
}

function placeComponentSideNodes(params: {
  component: Set<string>;
  orderedIds: string[];
  adjacency: Map<string, Set<string>>;
  positions: Map<string, { x: number; y: number }>;
  placed: Set<string>;
  baseY: number;
  layout: PatternLayoutOptions;
}): void {
  const { component, orderedIds, adjacency, positions, placed, baseY, layout } =
    params;
  const orderedSet = new Set(orderedIds);
  const sideNodeCountByAnchor = new Map<string, number>();

  Array.from(component).forEach((id) => {
    if (placed.has(id)) {
      return;
    }

    const anchorId = Array.from(adjacency.get(id) ?? []).find((neighbor) =>
      orderedSet.has(neighbor),
    );
    const anchorPosition = anchorId ? positions.get(anchorId) : undefined;
    const sideNodeIndex = sideNodeCountByAnchor.get(anchorId ?? "") ?? 0;

    sideNodeCountByAnchor.set(anchorId ?? "", sideNodeIndex + 1);

    positions.set(id, {
      x: anchorPosition
        ? anchorPosition.x + sideNodeIndex * layout.stopGap
        : getMaxPositionX(positions) + layout.stopGap,
      y: baseY + layout.branchGap,
    });
    placed.add(id);
  });
}

function addComponentEdges(
  component: Set<string>,
  adjacency: Map<string, Set<string>>,
  visibleEdges: Set<string>,
): void {
  component.forEach((source) => {
    for (const target of adjacency.get(source) ?? []) {
      if (component.has(target) && source !== target) {
        visibleEdges.add(createEdgeKey(source, target));
      }
    }
  });
}

function addPathEdges(path: string[], visibleEdges: Set<string>): void {
  path.slice(0, -1).forEach((source, index) => {
    const target = path[index + 1];

    if (source !== target) {
      visibleEdges.add(createEdgeKey(source, target));
    }
  });
}

function addGraphEdges(
  edges: PatternGraphEdge[],
  visibleEdges: Set<string>,
): void {
  edges.forEach((edge) => {
    visibleEdges.add(createEdgeKey(edge.source, edge.target));
  });
}

function createDegreesFromEdgeKeys(edgeKeys: Set<string>): Map<string, number> {
  const degrees = new Map<string, number>();

  edgeKeys.forEach((edgeKey) => {
    const [source, target] = edgeKey.split("--");

    degrees.set(source, (degrees.get(source) ?? 0) + 1);
    degrees.set(target, (degrees.get(target) ?? 0) + 1);
  });

  return degrees;
}

function createDegreesFromEdges(
  edges: PatternGraphEdge[],
): Map<string, number> {
  const degrees = new Map<string, number>();

  edges.forEach((edge) => {
    degrees.set(edge.source, (degrees.get(edge.source) ?? 0) + 1);
    degrees.set(edge.target, (degrees.get(edge.target) ?? 0) + 1);
  });

  return degrees;
}

function scoreSequence(
  sequence: string[],
  servedKeys: Set<string>,
  currentKey?: string,
): number {
  const overlap = sequence.filter((key) => servedKeys.has(key)).length;
  const currentBonus = currentKey && sequence.includes(currentKey) ? 1000 : 0;

  return overlap * 120 + currentBonus + sequence.length;
}

function getMaxPositionX(
  positions: Map<string, { x: number; y: number }>,
): number {
  return Math.max(
    0,
    ...Array.from(positions.values()).map((position) => position.x),
  );
}

function getMinPositionX(
  positions: Map<string, { x: number; y: number }>,
): number {
  return Math.min(
    0,
    ...Array.from(positions.values()).map((position) => position.x),
  );
}

function* createLaneSteps(): Generator<number, never, unknown> {
  let magnitude = 1;

  while (true) {
    yield magnitude;
    yield -magnitude;
    magnitude += 1;
  }
}

function createDagreLayout(
  graph: {
    nodes: PatternGraphNode[];
    edges: PatternGraphEdge[];
  },
  layout: PatternLayoutOptions,
): Map<string, { x: number; y: number }> {
  const layoutGraph = new dagre.graphlib.Graph();

  layoutGraph.setDefaultEdgeLabel(() => ({}));
  layoutGraph.setGraph({
    rankdir: "LR",
    align: "UL",
    ranksep: layout.rankSeparator,
    nodesep: layout.nodeSeparator,
    edgesep: 24,
    marginx: 34,
    marginy: 28,
  });

  graph.nodes.forEach((node) => {
    layoutGraph.setNode(node.id, {
      width: layout.nodeWidth,
      height: layout.nodeHeight,
    });
  });
  graph.edges.forEach((edge) => {
    layoutGraph.setEdge(edge.source, edge.target, {
      weight: edge.active ? 3 : 1,
      minlen: 1,
    });
  });

  dagre.layout(layoutGraph);

  return new Map(
    graph.nodes.map((node) => {
      const layoutNode = layoutGraph.node(node.id);

      return [
        node.id,
        {
          x: layoutNode?.x ?? 0,
          y: layoutNode?.y ?? 0,
        },
      ];
    }),
  );
}

function buildPatternGraph(
  calls: DepartureCall[],
  lineTopology: LineRouteSequence[],
  fullLine = false,
): {
  nodes: PatternGraphNode[];
  edges: PatternGraphEdge[];
} {
  const callMap = new Map<string, DepartureCall>();

  calls.forEach((call) => {
    callMap.set(createStationKey(call), call);
  });

  const nodeMap = new Map<string, PatternGraphNode>();
  const edgeMap = new Map<string, PatternGraphEdge>();

  lineTopology.forEach((sequence) => {
    const stops = dedupeRouteStops(sequence.stops);
    const coordinatePriority = getTopologyCoordinatePriority(
      sequence.topologySource,
    );

    stops.forEach((stop) => {
      const call = findCallForStop(callMap, stop);
      const key = createStationKey(stop);
      const existing = nodeMap.get(key);
      const stopCoordinates = resolveTransitLonLat(stop);
      const shouldUseStopCoordinates =
        stopCoordinates !== undefined &&
        (existing?.lat === undefined ||
          existing?.lon === undefined ||
          coordinatePriority > existing.coordinatePriority);

      nodeMap.set(key, {
        id: key,
        label: existing?.label ?? call?.label ?? stop.label,
        city: existing?.city ?? call?.city ?? stop.city,
        lon: shouldUseStopCoordinates ? stopCoordinates.lon : existing?.lon,
        lat: shouldUseStopCoordinates ? stopCoordinates.lat : existing?.lat,
        coordinatePriority: shouldUseStopCoordinates
          ? coordinatePriority
          : (existing?.coordinatePriority ?? -1),
        current: fullLine ? false : Boolean(existing?.current || call?.current),
        served: fullLine ? true : Boolean(existing?.served || call?.served),
        time: fullLine ? undefined : (existing?.time ?? call?.time),
        transfers: mergeTransfers(
          existing?.transfers,
          stop.transferLines,
          call?.transferLines,
        ),
        degree: existing?.degree ?? 0,
      });
    });

    stops.slice(0, -1).forEach((sourceStop, index) => {
      const targetStop = stops[index + 1];
      const source = createStationKey(sourceStop);
      const target = createStationKey(targetStop);
      const edgeKey = createEdgeKey(source, target);
      const distanceKm = getStopDistanceKm(sourceStop, targetStop);
      const existingEdge = edgeMap.get(edgeKey);

      if (source === target) {
        return;
      }

      if (existingEdge) {
        if (
          distanceKm !== undefined &&
          (existingEdge.distanceKm === undefined ||
            sequence.topologySource === "server")
        ) {
          existingEdge.distanceKm = distanceKm;
        }
        return;
      }

      edgeMap.set(edgeKey, {
        id: edgeKey,
        source,
        target,
        active: false,
        distanceKm,
      });
    });
  });

  if (nodeMap.size === 0) {
    calls.forEach((call) => {
      const key = createStationKey(call);

      nodeMap.set(key, {
        id: key,
        label: call.label,
        city: call.city,
        coordinatePriority: -1,
        current: fullLine ? false : call.current,
        served: fullLine ? true : call.served,
        time: fullLine ? undefined : call.time,
        transfers: call.transferLines ?? [],
        degree: 0,
      });
    });
    calls.slice(0, -1).forEach((call, index) => {
      const source = createStationKey(call);
      const target = createStationKey(calls[index + 1]);

      if (source !== target) {
        edgeMap.set(createEdgeKey(source, target), {
          id: createEdgeKey(source, target),
          source,
          target,
          active: false,
        });
      }
    });
  }

  const servedEdges = fullLine
    ? new Set<string>()
    : createServedEdgeKeys(calls);
  const corridorEdges = fullLine
    ? new Set<string>()
    : createActiveCorridorEdgeKeys(calls, lineTopology);
  if (lineTopology.length === 0) {
    pruneImplausibleEdges(edgeMap, servedEdges, corridorEdges);
  }

  edgeMap.forEach((edge) => {
    const edgeKey = createEdgeKey(edge.source, edge.target);

    edge.active =
      fullLine || servedEdges.has(edgeKey) || corridorEdges.has(edgeKey);
    nodeMap.get(edge.source)!.degree += 1;
    nodeMap.get(edge.target)!.degree += 1;
  });

  return {
    nodes: Array.from(nodeMap.values()),
    edges: Array.from(edgeMap.values()),
  };
}

function pruneImplausibleEdges(
  edgeMap: Map<string, PatternGraphEdge>,
  protectedEdges: Set<string>,
  activeCorridorEdges: Set<string>,
): void {
  const distances = Array.from(edgeMap.values())
    .map((edge) => edge.distanceKm)
    .filter(
      (distance): distance is number =>
        typeof distance === "number" &&
        Number.isFinite(distance) &&
        distance > 0,
    )
    .sort((left, right) => left - right);

  if (distances.length < 8) {
    return;
  }

  const medianDistance = distances[Math.floor(distances.length / 2)];
  const threshold = Math.min(8, Math.max(3.2, medianDistance * 3.2));

  edgeMap.forEach((edge, edgeKey) => {
    if (
      protectedEdges.has(edgeKey) ||
      activeCorridorEdges.has(edgeKey) ||
      edge.distanceKm === undefined
    ) {
      return;
    }

    if (edge.distanceKm > threshold) {
      edgeMap.delete(edgeKey);
    }
  });
}

function createServedEdgeKeys(calls: DepartureCall[]): Set<string> {
  return new Set(createServedEdgeKeyList(calls));
}

function createServedEdgeKeyList(calls: DepartureCall[]): string[] {
  const servedCalls = calls.filter((call) => call.served);
  const edgeKeys: string[] = [];

  servedCalls.slice(0, -1).forEach((call, index) => {
    const source = createStationKey(call);
    const target = createStationKey(servedCalls[index + 1]);

    if (source !== target) {
      edgeKeys.push(createEdgeKey(source, target));
    }
  });

  return edgeKeys;
}

function getServedDestinationKey(calls: DepartureCall[]): string | undefined {
  const servedCalls = calls.filter((call) => call.served);
  const destinationCall = servedCalls[servedCalls.length - 1];

  return destinationCall ? createStationKey(destinationCall) : undefined;
}

function createActiveCorridorEdgeKeys(
  calls: DepartureCall[],
  lineTopology: LineRouteSequence[],
): Set<string> {
  return new Set(createActiveRouteEdgeKeyList(calls, lineTopology));
}

function createActiveRouteEdgeOrder(
  calls: DepartureCall[],
  lineTopology: LineRouteSequence[],
): Map<string, number> {
  return new Map(
    createActiveRouteEdgeKeyList(calls, lineTopology).map((key, index) => [
      key,
      index,
    ]),
  );
}

function createActiveRouteEdgeDirections(
  calls: DepartureCall[],
  lineTopology: LineRouteSequence[],
): Map<string, { source: string; target: string }> {
  return new Map(
    createActiveRouteDirectedEdges(calls, lineTopology).map((edge) => [
      createEdgeKey(edge.source, edge.target),
      edge,
    ]),
  );
}

function createActiveRouteEdgeKeyList(
  calls: DepartureCall[],
  lineTopology: LineRouteSequence[],
): string[] {
  return createActiveRouteDirectedEdges(calls, lineTopology).map((edge) =>
    createEdgeKey(edge.source, edge.target),
  );
}

function createActiveRouteDirectedEdges(
  calls: DepartureCall[],
  lineTopology: LineRouteSequence[],
): Array<{ source: string; target: string }> {
  const servedCallKeys = calls
    .filter((call) => call.served)
    .map(createStationKey);
  const servedKeys = new Set(servedCallKeys);
  const currentKey = calls.find((call) => call.current)
    ? createStationKey(calls.find((call) => call.current)!)
    : undefined;
  const sequences = lineTopology
    .map((sequence) => dedupeRouteStops(sequence.stops).map(createStationKey))
    .filter((sequence) => sequence.length > 1);
  const sequence = [...sequences].sort(
    (left, right) =>
      scoreSequence(right, servedKeys, currentKey) -
      scoreSequence(left, servedKeys, currentKey),
  )[0];

  if (!sequence) {
    return createServedDirectedEdges(calls);
  }

  const orientedSequence = orientSequenceTowardCalls(sequence, servedCallKeys);
  const firstServedKey = servedCallKeys.find((key) =>
    orientedSequence.includes(key),
  );
  const lastServedKey = [...servedCallKeys]
    .reverse()
    .find((key) => orientedSequence.includes(key));
  const servedIndexes = orientedSequence
    .map((key, index) => (servedKeys.has(key) ? index : -1))
    .filter((index) => index >= 0);

  if (servedIndexes.length < 2) {
    return createServedDirectedEdges(calls);
  }

  const firstIndex =
    firstServedKey !== undefined
      ? orientedSequence.indexOf(firstServedKey)
      : -1;
  const lastIndex =
    lastServedKey !== undefined ? orientedSequence.indexOf(lastServedKey) : -1;
  const startIndex =
    firstIndex >= 0 && lastIndex >= 0
      ? Math.min(firstIndex, lastIndex)
      : Math.min(...servedIndexes);
  const endIndex =
    firstIndex >= 0 && lastIndex >= 0
      ? Math.max(firstIndex, lastIndex)
      : Math.max(...servedIndexes);
  const directedEdges: Array<{ source: string; target: string }> = [];

  orientedSequence.slice(startIndex, endIndex).forEach((source, index) => {
    const target = orientedSequence[startIndex + index + 1];

    if (source !== target) {
      directedEdges.push({ source, target });
    }
  });

  return directedEdges;
}

function createServedDirectedEdges(
  calls: DepartureCall[],
): Array<{ source: string; target: string }> {
  const servedCalls = calls.filter((call) => call.served);
  const edges: Array<{ source: string; target: string }> = [];

  servedCalls.slice(0, -1).forEach((call, index) => {
    const source = createStationKey(call);
    const target = createStationKey(servedCalls[index + 1]);

    if (source !== target) {
      edges.push({ source, target });
    }
  });

  return edges;
}

function orientSequenceTowardCalls(
  sequence: string[],
  servedCallKeys: string[],
): string[] {
  const firstServedKey = servedCallKeys.find((key) => sequence.includes(key));
  const lastServedKey = [...servedCallKeys]
    .reverse()
    .find((key) => sequence.includes(key));

  if (!firstServedKey || !lastServedKey) {
    return sequence;
  }

  const firstIndex = sequence.indexOf(firstServedKey);
  const lastIndex = sequence.indexOf(lastServedKey);

  return lastIndex < firstIndex ? [...sequence].reverse() : sequence;
}

function getActiveTerminalIds(graph: {
  nodes: PatternGraphNode[];
  edges: PatternGraphEdge[];
}): Set<string> {
  const activeDegree = new Map<string, number>();

  graph.edges
    .filter((edge) => edge.active)
    .forEach((edge) => {
      activeDegree.set(edge.source, (activeDegree.get(edge.source) ?? 0) + 1);
      activeDegree.set(edge.target, (activeDegree.get(edge.target) ?? 0) + 1);
    });

  return new Set(
    graph.nodes
      .filter((node) => node.served && (activeDegree.get(node.id) ?? 0) <= 1)
      .map((node) => node.id),
  );
}

function getBranchChip(
  node: PatternGraphNode,
  activeTerminalIds: Set<string>,
  departureTimeLabel: string,
): string | undefined {
  if (activeTerminalIds.has(node.id) && departureTimeLabel) {
    return node.current ? t("alarm.fallbackDeparture") : departureTimeLabel;
  }

  return undefined;
}

function dedupeRouteStops(stops: LineRouteStop[]): LineRouteStop[] {
  const seen = new Set<string>();

  return stops.filter((stop) => {
    const key = createStationKey(stop);

    if (seen.has(key)) {
      return false;
    }

    seen.add(key);
    return true;
  });
}

function findCallForStop(
  callMap: Map<string, DepartureCall>,
  stop: LineRouteStop,
): DepartureCall | undefined {
  const stopKey = createStationKey(stop);
  const exactMatch = callMap.get(stopKey);

  if (exactMatch) {
    return exactMatch;
  }

  return Array.from(callMap.values()).find((call) =>
    stationKeysAreCompatible(stopKey, createStationKey(call)),
  );
}

function mergeTransfers(
  ...transferGroups: Array<TransferLineOption[] | undefined>
): TransferLineOption[] {
  const transfers = new Map<string, TransferLineOption>();

  transferGroups
    .flatMap((group) => group ?? [])
    .forEach((transfer) => {
      const key = `${transfer.family ?? ""}:${transfer.id}:${transfer.label}`;

      if (!transfers.has(key)) {
        transfers.set(key, transfer);
      }
    });

  return Array.from(transfers.values()).slice(0, 40);
}

function isBusTransfer(transfer: TransferLineOption): boolean {
  return isBusLikeTransfer(transfer);
}

function showStationTooltip(stationKey: string): void {
  if (stationTooltipHideTimer !== undefined) {
    window.clearTimeout(stationTooltipHideTimer);
    stationTooltipHideTimer = undefined;
  }

  activeStationTooltipKey.value = stationKey;
}

function scheduleHideStationTooltip(stationKey: string): void {
  if (stationTooltipHideTimer !== undefined) {
    window.clearTimeout(stationTooltipHideTimer);
  }

  stationTooltipHideTimer = window.setTimeout(() => {
    if (activeStationTooltipKey.value === stationKey) {
      activeStationTooltipKey.value = undefined;
    }

    stationTooltipHideTimer = undefined;
  }, 500);
}

function getNodeDistanceKm(
  sourceNode: PatternGraphNode,
  targetNode: PatternGraphNode,
): number | undefined {
  if (
    sourceNode.lat === undefined ||
    sourceNode.lon === undefined ||
    targetNode.lat === undefined ||
    targetNode.lon === undefined
  ) {
    return undefined;
  }

  return getCoordinatesDistanceKm(
    sourceNode.lat,
    sourceNode.lon,
    targetNode.lat,
    targetNode.lon,
  );
}

function getStopDistanceKm(
  sourceStop: LineRouteStop,
  targetStop: LineRouteStop,
): number | undefined {
  const sourceCoordinates = resolveTransitLonLat(sourceStop);
  const targetCoordinates = resolveTransitLonLat(targetStop);

  if (!sourceCoordinates || !targetCoordinates) {
    return undefined;
  }

  return getCoordinatesDistanceKm(
    sourceCoordinates.lat,
    sourceCoordinates.lon,
    targetCoordinates.lat,
    targetCoordinates.lon,
  );
}

function getTopologyCoordinatePriority(
  source: LineRouteSequence["topologySource"],
): number {
  if (source === "server") {
    return 2;
  }

  if (source === "navitia") {
    return 1;
  }

  return 0;
}

function createEdgeKey(source: string, target: string): string {
  return [source, target].sort().join("--");
}

function togglePatternFlowFullscreen(event: MouseEvent): void {
  const button =
    event.currentTarget instanceof HTMLElement
      ? event.currentTarget
      : undefined;

  const shell = button?.closest(".pattern-flow-shell");

  if (!(shell instanceof HTMLElement)) {
    return;
  }

  if (document.fullscreenElement === shell) {
    void document.exitFullscreen();
    return;
  }

  void shell.requestFullscreen().then(() => {
    isPatternFlowFullscreen.value = true;
  });
}

function syncPatternFlowFullscreenState(): void {
  isPatternFlowFullscreen.value =
    document.fullscreenElement?.classList.contains("pattern-flow-shell") ??
    false;
  void nextTick();
}

function isInfoCardsDebugQueryEnabled(): boolean {
  if (typeof window === "undefined") return false;
  const params = new URLSearchParams(window.location.search);
  return ["debugInfoCards", "debugReplacementBuses"].some((key) => {
    const value = params.get(key);
    return value === "1" || value === "true" || value === "yes";
  });
}

function refreshInfoCardsDebugOutput(): void {
  if (!infoCardsDebugEnabled.value) return;
  if (typeof window !== "undefined") {
    window.__departurePatternModalInfoCardsDebugTools =
      departurePatternModalInfoCardsDebugTools;
    window.__departurePatternModalDebugTools =
      departurePatternModalInfoCardsDebugTools;
  }
  const infos = departurePatternModalInfoCardsDebugTools.getInfoCardInfos();
  infoCardsDebugOutput.value = JSON.stringify(
    {
      infoCards: infos,
      duplicateInfoCards:
        departurePatternModalInfoCardsDebugTools.checkDuplicateInfoCards(),
    },
    null,
    2,
  );
}

watch(
  () => [
    props.open,
    flowModel.value.nodes,
    hiddenTrafficMarkerKeys.value,
    selectedTrafficTimestamp.value,
  ],
  () => {
    if (infoCardsDebugEnabled.value) {
      void nextTick(refreshInfoCardsDebugOutput);
    }
  },
  { flush: "post" },
);

onMounted(() => {
  document.addEventListener("fullscreenchange", syncPatternFlowFullscreenState);
  if (isInfoCardsDebugQueryEnabled()) {
    infoCardsDebugEnabled.value = true;
    window.__departurePatternModalInfoCardsDebugTools =
      departurePatternModalInfoCardsDebugTools;
    window.__departurePatternModalDebugTools =
      departurePatternModalInfoCardsDebugTools;
    void nextTick(refreshInfoCardsDebugOutput);
  }
});

onBeforeUnmount(() => {
  transferHydrationRequest += 1;
  clearPatternDistanceLabelHideTimer();
  resetTransferHydrationStallState();
  clearTransferHydrationRateLimitTimer();
  trafficFocusRequest += 1;
  resetTrafficFocusTimers();
  if (stationTooltipHideTimer !== undefined) {
    window.clearTimeout(stationTooltipHideTimer);
  }

  document.removeEventListener(
    "fullscreenchange",
    syncPatternFlowFullscreenState,
  );
});
</script>

<template>
  <Teleport to="body" :disabled="embedded">
    <Transition name="modal-scale">
      <div
        v-if="open"
        :class="embedded ? 'pattern-page-embed' : 'modal-backdrop'"
        @click.self="!embedded && emit('close')"
      >
        <section
          :class="
            embedded
              ? 'pattern-page-embed__panel pattern-modal'
              : 'modal-panel modal-panel--wide pattern-modal'
          "
          aria-modal="true"
          role="dialog"
        >
          <header v-if="!embedded" class="modal-panel__header">
            <div class="pattern-modal__title">
              <LineIconBadge
                v-if="board"
                class="pattern-modal__line"
                :line="board.line"
              />
              <div>
                <p class="eyebrow">{{ serviceLabel }}</p>
                <h2>
                  {{
                    departure?.destination
                      ? t("pattern.passageService")
                      : t("pattern.service")
                  }}
                </h2>
                <span v-if="board">
                  {{ board.title }}
                  <template v-if="departure?.platform">
                    -
                    {{
                      t("app.platform", { platform: departure.platform })
                    }}</template
                  >
                </span>
              </div>
            </div>
            <button
              class="icon-button"
              type="button"
              :aria-label="t('common.actions.close')"
              @click="emit('close')"
            >
              ×
            </button>
          </header>

          <div class="pattern-modal__body">
            <div v-if="loading" class="pattern-modal__state">
              <span aria-hidden="true" class="loader-dot"></span>
              {{ t("pattern.loadingPattern") }}
            </div>

            <div
              v-else-if="error || pattern?.error"
              class="pattern-modal__state pattern-modal__state--error"
            >
              {{ error || pattern?.error || t("pattern.loadFailed") }}
            </div>

            <div
              v-else-if="displayPattern && displayPattern.calls.length > 0"
              class="pattern-board"
              :style="{ '--line-color': board?.line.color ?? '#0064ff' }"
            >
              <aside class="pattern-board__summary">
                <div class="pattern-board__summary-heading">
                  <div class="pattern-board__line">
                    <span
                      v-if="board"
                      class="pattern-board__mode-icon"
                      :class="`pattern-board__mode-icon--${transportModeIcon.key}`"
                      :aria-label="transportModeIcon.title"
                      :title="transportModeIcon.title"
                    >
                      <span aria-hidden="true">{{
                        transportModeIcon.label
                      }}</span>
                    </span>
                    <LineIconBadge v-if="board" :line="board.line" />
                    <span v-else>{{ departure?.lineRef ?? "" }}</span>
                  </div>
                  <slot name="summary-action"></slot>
                </div>
                <p>{{ serviceLabel }}</p>
                <strong>{{ destinationLabel }}</strong>
                <small v-if="board">
                  {{ board.title }}
                  <template v-if="departure?.platform">
                    -
                    {{
                      t("app.platform", { platform: departure.platform })
                    }}</template
                  >
                </small>
              </aside>

              <div class="pattern-board__display">
                <div class="pattern-board__top-strip">
                  <div class="pattern-board__top-strip-direction">
                    <span>{{ t("pattern.direction") }}</span>
                    <div class="pattern-board__direction-controls">
                      <label
                        v-if="hasDirectionPicker"
                        class="pattern-board__direction-picker"
                      >
                        <MaterialCombobox
                          :model-value="selectedDirectionId ?? ''"
                          :options="directionOptions ?? []"
                          :aria-label="t('pattern.changeDirectionAria')"
                          @update:model-value="emit('directionChange', $event)"
                        />
                      </label>
                      <strong v-else>{{ destinationLabel }}</strong>
                    </div>
                  </div>
                  <div class="pattern-board__meta">
                    <span>{{ servedStopsLabel }}</span>
                    <strong>{{ departureClock || "--:--" }}</strong>
                  </div>
                  <slot name="top-strip-direction-action"></slot>
                </div>

                <div class="pattern-board__workspace">
                  <div
                    ref="patternFlowShell"
                    class="pattern-flow-shell"
                    :class="{
                      'pattern-flow-shell--comfort': isComfortPatternFlow,
                      'pattern-flow-shell--compact':
                        isCompactPatternFlow || isCitiesPatternFlow,
                      'pattern-flow-shell--realistic': isRealisticPatternFlow,
                      'pattern-flow-shell--cities': isCitiesPatternFlow,
                      'pattern-flow-shell--reduce-motion': reduceMotion,
                    }"
                  >
                    <div
                      v-if="embedded && transferHydrationLoading"
                      class="pattern-flow-transfer-loader"
                      :class="{
                        'pattern-flow-transfer-loader--rate-limited':
                          transferHydrationRateLimited,
                      }"
                      role="status"
                      aria-live="polite"
                    >
                      <span aria-hidden="true"></span>
                      <div class="pattern-flow-transfer-loader__content">
                        <div class="pattern-flow-transfer-loader__label">
                          <strong>{{ transferHydrationStatusLabel }}</strong>
                          <small>{{ transferHydrationDetailLabel }}</small>
                        </div>
                        <div
                          v-if="!transferHydrationRateLimited"
                          class="pattern-flow-transfer-loader__track"
                          aria-hidden="true"
                        >
                          <i
                            :style="{
                              width: `${transferHydrationProgressPercent}%`,
                            }"
                          ></i>
                        </div>
                        <button
                          v-if="transferHydrationRetryVisible"
                          class="pattern-flow-transfer-loader__retry"
                          type="button"
                          @click.stop="retryTransferHydrationFromScratch"
                        >
                          {{ t("common.actions.retry") }}
                        </button>
                      </div>
                    </div>
                    <div
                      v-for="(status, statusIndex) in pluginStatuses"
                      :key="status.id"
                      class="pattern-flow-plugin-status"
                      :class="'pattern-flow-plugin-status--' + status.state"
                      :style="{ bottom: 14 + statusIndex * 52 + 'px' }"
                      :title="status.tooltip"
                      role="status"
                      aria-live="polite"
                    >
                      <span aria-hidden="true"></span>
                      <div>
                        <strong>{{ status.label }}</strong>
                        <small v-if="status.detail">
                          {{ status.detail }}
                        </small>
                      </div>
                    </div>
                    <pre
                      v-if="infoCardsDebugEnabled"
                      class="pattern-flow-debug-output"
                      data-info-cards-debug
                    >{{ infoCardsDebugOutput }}</pre>
                    <div
                      class="pattern-flow-actions pattern-flow-actions--desktop"
                    >
                      <slot name="flow-actions-prefix"></slot>
                      <PatternTrafficCalendarToggle
                        v-if="trafficCalendarEventCount > 0"
                        :active="trafficCalendarOpen"
                        :count="trafficCalendarEventCount"
                        :next-delay-label="trafficCalendarNextDelayLabel"
                        :reduce-motion="reduceMotion"
                        @toggle="toggleTrafficCalendar"
                      />
                      <DistanceToggle
                        v-model="showPatternDistances"
                        class="pattern-flow-action-button"
                        :reduce-motion="reduceMotion"
                      />
                      <MaterialCombobox
                        class="pattern-flow-mode-combobox"
                        :model-value="patternVisualMode"
                        :options="patternVisualModeOptions"
                        :aria-label="t('pattern.visualModeAria')"
                        @update:model-value="selectPatternVisualMode"
                      />
                      <button
                        class="pattern-flow-action-button"
                        type="button"
                        :aria-label="
                          isPatternFlowFullscreen
                            ? t('pattern.exitFullscreenAria')
                            : t('pattern.enterFullscreenAria')
                        "
                        @click.stop="togglePatternFlowFullscreen"
                      >
                        <Minimize2
                          v-if="isPatternFlowFullscreen"
                          aria-hidden="true"
                        />
                        <Expand v-else aria-hidden="true" />
                        <span>
                          {{
                            isPatternFlowFullscreen
                              ? t("pattern.collapse")
                              : t("pattern.fullscreen")
                          }}
                        </span>
                      </button>
                    </div>
                    <MobileActionsMenu :aria-label="t('pattern.optionsAria')">
                      <template #default="{ close }">
                        <slot name="flow-actions-prefix"></slot>
                        <PatternTrafficCalendarToggle
                          v-if="trafficCalendarEventCount > 0"
                          :active="trafficCalendarOpen"
                          :count="trafficCalendarEventCount"
                          :next-delay-label="trafficCalendarNextDelayLabel"
                          :reduce-motion="reduceMotion"
                          @toggle="
                            toggleTrafficCalendar();
                            close();
                          "
                        />
                        <DistanceToggle
                          v-model="showPatternDistances"
                          class="pattern-flow-action-button"
                          :reduce-motion="reduceMotion"
                          @click="close"
                        />
                        <MaterialCombobox
                          class="pattern-flow-mode-combobox"
                          :model-value="patternVisualMode"
                          :options="patternVisualModeOptions"
                          :aria-label="t('pattern.visualModeAria')"
                          @update:model-value="selectPatternVisualMode"
                          @change="close"
                        />
                        <button
                          class="pattern-flow-action-button"
                          type="button"
                          :aria-label="
                            isPatternFlowFullscreen
                              ? t('pattern.exitFullscreenAria')
                              : t('pattern.enterFullscreenAria')
                          "
                          @click.stop="
                            togglePatternFlowFullscreen($event);
                            close();
                          "
                        >
                          <Minimize2
                            v-if="isPatternFlowFullscreen"
                            aria-hidden="true"
                          />
                          <Expand v-else aria-hidden="true" />
                          <span>
                            {{
                              isPatternFlowFullscreen
                                ? t("pattern.collapse")
                                : t("pattern.fullscreen")
                            }}
                          </span>
                        </button>
                      </template>
                    </MobileActionsMenu>
                    <VueFlow
                      pan-on-drag
                      :key="patternFlowKey"
                      class="pattern-flow"
                      :nodes="allFlowNodes"
                      :node-types="pluginNodeTypes"
                      :edges="flowModel.edges"
                      :default-viewport="initialViewport"
                      :fit-view-on-init="isFullLineMode"
                      :min-zoom="0.34"
                      :max-zoom="1.7"
                      :nodes-draggable="false"
                      :nodes-connectable="false"
                      :elements-selectable="false"
                      :zoom-on-scroll="shouldZoomOnWheel"
                      :zoom-on-pinch="true"
                      :pan-on-scroll="false"
                      :prevent-scrolling="shouldZoomOnWheel"
                      @pane-ready="handlePatternFlowReady"
                      @viewport-change="handlePatternFlowViewportChange"
                      @edge-click="handlePatternEdgeClick"
                    >
                      <Controls :show-interactive="false" />
                      <template #node-city-zone="{ data }">
                        <div
                          class="pattern-flow-city-zone"
                          :data-city-zone-key="data.key"
                          :data-city-zone-width="data.width"
                          :data-layout-x="data.layoutX"
                          :data-layout-y="data.layoutY"
                          :data-node-x="data.nodeX"
                          :data-node-y="data.nodeY"
                          :style="{
                            '--city-zone-width': `${data.width}px`,
                          }"
                          aria-hidden="true"
                        >
                          <span>{{ data.city }}</span>
                        </div>
                      </template>
                      <template #node-traffic-marker-connector="{ data }">
                        <div
                          class="pattern-flow-traffic-marker-connector"
                          :data-traffic-marker-connector-key="data.key"
                          :class="[
                            `pattern-flow-traffic-marker-connector--${data.kind}`,
                            `pattern-flow-traffic-marker-connector--${data.placement}`,
                          ]"
                          :style="{
                            '--traffic-marker-connector-angle': `${data.connectorAngle}deg`,
                            '--traffic-marker-connector-height': `${data.connectorHeight}px`,
                            '--traffic-marker-connector-length': `${data.connectorLength}px`,
                            '--traffic-marker-connector-offset': `${data.connectorOffset}px`,
                            '--traffic-marker-layout-height': `${data.markerHeight}px`,
                            '--traffic-marker-layout-width': `${data.markerWidth}px`,
                          }"
                          aria-hidden="true"
                        ></div>
                      </template>
                      <template #node-traffic-marker="{ data }">
                        <div
                          class="pattern-flow-traffic-marker"
                          :data-traffic-marker-key="data.key"
                          :class="[
                            `pattern-flow-traffic-marker--${data.kind}`,
                            data.kind === 'interruption' || data.replacementBus
                              ? 'pattern-flow-traffic-marker--large'
                              : '',
                            `pattern-flow-traffic-marker--${data.placement}`,
                          ]"
                          :style="{
                            '--traffic-marker-layout-height': `${data.markerHeight}px`,
                          }"
                          @mouseenter="hoverTrafficMarker(data.key)"
                          @mouseleave="unhoverTrafficMarker(data.key)"
                          @focusin="hoverTrafficMarker(data.key)"
                          @focusout="unhoverTrafficMarker(data.key)"
                        >
                          <button
                            v-if="data.kind === 'interruption'"
                            class="pattern-flow-traffic-marker__dismiss"
                            type="button"
                            :aria-label="t('pattern.closeTrafficAria')"
                            @pointerdown.stop="hideTrafficMarker(data.key)"
                            @click.stop="hideTrafficMarker(data.key)"
                          >
                            <X aria-hidden="true" />
                          </button>
                          <button
                            v-if="data.replacementBus"
                            class="pattern-flow-traffic-marker__focus"
                            type="button"
                            :aria-label="t('pattern.focusTrafficAria')"
                            @pointerdown.stop.prevent
                            @click.stop="focusTrafficMarker(data.pulseStationKeys)"
                          >
                            <Eye aria-hidden="true" />
                          </button>
                          <span
                            v-if="data.replacementBus"
                            class="pattern-flow-traffic-marker__icon"
                            aria-hidden="true"
                          >
                            <Bus />
                          </span>
                          <span
                            v-else
                            class="pattern-flow-traffic-marker__icon"
                            aria-hidden="true"
                          >
                            <TriangleAlert />
                          </span>
                          <span class="pattern-flow-traffic-marker__content">
                            <span class="pattern-flow-traffic-marker__copy">
                              <strong>{{ data.statusLabel }}</strong>
                              <small v-if="data.detailLabel">
                                {{ data.detailLabel }}
                              </small>
                            </span>
                            <button
                              class="pattern-flow-traffic-marker__details"
                              type="button"
                              @pointerdown.stop="
                                showTrafficImpactPopup(data.trafficImpact)
                              "
                              @click.stop="
                                showTrafficImpactPopup(data.trafficImpact)
                              "
                            >
                              <Info aria-hidden="true" />
                              <span>{{ t("pattern.details") }}</span>
                            </button>
                          </span>
                        </div>
                      </template>
                      <template #node-traffic-walking="{ data }">
                        <div
                          class="pattern-flow-traffic-walking"
                          :data-traffic-walking-edge-key="data.edgeKey"
                          role="note"
                          :aria-label="
                            t('pattern.walkingTimeAria', {
                              time: data.durationLabel,
                            })
                          "
                        >
                          <Footprints aria-hidden="true" />
                          <span>{{ data.durationLabel }}</span>
                        </div>
                      </template>
                      <template #node-station="{ data }">
                        <div
                          class="pattern-flow-station"
                          :data-station-key="data.key"
                          :data-station-label="data.label"
                          :data-station-city="data.city ?? ''"
                          :data-city-node="data.cityNode ? 'true' : 'false'"
                          :data-mixed-served="
                            data.mixedServed ? 'true' : 'false'
                          "
                          :data-layout-x="data.layoutX"
                          :data-layout-y="data.layoutY"
                          :data-node-x="data.nodeX"
                          :data-node-y="data.nodeY"
                          :data-served="data.served ? 'true' : 'false'"
                          :data-current="data.current ? 'true' : 'false'"
                          :class="{
                            'pattern-flow-station--current': data.current,
                            'pattern-flow-station--skipped': !data.served,
                            'pattern-flow-station--terminal': data.branchEnd,
                            'pattern-flow-station--city': data.cityNode,
                            'pattern-flow-station--mixed': data.mixedServed,
                            'pattern-flow-station--tooltip-open':
                              activeStationTooltipKey === data.key,
                            'pattern-flow-station--traffic-interruption':
                              data.trafficImpact?.kind === 'interruption',
                            'pattern-flow-station--traffic-disturbance':
                              data.trafficImpact?.kind === 'disturbance',
                            'pattern-flow-station--traffic-focus':
                              trafficPulseStationKeys.has(data.key),
                          }"
                          :title="
                            data.mixedServed
                              ? t('pattern.cityPartiallyServedTitle')
                              : data.served
                                ? undefined
                                : t('pattern.skippedTitle')
                          "
                          @focusin="showStationTooltip(data.key)"
                          @focusout="scheduleHideStationTooltip(data.key)"
                          @mouseenter="showStationTooltip(data.key)"
                          @mouseleave="scheduleHideStationTooltip(data.key)"
                          @click.stop="
                            showTrafficImpactPopup(data.trafficImpact)
                          "
                        >
                          <Handle
                            id="station-target"
                            class="pattern-flow-station__handle pattern-flow-station__handle--target"
                            type="target"
                            :position="Position.Left"
                          />
                          <Handle
                            id="station-source"
                            class="pattern-flow-station__handle pattern-flow-station__handle--source"
                            type="source"
                            :position="Position.Right"
                          />
                          <span
                            class="pattern-flow-station__dot"
                            aria-hidden="true"
                          ></span>
                          <span class="station-name">{{ data.label }}</span>
                          <span
                            v-if="data.nonBusTransfers.length > 0"
                            class="pattern-flow-station__transfers pattern-flow-station__transfers--inline"
                            :aria-label="t('pattern.mainTransfersAria')"
                          >
                            <LineIconBadge
                              v-for="transfer in data.nonBusTransfers"
                              :key="`${data.key}-non-bus-${transfer.id}-${transfer.label}`"
                              class="pattern-flow-station__transfer"
                              :line="transfer"
                              compact
                            />
                          </span>
                          <small v-if="data.time">{{
                            formatClock(data.time)
                          }}</small>
                          <small v-else-if="!data.served && data.branchEnd">
                            {{ t("pattern.skipped") }}
                          </small>
                          <em v-if="data.branchChip">{{ data.branchChip }}</em>
                          <Transition name="pattern-flow-tooltip-open" appear>
                            <article
                              v-if="
                                data.transfers.length > 0 &&
                                activeStationTooltipKey === data.key
                              "
                              class="pattern-flow-station__transfer-tooltip"
                              role="tooltip"
                            >
                              <StationTransferDetails
                                :station-label="data.label"
                                :city="data.cityNode ? undefined : data.city"
                                :transfers="data.transfers"
                                :rich-details="richTransferTooltips"
                                :line-color="board?.line.color ?? '#0064ff'"
                              />
                            </article>
                          </Transition>
                        </div>
                      </template>
                    </VueFlow>
                    <PatternFlowMiniMap
                      v-if="showMiniMap"
                      :nodes="flowModel.stationNodes"
                      :edges="flowModel.edges"
                      :node-width="currentLayoutOptions.nodeWidth"
                      :node-height="currentLayoutOptions.nodeHeight"
                      :viewport="patternFlowViewport"
                      :viewport-size="patternFlowViewportSize"
                      :line-color="board?.line.color ?? '#0064ff'"
                      @focus="focusPatternFlowOn"
                    />
                    <!-- Shows the traffic information tooltip, including interrupted service cases. -->
                    <Transition name="pattern-flow-traffic-popup">
                      <aside
                        v-if="activeTrafficImpact"
                        class="pattern-flow-traffic-popup"
                        role="dialog"
                        :aria-label="t('pattern.trafficDetailsAria')"
                      >
                        <button
                          class="pattern-flow-traffic-popup__close"
                          type="button"
                          :aria-label="t('pattern.closeTrafficAria')"
                          @click="closeTrafficImpactPopup"
                        >
                          ×
                        </button>
                        <TrafficDisruptionCard
                          :disruption="activeTrafficImpact.disruption"
                          compact
                          :show-header="false"
                        />
                      </aside>
                    </Transition>
                  </div>
                  <PatternTrafficCalendarSurface
                    v-if="trafficCalendarEventCount > 0"
                    :open="trafficCalendarOpen"
                    :expanded="trafficCalendarExpanded"
                    :has-next="hasNextTrafficCalendarMonth"
                    :has-previous="hasPreviousTrafficCalendarMonth"
                    :calendar="trafficCalendar"
                    :selected-date-key="selectedTrafficCalendarDateKey"
                    :selected-day="selectedTrafficCalendarDay"
                    :selected-disruptions="selectedTrafficCalendarDisruptions"
                    :loading-date-key="trafficCalendarLoadingDateKey"
                    :loading-direction="trafficCalendarLoadingDirection"
                    @close="closeTrafficCalendar"
                    @close-expanded="closeExpandedTrafficCalendar"
                    @next="selectNextTrafficCalendarMonth"
                    @previous="selectPreviousTrafficCalendarMonth"
                    @reset-today="resetTrafficCalendarToday"
                    @select="selectTrafficCalendarDay"
                    @expand="expandTrafficCalendar"
                    @focus-disruption="focusTrafficDisruption"
                  />
                </div>
              </div>
            </div>

            <div v-else class="pattern-modal__state">
              {{ t("pattern.unavailableForDeparture") }}
            </div>
          </div>
        </section>
      </div>
    </Transition>
  </Teleport>
</template>
