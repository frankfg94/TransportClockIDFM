import { computed, onBeforeUnmount, onMounted, readonly, ref, watch } from "vue";
import { createNearbyDataProviders } from "../../services/nearbyDataProviders";
import { getCoordinatesDistanceMeters } from "../../services/distance";
import type { GlobalMapLine, GlobalMapMode, GlobalMapStation } from "../transport-map/contracts/manifest";
import type { TransportMapNetwork } from "../transport-map/contracts/network";
import { groupGlobalMapStations } from "../transport-map/search/globalMapSearch";
import {
  buildStationCorrespondenceContext,
  queryStationCorrespondenceStations,
  STATION_CORRESPONDENCE_RADIUS_METERS,
} from "../transport-map/spatial/stationCorrespondences";
import type { NearbyStationEntry } from "./nearbyStations";
import {
  listNearbyHeavyJourneyAlternatives,
  limitNearbyHeavyProjectedStations,
  NEARBY_HEAVY_SEARCH_MAX_METERS,
  NEARBY_HEAVY_TRANSPORT_MODES,
  selectNearbyHeavyTargetCandidates,
  type JourneyProvider,
  type NearbyHeavyTransportAccess,
  type NearbyHeavyTransportCandidate,
} from "./nearbyHeavyTransports";

// A heavy line can be reachable through a nearby feeder even when its
// closest station is a different branch/terminus. Keep enough candidates to
// retain cases such as T10 -> RER B at Robinson and Croix de Berny.
const HEAVY_STATION_CANDIDATES_PER_LINE = 6;
const HEAVY_RESOLUTION_CONCURRENCY = 6;
const HEAVY_REFRESH_INTERVAL_MS = 5 * 60_000;

export interface NearbyHeavyTransportSource {
  origin: { value?: { lon: number; lat: number } };
  network?: { value?: TransportMapNetwork };
  stations: { value: NearbyStationEntry[] };
  activeModes: { value: GlobalMapMode[] };
  radius: { value: number };
}

export interface NearbyHeavyTransportResolverInput {
  origin: { lon: number; lat: number };
  network: TransportMapNetwork;
  localEntries: readonly NearbyStationEntry[];
  activeModes: readonly GlobalMapMode[];
  radiusMeters: number;
  journeyProvider: JourneyProvider;
}

export interface HeavyTransportResolver {
  resolve(input: NearbyHeavyTransportResolverInput): Promise<NearbyHeavyTransportCandidate[]>;
}

export interface UseNearbyHeavyTransportsOptions {
  journeyProvider?: JourneyProvider;
  resolver?: HeavyTransportResolver;
}

const defaultJourneyProvider: JourneyProvider = createNearbyDataProviders().travelRoutes;

export const defaultNearbyHeavyTransportResolver: HeavyTransportResolver = {
  async resolve(input) {
    const activeHeavyModes = new Set(
      input.activeModes.filter((mode) => NEARBY_HEAVY_TRANSPORT_MODES.includes(mode)),
    );
    if (activeHeavyModes.size === 0) return [];

    const existingIds = new Set(input.localEntries.map((entry) => entry.id));
    const activeFeederModes = input.activeModes.filter((mode) => !NEARBY_HEAVY_TRANSPORT_MODES.includes(mode));
    const localLines = input.localEntries.flatMap((entry) => entry.lines)
      .filter((line) => activeFeederModes.includes(line.mode));
    const lineCandidates = new Map<string, Array<{ station: GlobalMapStation; line: GlobalMapLine; distanceMeters: number }>>();
    const projectedFeederLinesCache = new Map<string, GlobalMapLine[]>();

    function projectedFeederLines(station: GlobalMapStation, distanceMeters: number): GlobalMapLine[] {
      if (distanceMeters <= input.radiusMeters) return [];
      const cached = projectedFeederLinesCache.get(station.id);
      if (cached) return cached;

      const nearbyStations = queryStationCorrespondenceStations(
        input.network,
        station,
        STATION_CORRESPONDENCE_RADIUS_METERS,
      );
      const correspondence = buildStationCorrespondenceContext(
        [station],
        nearbyStations,
        input.network.linesById,
        { allowedModes: activeFeederModes },
      );
      projectedFeederLinesCache.set(station.id, correspondence.lines);
      return correspondence.lines;
    }

    for (const station of input.network.stations) {
      const distanceMeters = getCoordinatesDistanceMeters(
        input.origin.lat,
        input.origin.lon,
        station.lat,
        station.lon,
      );
      if (distanceMeters > NEARBY_HEAVY_SEARCH_MAX_METERS) continue;

      for (const lineId of station.lineIds) {
        const line = input.network.linesById.get(lineId);
        if (!line || !activeHeavyModes.has(line.mode)) continue;
        const candidates = lineCandidates.get(line.id) ?? [];
        candidates.push({ station, line, distanceMeters });
        lineCandidates.set(line.id, candidates);
      }
    }

    const targets = selectNearbyHeavyTargetCandidates(
      [...lineCandidates.values()].flat(),
      HEAVY_STATION_CANDIDATES_PER_LINE,
    );

    const resolved = await mapWithConcurrency(
      targets,
      HEAVY_RESOLUTION_CONCURRENCY,
      async ({ station, line, distanceMeters }) => {
        const correspondenceLines = projectedFeederLines(station, distanceMeters);
        const feederLines = mergeNearbyHeavyFeederLines(
          localLines,
          correspondenceLines,
        );
        const localLineIds = new Set(
          feederLines.flatMap((feederLine) => [
            feederLine.id,
            feederLine.sourceLineId,
          ].filter((value): value is string => Boolean(value))),
        );
        const localLineCodes = new Set(
          feederLines.flatMap((feederLine) => [
            feederLine.code,
            feederLine.label,
            feederLine.sourceLineId,
            ...feederLine.aliases,
          ].filter((value): value is string => Boolean(value))),
        );
        const journeys = await input.journeyProvider.findJourneys({
          origin: input.origin,
          destination: station,
        }).catch(() => []);
        const currentAlternatives = listNearbyHeavyJourneyAlternatives(journeys, {
          stationDistanceMeters: distanceMeters,
          localLineIds,
          localLineCodes,
        }).map((access) => normalizeNearbyHeavyAccessLine(access, feederLines));

        // The live departure window is not enough to describe every valid
        // feeder: a daytime tram may be absent from a current-time response
        // while a bus remains available. Probe a representative daytime
        // window as well, then retain both sets of distinct feeder lines.
        const daytimeJourneys = await input.journeyProvider.findJourneys({
          origin: input.origin,
          destination: station,
          datetime: representativeJourneyDateTime(),
        }).catch(() => []);
        const daytimeAlternatives = listNearbyHeavyJourneyAlternatives(daytimeJourneys, {
          stationDistanceMeters: distanceMeters,
          localLineIds,
          localLineCodes,
        }).map((access) => normalizeNearbyHeavyAccessLine(access, feederLines));
        const currentAccess = currentAlternatives[0];
        const accessAlternatives = currentAccess && isNoctilienAccess(currentAccess, feederLines)
          ? daytimeAlternatives.length > 0
            ? mergeNearbyHeavyAccessAlternatives(
              currentAlternatives.filter((candidate) => !isNoctilienAccess(candidate, feederLines)),
              daytimeAlternatives,
            )
            : currentAlternatives
          : mergeNearbyHeavyAccessAlternatives(currentAlternatives, daytimeAlternatives);
        const access = accessAlternatives[0];
        if (!access) return undefined;

        const entry = createHeavyEntry(station, line, input.network, distanceMeters);
        if (existingIds.has(entry.id)) return undefined;
        return { entry, station, line, distanceMeters, access, accessAlternatives, correspondenceLines };
      },
    );

    const byStation = new Map<string, {
      entry: NearbyStationEntry;
      station: GlobalMapStation;
      lines: GlobalMapLine[];
      accesses: Record<string, NearbyHeavyTransportAccess>;
      accessAlternatives: Record<string, NearbyHeavyTransportAccess[]>;
      correspondenceLines: GlobalMapLine[];
      distanceMeters: number;
    }>();
    for (const result of resolved) {
      if (!result) continue;
      const existing = byStation.get(result.entry.id);
      if (existing) {
        existing.lines.push(result.line);
        existing.accesses[result.line.id] = result.access;
        existing.accessAlternatives[result.line.id] = result.accessAlternatives;
        existing.correspondenceLines = mergeNearbyHeavyFeederLines(
          existing.correspondenceLines,
          result.correspondenceLines,
        );
        existing.distanceMeters = Math.min(existing.distanceMeters, result.distanceMeters);
      } else {
        byStation.set(result.entry.id, {
          entry: { ...result.entry, lines: [result.line] },
          station: result.station,
          lines: [result.line],
          accesses: { [result.line.id]: result.access },
          accessAlternatives: { [result.line.id]: result.accessAlternatives },
          correspondenceLines: result.correspondenceLines,
          distanceMeters: result.distanceMeters,
        });
      }
    }

    const resolvedCandidates = [...byStation.values()]
      .map((value) => {
        const access = Object.values(value.accesses).sort((left, right) => left.totalSeconds - right.totalSeconds)[0];
        const accessAlternativesByLine = value.accessAlternatives;
        const accessAlternatives = mergeNearbyHeavyAccessAlternatives(
          ...Object.values(accessAlternativesByLine),
        );
        return {
          id: value.entry.id,
          entry: value.entry,
          station: value.station,
          lines: value.lines,
          distanceMeters: value.distanceMeters,
          access,
          accessByLine: value.accesses,
          accessAlternatives,
          accessAlternativesByLine,
          correspondenceLines: value.correspondenceLines,
          projected: value.distanceMeters > input.radiusMeters,
        } satisfies NearbyHeavyTransportCandidate;
      })
      .sort((left, right) => left.distanceMeters - right.distanceMeters || left.station.name.localeCompare(right.station.name, "fr"));

    return limitNearbyHeavyProjectedStations(resolvedCandidates, input.origin);
  },
};

export function useNearbyHeavyTransports(
  source: NearbyHeavyTransportSource,
  options: UseNearbyHeavyTransportsOptions = {},
) {
  const candidates = ref<NearbyHeavyTransportCandidate[]>([]);
  const isLoading = ref(false);
  const error = ref<string>();
  const hiddenStationIds = ref<Set<string>>(new Set());
  const requestToken = ref(0);
  let refreshTimer: number | undefined;
  let refreshInterval: number | undefined;

  const resolver = options.resolver ?? defaultNearbyHeavyTransportResolver;
  const journeyProvider = options.journeyProvider ?? defaultJourneyProvider;
  const visibleCandidates = computed(() => candidates.value.filter((candidate) => !hiddenStationIds.value.has(candidate.id)));

  async function refresh(): Promise<void> {
    const origin = source.origin.value;
    const network = source.network?.value;
    if (!origin || !network) {
      candidates.value = [];
      return;
    }

    const token = requestToken.value + 1;
    requestToken.value = token;
    isLoading.value = true;
    error.value = undefined;
    try {
      const next = await resolver.resolve({
        origin,
        network,
        localEntries: source.stations.value,
        activeModes: source.activeModes.value,
        radiusMeters: source.radius.value,
        journeyProvider,
      });
      if (token === requestToken.value) candidates.value = next;
    } catch (cause) {
      if (token === requestToken.value) {
        candidates.value = [];
        error.value = cause instanceof Error ? cause.message : "heavy-transport-unavailable";
      }
    } finally {
      if (token === requestToken.value) isLoading.value = false;
    }
  }

  function refreshSoon(): void {
    if (typeof window === "undefined") return;
    if (refreshTimer !== undefined) window.clearTimeout(refreshTimer);
    refreshTimer = window.setTimeout(() => {
      refreshTimer = undefined;
      void refresh();
    }, 100);
  }

  function hideStation(stationId: string): void {
    hiddenStationIds.value = new Set(hiddenStationIds.value).add(stationId);
  }

  function toggleStation(stationId: string): void {
    const next = new Set(hiddenStationIds.value);
    if (next.has(stationId)) next.delete(stationId);
    else next.add(stationId);
    hiddenStationIds.value = next;
  }

  function resetVisibility(): void {
    hiddenStationIds.value = new Set();
  }

  watch(
    () => [
      source.origin.value?.lon,
      source.origin.value?.lat,
      source.network?.value?.stations.length,
      source.activeModes.value.join(","),
      source.stations.value.map((entry) => entry.id).join(","),
    ],
    refreshSoon,
    { immediate: true },
  );

  onMounted(() => {
    refreshInterval = window.setInterval(() => {
      if (document.visibilityState !== "hidden") void refresh();
    }, HEAVY_REFRESH_INTERVAL_MS);
    document.addEventListener("visibilitychange", handleVisibilityChange);
  });

  onBeforeUnmount(() => {
    requestToken.value += 1;
    if (refreshTimer !== undefined) window.clearTimeout(refreshTimer);
    if (refreshInterval !== undefined) window.clearInterval(refreshInterval);
    document.removeEventListener("visibilitychange", handleVisibilityChange);
  });

  function handleVisibilityChange(): void {
    if (document.visibilityState !== "hidden") void refresh();
  }

  return {
    candidates: computed(() => candidates.value),
    visibleCandidates,
    hiddenStationIds: computed(() => hiddenStationIds.value),
    isLoading: readonly(isLoading),
    error: readonly(error),
    refresh,
    hideStation,
    toggleStation,
    resetVisibility,
  };
}

function representativeJourneyDateTime(): string {
  const date = new Date();
  const midday = new Date(date);
  midday.setHours(12, 0, 0, 0);
  if (midday.getTime() <= date.getTime()) midday.setDate(midday.getDate() + 1);
  const pad = (value: number) => String(value).padStart(2, "0");
  return `${midday.getFullYear()}${pad(midday.getMonth() + 1)}${pad(midday.getDate())}T${pad(midday.getHours())}${pad(midday.getMinutes())}${pad(midday.getSeconds())}`;
}

function isNoctilienAccess(
  access: NearbyHeavyTransportAccess,
  localLines: readonly GlobalMapLine[],
): boolean {
  if (access.kind !== "connection") return false;
  const feederCode = access.feederLineCode?.trim().toLocaleUpperCase("fr-FR");
  if (feederCode?.startsWith("N") && /\d/u.test(feederCode.slice(1))) return true;
  return localLines.some((line) => {
    if (line.mode !== "NOCTILIEN") return false;
    if (access.feederLineId && line.id === access.feederLineId) return true;
    return Boolean(
      access.feederLineCode &&
      [line.code, line.label, ...line.aliases].some((value) =>
        value.trim().toLocaleLowerCase("fr-FR") === access.feederLineCode!.trim().toLocaleLowerCase("fr-FR")),
    );
  });
}

function mergeNearbyHeavyFeederLines(
  ...groups: readonly (readonly GlobalMapLine[])[]
): GlobalMapLine[] {
  const linesByKey = new Map<string, GlobalMapLine>();

  for (const group of groups) {
    for (const line of group) {
      const key = (line.code || line.sourceLineId || line.id).trim().toLocaleLowerCase("fr-FR");
      if (!linesByKey.has(key)) linesByKey.set(key, line);
    }
  }

  return [...linesByKey.values()];
}

function normalizeNearbyHeavyAccessLine(
  access: NearbyHeavyTransportAccess,
  feederLines: readonly GlobalMapLine[],
): NearbyHeavyTransportAccess {
  if (access.kind !== "connection") return access;
  const reference = access.feederLineCode?.trim() || access.feederLineId?.trim();
  if (!reference) return access;

  const line = feederLines.find((candidate) => [
    candidate.id,
    candidate.code,
    candidate.label,
    candidate.sourceLineId ?? "",
    ...candidate.aliases,
  ].some((candidateReference) =>
    lineReferenceVariants(candidateReference).some((variant) =>
      lineReferenceVariants(reference).includes(variant),
    ),
  ));
  if (!line) return access;

  return {
    ...access,
    feederLineId: line.id,
    feederLineCode: line.code || line.label,
    feederMode: line.mode,
  };
}

function lineReferenceVariants(value: string): string[] {
  const normalized = value.trim().toLocaleLowerCase("fr-FR");
  const variants = new Set([normalized]);
  const parenthetical = /\((?:ex(?:\.|\s+)?|anciennement\s+)?([^)]*)\)/giu;
  for (const match of normalized.matchAll(parenthetical)) {
    const alias = match[1]?.trim();
    if (alias) variants.add(alias);
  }
  return [...variants];
}

function mergeNearbyHeavyAccessAlternatives(
  ...groups: readonly (readonly NearbyHeavyTransportAccess[])[]
): NearbyHeavyTransportAccess[] {
  const alternatives = new Map<string, NearbyHeavyTransportAccess>();

  for (const group of groups) {
    for (const access of group) {
      const key = access.kind === "direct"
        ? "direct"
        : `connection:${(access.feederLineCode ?? access.feederLineId ?? access.feederMode ?? "unknown").trim().toLocaleLowerCase("fr-FR")}`;
      const existing = alternatives.get(key);
      if (!existing || compareNearbyHeavyAccess(access, existing) < 0) {
        alternatives.set(key, access);
      }
    }
  }

  return [...alternatives.values()].sort(compareNearbyHeavyAccess);
}

function compareNearbyHeavyAccess(
  left: NearbyHeavyTransportAccess,
  right: NearbyHeavyTransportAccess,
): number {
  return left.totalSeconds - right.totalSeconds ||
    left.walkingSeconds - right.walkingSeconds ||
    (left.feederRideSeconds ?? Number.POSITIVE_INFINITY) - (right.feederRideSeconds ?? Number.POSITIVE_INFINITY) ||
    (left.feederLineCode ?? left.feederLineId ?? "").localeCompare(right.feederLineCode ?? right.feederLineId ?? "", "fr");
}

function createHeavyEntry(
  station: GlobalMapStation,
  line: GlobalMapLine,
  network: TransportMapNetwork,
  distanceMeters: number,
): NearbyStationEntry {
  const group = groupGlobalMapStations([station], network.lines)[0];
  if (!group) throw new Error("heavy-station-group-missing");
  return {
    id: group.id,
    station: group,
    memberStations: [station],
    lines: [line],
    distanceMeters,
    lineDistanceMeters: { [line.id]: distanceMeters },
    lineInsideRadius: { [line.id]: true },
    // Supplemental entries are eligible for their own schedules even when
    // their real station is outside the adjustable local radius.
    insideRadius: true,
  };
}

async function mapWithConcurrency<T, R>(
  values: readonly T[],
  concurrency: number,
  worker: (value: T) => Promise<R>,
): Promise<R[]> {
  const results = new Array<R>(values.length);
  let nextIndex = 0;
  await Promise.all(Array.from({ length: Math.min(Math.max(1, concurrency), values.length) }, async () => {
    while (nextIndex < values.length) {
      const index = nextIndex;
      nextIndex += 1;
      results[index] = await worker(values[index]);
    }
  }));
  return results;
}
