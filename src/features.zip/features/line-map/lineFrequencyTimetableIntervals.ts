import type { TranslationKey } from "../../i18n";
import type {
  GtfsLineTimetableCall,
  GtfsLineTimetableStop,
  GtfsLineTimetableTrip,
} from "../../types/lineFrequencyTimetable";

export interface GtfsLineTimetableWindow {
  key: string;
  startSeconds: number;
  endSeconds: number;
  label: TranslationKey;
}

/**
 * The same generic service-day bands used by the frequency computation. They
 * are deliberately line-agnostic: the timetable fills each cell from the
 * actual departures found in that band.
 */
export const GTFS_LINE_TIMETABLE_WINDOWS = [
  {
    key: "beforeFive",
    startSeconds: 0,
    endSeconds: 5 * 3600,
    label: "globalMap.sidebar.gtfsFrequency.timetableBeforeFive",
  },
  {
    key: "fiveToSeven",
    startSeconds: 5 * 3600,
    endSeconds: 7 * 3600,
    label: "globalMap.sidebar.gtfsFrequency.timetableFiveToSeven",
  },
  {
    key: "sevenToNineThirty",
    startSeconds: 7 * 3600,
    endSeconds: 9.5 * 3600,
    label: "globalMap.sidebar.gtfsFrequency.timetableSevenToNineThirty",
  },
  {
    key: "nineThirtyToSeventeenThirty",
    startSeconds: 9.5 * 3600,
    endSeconds: 17.5 * 3600,
    label: "globalMap.sidebar.gtfsFrequency.timetableNineThirtyToSeventeenThirty",
  },
  {
    key: "seventeenThirtyToNineteen",
    startSeconds: 17.5 * 3600,
    endSeconds: 19 * 3600,
    label: "globalMap.sidebar.gtfsFrequency.timetableSeventeenThirtyToNineteen",
  },
  {
    key: "nineteenToTwentyThreeThirty",
    startSeconds: 19 * 3600,
    endSeconds: 23.5 * 3600,
    label: "globalMap.sidebar.gtfsFrequency.timetableNineteenToTwentyThreeThirty",
  },
  {
    key: "afterTwentyThreeThirty",
    startSeconds: 23.5 * 3600,
    endSeconds: 24 * 3600,
    label: "globalMap.sidebar.gtfsFrequency.timetableAfterTwentyThreeThirty",
  },
] as const satisfies readonly GtfsLineTimetableWindow[];

export interface GtfsTimetableInterval {
  /** Raw minutes are kept so callers can round only at presentation time. */
  minMinutes: number;
  maxMinutes: number;
}

export function isBoardableGtfsTimetableCall(call: GtfsLineTimetableCall): boolean {
  return (
    [0, 2, 3].includes(call.pickupType) &&
    call.departure !== null &&
    Number.isFinite(call.departure)
  );
}

/**
 * Builds the observed interval range for one direction and one time band.
 * Departures are compared at each station (parent stop when available), then
 * pooled across stations. Gaps crossing a time-band boundary stay out of both
 * bands, so each table cell describes only its own period.
 */
export function calculateGtfsTimetableInterval(
  trips: readonly GtfsLineTimetableTrip[],
  window: GtfsLineTimetableWindow,
  stopsById?: ReadonlyMap<string, GtfsLineTimetableStop>,
): GtfsTimetableInterval | undefined {
  const departuresByStation = new Map<string, Set<number>>();

  for (const trip of trips) {
    for (const call of trip.calls) {
      if (!isBoardableGtfsTimetableCall(call)) continue;
      const departure = call.departure;
      if (
        departure === null ||
        departure < window.startSeconds ||
        departure >= window.endSeconds
      ) {
        continue;
      }

      const stationKey = stopsById?.get(call.stopId)?.parentId ?? call.stopId;
      const departures = departuresByStation.get(stationKey) ?? new Set<number>();
      departures.add(departure);
      departuresByStation.set(stationKey, departures);
    }
  }

  const gaps: number[] = [];
  for (const departures of departuresByStation.values()) {
    const ordered = [...departures].sort((left, right) => left - right);
    for (let index = 1; index < ordered.length; index += 1) {
      const gapSeconds = ordered[index]! - ordered[index - 1]!;
      if (gapSeconds > 0) gaps.push(gapSeconds / 60);
    }
  }

  if (!gaps.length) return undefined;
  return {
    minMinutes: Math.min(...gaps),
    maxMinutes: Math.max(...gaps),
  };
}
