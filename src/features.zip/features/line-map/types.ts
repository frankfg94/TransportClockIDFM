import type {
  LineRouteSequence,
  StationSearchOption,
  TransferLineOption,
} from "../../types/transit";
import type { GeographicViewport } from "../network-ghost/geoProjection";

import type { LineGeometryAttempt, LineGeometryPoint, LineGeometrySource } from "./lineGeometry";
export interface LineMapQuayView {
  id: string;
  name: string;
  lon?: number;
  lat?: number;
  projectedX?: number;
  projectedY?: number;
  srsName?: string;
}

export interface LineMapStopView {
  id: string;
  label: string;
  city?: string;
  lon?: number;
  lat?: number;
  projectedX?: number;
  projectedY?: number;
  coordinateSource?: "wgs84" | "lambert93" | "fallback";
  x: number;
  y: number;
  routeIds: string[];
  routeLabels: string[];
  quays?: LineMapQuayView[];
  station: StationSearchOption;
}

export interface LineMapSegmentView {
  id: string;
  fromStopId: string;
  toStopId: string;
  distanceKm?: number;
  polyline?: LineGeometryPoint[];
}

export interface LineMapEntranceView {
  id: string;
  parentStopId: string;
  name: string;
  code?: string;
  lon: number;
  lat: number;
  x: number;
  y: number;
}

export interface LineMapBranchView {
  id: string;
  label: string;
  direction?: string;
  topologySource?: LineRouteSequence["topologySource"];
  stopIds: string[];
}

export interface MapTile {
  id: string;
  url: string;
  priority: "visible" | "overscan";
  x: number;
  y: number;
  width: number;
  height: number;
}

export interface LineMapViewModel {
  lineId: string;
  lineLabel: string;
  lineColor: string;
  textColor: string;
  stops: LineMapStopView[];
  segments: LineMapSegmentView[];
  branches: LineMapBranchView[];
  tiles: MapTile[];
  viewport?: GeographicViewport;
  geometrySource: LineGeometrySource;
  geometryAttempts: LineGeometryAttempt[];
  geometryDatasetVersion?: string;
  entrances: LineMapEntranceView[];
}

export interface LineTransferSummary {
  stationId: string;
  transfers: TransferLineOption[];
}

export interface StationListItem {
  station: StationSearchOption;
  transfers?: TransferLineOption[];
  transfersLoading?: boolean;
}

export interface TransferLineDirections {
  lineId: string;
  directions: string[];
}
