  <script setup lang="ts">
  import { computed } from "vue";
  import { useI18n } from "../../i18n";
  import {
    getDisruptionIcon,
    getDisruptionTone,
    getTrafficDisruptionReason,
    isGenericTrafficWorksReason,
  } from "./trafficPresentation";
  import {
    getTrafficDisruptionDisplayPeriod,
    parseTrafficDate,
  } from "./trafficTiming";
  import type { TrafficDisruption } from "./types";

  const props = withDefaults(
    defineProps<{
      disruption: TrafficDisruption;
      compact?: boolean;
      statusLabel?: string;
      showHeader?: boolean;
      impactedStopLimit?: number;
    }>(),
    {
      compact: false,
      statusLabel: "",
      showHeader: true,
      impactedStopLimit: 8,
    },
  );

  const tone = computed(() => getDisruptionTone(props.disruption));
  const icon = computed(() => getDisruptionIcon(props.disruption));
  const { d, t } = useI18n();
  const periodLabel = computed(() =>
    formatTrafficDisruptionPeriodLabel(props.disruption),
  );
  const impactedStopNames = computed(() =>
    props.disruption.impactedStopNames.slice(0, props.impactedStopLimit),
  );
  const reason = computed(() => {
    const messageReason = getTrafficDisruptionReason(props.disruption.message);
    if (messageReason && !isGenericTrafficWorksReason(messageReason)) {
      return messageReason;
    }

    const cause = props.disruption.cause?.trim();
    return cause && !isGenericTrafficWorksReason(cause) ? cause : undefined;
  });
  const opaqueWorksTitle = computed(() => {
    if (props.disruption.kind !== "works") {
      return false;
    }

    const normalizedTitle = normalizeTrafficTitle(props.disruption.title);
    return !["travaux", "work", "works", "maintenance", "chantier"].some(
      (keyword) => normalizedTitle.includes(keyword),
    );
  });
  const displayTitle = computed(() => {
    if (!opaqueWorksTitle.value) {
      return props.disruption.title;
    }

    return reason.value
      ? t("traffic.worksTitle") + " — " + reason.value
      : t("traffic.worksTitle");
  });
  const displayMessage = computed(() => {
    if (!opaqueWorksTitle.value) {
      return props.disruption.message ?? "";
    }

    const message = props.disruption.message?.trim();
    if (!message) {
      return props.disruption.title;
    }

    return message + "\n" + props.disruption.title;
  });
  const displayCause = computed(() => {
    if (
      opaqueWorksTitle.value ||
      !reason.value ||
      getTrafficDisruptionReason(props.disruption.message)
    ) {
      return "";
    }

    return reason.value;
  });

  function normalizeTrafficTitle(value: string): string {
    return value
      .normalize("NFD")
      .replace(/\p{Diacritic}/gu, "")
      .toLowerCase();
  }

  function formatTrafficDisruptionPeriodLabel(
    disruption: TrafficDisruption,
  ): string {
    const period = getTrafficDisruptionDisplayPeriod(disruption);

    if (!period) {
      return "";
    }

    const begin = formatTrafficDateLabel(period.begin);
    const end = formatTrafficDateLabel(period.end);

    if (begin && end) {
      return t("traffic.period.range", { begin, end });
    }

    return begin
      ? t("traffic.period.from", { date: begin })
      : t("traffic.period.until", { date: end });
  }

  function formatTrafficDateLabel(value?: string): string {
    if (!value) {
      return "";
    }

    const date = parseTrafficDate(value);

    return !date || Number.isNaN(date.getTime())
      ? value
      : d(date, {
          dateStyle: "medium",
          timeStyle: "short",
        });
  }
  </script>

  <template>
    <article
      class="traffic-disruption"
      :class="[
        `traffic-disruption--${tone}`,
        { 'traffic-disruption--compact': compact },
      ]"
    >
      <header v-if="showHeader && (statusLabel || periodLabel)">
        <span v-if="statusLabel">{{ statusLabel }}</span>
        <small v-if="periodLabel">{{ periodLabel }}</small>
      </header>

      <div class="traffic-disruption__title">
        <span class="traffic-disruption__icon">
          {{ icon }}
        </span>
        <h3>{{ displayTitle }}</h3>
      </div>

      <p v-if="displayMessage">{{ displayMessage }}</p>
      <small v-if="displayCause">
        {{ t("traffic.cause") }} {{ displayCause }}
      </small>

      <small v-if="!showHeader && periodLabel">
        {{ periodLabel }}
      </small>
      <small v-if="impactedStopNames.length">
        {{ t("traffic.affectedStops") }}
        {{ impactedStopNames.join(", ") }}
      </small>
    </article>
  </template>

  <style scoped>
  .traffic-disruption {
    background: #ffffff;
    border: 1px solid rgba(16, 35, 63, 0.1);
    border-radius: 8px;
    display: grid;
    gap: 8px;
    padding: 12px;
  }

  .traffic-disruption--orange {
    border-color: #f59e0b;
  }

  .traffic-disruption--red {
    border-color: #ef4444;
  }

  .traffic-disruption__title {
    align-items: flex-start;
    display: flex;
    gap: 10px;
  }

  .traffic-disruption__icon {
    align-items: center;
    border-radius: 6px;
    color: #ffffff;
    display: inline-flex;
    flex: 0 0 auto;
    font-size: 0.86rem;
    font-weight: 950;
    height: 24px;
    justify-content: center;
    line-height: 1;
    text-transform: uppercase;
    width: 24px;
  }

  .traffic-disruption--orange .traffic-disruption__icon {
    background: #f59e0b;
    box-shadow: 0 0 0 2px #f59e0b;
  }

  .traffic-disruption--red .traffic-disruption__icon {
    background: #ef4444;
    box-shadow: 0 0 0 2px #ef4444;
  }

  .traffic-disruption header {
    align-items: center;
    display: flex;
    gap: 10px;
    justify-content: space-between;
  }

  .traffic-disruption header span {
    color: #5136ff;
    font-size: 0.74rem;
    font-weight: 950;
    letter-spacing: 0.03em;
    text-transform: uppercase;
  }

  .traffic-disruption header small,
  .traffic-disruption > small {
    color: var(--muted);
    font-weight: 780;
  }

  .traffic-disruption h3 {
    color: var(--ink);
    font-size: 1rem;
    margin: 0;
  }

  .traffic-disruption p {
    color: #334155;
    font-weight: 720;
    line-height: 1.45;
    margin: 0;
    white-space: pre-line;
  }
  </style>
